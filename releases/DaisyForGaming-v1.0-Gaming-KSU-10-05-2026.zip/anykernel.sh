# AnyKernel3 Ramdisk Mod Script
## DaisyForGaming by JUBAIR HOSEN (Linux 4.9.337)

properties() { '
kernel.string=DaisyForGaming v1.0
do.devicecheck=1
do.modules=0
do.systemless=1
do.cleanup=1
do.cleanuponabort=0
device.name1=daisy
device.name2=daisy_sprout
supported.versions=11
supported.patchlevels=
supported.vendor.patchlevels=
'; }

BLOCK=/dev/block/bootdevice/by-name/boot;
IS_SLOT_DEVICE=auto;
RAMDISK_COMPRESSION=auto;
PATCH_VBMETA_FLAG=auto;

. tools/ak3-core.sh;

ui_print " ";
ui_print "  [1/4] Checking device ...";
DEV_MODEL=$(getprop ro.product.device);
DEV_BUILD=$(getprop ro.build.product);
ui_print "        Detected : $DEV_MODEL";
case "$DEV_MODEL $DEV_BUILD" in
  *daisy*)
    ui_print "        Mi A2 Lite (daisy) confirmed.";
    ;;
  *)
    abort "  Not a Mi A2 Lite (daisy) device. Aborting.";
    ;;
esac;

ui_print "  [2/4] Checking ROM version ...";
ROM_VER=$(grep -m1 "^ro.build.version.release=" /system/build.prop 2>/dev/null | cut -d= -f2-);
case "$ROM_VER" in
  11*)  ui_print "        Android $ROM_VER supported." ;;
  "")   ui_print "        Android version unreadable, continuing." ;;
  *)    abort "  Android $ROM_VER not supported by DaisyForGaming. Aborting." ;;
esac;

ui_print "  [3/4] Checking boot slot ...";
SLOT_SUFFIX=$(getprop ro.boot.slot_suffix);
ui_print "        Slot : ${SLOT_SUFFIX:-single}";

ui_print "  [4/4] Installing kernel ...";
ui_print "        Target : $BLOCK";

dump_boot;

ui_print " ";
ui_print "  Kernel features:";
ui_print "    - Linux 4.9.337  (DaisyForGaming v1.0)";
ui_print "    - CPU touch boost ON: 1401MHz little /";
ui_print "      1689MHz big, 300ms + WALT sched boost";
ui_print "    - schedutil governor, Adreno msm-adreno-tz";
ui_print "    - top-app schedtune boost (boot script)";
ui_print "    - zRAM lz4 + writeback, UKSM low preset";
ui_print "    - deadline IO scheduler, fq_codel + BBR";
ui_print "    - KernelSU + SusFS built in (KSU Manager)";
ui_print "    - Magisk compatible (ramdisk preserved)";
ui_print " ";

write_boot;

# Stage the tuning service script so it survives reboots.
if [ -f ./dfg_tune.sh ]; then
  if [ -d /data/adb/service.d ]; then
    cp -f ./dfg_tune.sh /data/adb/service.d/99-dfg-tune.sh 2>/dev/null;
    chmod 755 /data/adb/service.d/99-dfg-tune.sh 2>/dev/null;
    ui_print "  Staged tuning script (input boost assert,";
    ui_print "  top-app schedtune, zram retry, vm tuning).";
  else
    ui_print "  Magisk service.d not found, tuning script skipped.";
  fi;
fi;

# Remove the legacy broken kloder autoload script if present.
if [ -f /data/adb/service.d/90-kloder.sh ]; then
  rm -f /data/adb/service.d/90-kloder.sh 2>/dev/null;
  ui_print "  Removed obsolete kloder autoload script.";
fi;

ui_print " ";
ui_print "  Done! DaisyForGaming v1.0 (KSU) installed.";
ui_print "  Root: KernelSU Manager or Magisk.";
ui_print "  - JUBAIR HOSEN";
ui_print " ";
