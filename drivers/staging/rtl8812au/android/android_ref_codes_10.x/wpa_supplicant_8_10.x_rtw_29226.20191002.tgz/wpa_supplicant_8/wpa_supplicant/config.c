/*
 * WPA Supplicant / Configuration parser and common functions
 * Copyright (c) 2003-2018, Jouni Malinen <j@w1.fi>
 *
 * This software may be distributed under the terms of the BSD license.
 * See README for more details.
 */

#include "includes.h"

#include "common.h"
#include "utils/uuid.h"
#include "utils/ip_addr.h"
#include "common/ieee802_1x_defs.h"
#include "crypto/sha1.h"
#include "rsn_supp/wpa.h"
#include "eap_peer/eap.h"
#include "p2p/p2p.h"
#include "fst/fst.h"
#include "config.h"


#if !defined(CONFIG_CTRL_IFACE) && defined(CONFIG_NO_CONFIG_WRITE)
#define NO_CONFIG_WRITE
#endif

/*
 * Structure for network configuration parsing. This data is used to implement
 * a generic parser for each network block variable. The table of configuration
 * variables is defined below in this file (ssid_fields[]).
 */
struct parse_data {
	/* Configuration variable name */
	char *name;

	/* Parser function for this variable. The parser functions return 0 or 1
	 * to indicate success. Value 0 indicates that the parameter value may
	 * have changed while value 1 means that the value did not change.
	 * Error cases (failure to parse the string) are indicated by returning
	 * -1. */
	int (*parser)(const struct parse_data *data, struct wpa_ssid *ssid,
		      int line, const char *value);

#ifndef NO_CONFIG_WRITE
	/* Writer function (i.e., to get the variable in text format from
	 * internal presentation). */
	char * (*writer)(const struct parse_data *data, struct wpa_ssid *ssid);
#endif /* NO_CONFIG_WRITE */

	/* Variable specific parameters for the parser. */
	void *param1, *param2, *param3, *param4;

	/* 0 = this variable can be included in debug output and ctrl_iface
	 * 1 = this variable contains key/private data and it must not be
	 *     included in debug output unless explicitly requested. In
	 *     addition, this variable will not be readable through the
	 *     ctrl_iface.
	 */
	int key_data;
};


static int wpa_config_parse_str(const struct parse_data *data,
				struct wpa_ssid *ssid,
				int line, const char *value)
{
	size_t res_len, *dst_len, prev_len;
	char **dst, *tmp;

	if (os_strcmp(value, "NULL") == 0) {
		wpa_printf(MSG_DEBUG, "Unset configuration string '%s'",
			   data->name);
		tmp = NULL;
		res_len = 0;
		goto set;
	}

	tmp = wpa_config_parse_string(value, &res_len);
	if (tmp == NULL) {
		wpa_printf(MSG_ERROR, "Line %d: failed to parse %s '%s'.",
			   line, data->name,
			   data->key_data ? "[KEY DATA REMOVED]" : value);
		return -1;
	}

	if (data->key_data) {
		wpa_hexdump_ascii_key(MSG_MSGDUMP, data->name,
				      (u8 *) tmp, res_len);
	} else {
		wpa_hexdump_ascii(MSG_MSGDUMP, data->name,
				  (u8 *) tmp, res_len);
	}

	if (data->param3 && res_len < (size_t) data->param3) {
		wpa_printf(MSG_ERROR, "Line %d: too short %s (len=%lu "
			   "min_len=%ld)", line, data->name,
			   (unsigned long) res_len, (long) data->param3);
		os_free(tmp);
		return -1;
	}

	if (data->param4 && res_len > (size_t) data->param4) {
		wpa_printf(MSG_ERROR, "Line %d: too long %s (len=%lu "
			   "max_len=%ld)", line, data->name,
			   (unsigned long) res_len, (long) data->param4);
		os_free(tmp);
		return -1;
	}

set:
	dst = (char **) (((u8 *) ssid) + (long) data->param1);
	dst_len = (size_t *) (((u8 *) ssid) + (long) data->param2);

	if (data->param2)
		prev_len = *dst_len;
	else if (*dst)
		prev_len = os_strlen(*dst);
	else
		prev_len = 0;
	if ((*dst == NULL && tmp == NULL) ||
	    (*dst && tmp && prev_len == res_len &&
	     os_memcmp(*dst, tmp, res_len) == 0)) {
		/* No change to the previously configured value */
		os_free(tmp);
		return 1;
	}

	os_free(*dst);
	*dst = tmp;
	if (data->param2)
		*dst_len = res_len;

	return 0;
}


#ifndef NO_CONFIG_WRITE
static char * wpa_config_write_string_ascii(const u8 *value, size_t len)
{
	char *buf;

	buf = os_malloc(len + 3);
	if (buf == NULL)
		return NULL;
	buf[0] = '"';
	os_memcpy(buf + 1, value, len);
	buf[len + 1] = '"';
	buf[len + 2] = '\0';

	return buf;
}


static char * wpa_config_write_string_hex(const u8 *value, size_t len)
{
	char *buf;

	buf = os_zalloc(2 * len + 1);
	if (buf == NULL)
		return NULL;
	wpa_snprintf_hex(buf, 2 * len + 1, value, len);

	return buf;
}


static char * wpa_config_write_string(const u8 *value, size_t len)
{
	if (value == NULL)
		return NULL;

	if (is_hex(value, len))
		return wpa_config_write_string_hex(value, len);
	else
		return wpa_config_write_string_ascii(value, len);
}


static char * wpa_config_write_str(const struct parse_data *data,
				   struct wpa_ssid *ssid)
{
	size_t len;
	char **src;

	src = (char **) (((u8 *) ssid) + (long) data->param1);
	if (*src == NULL)
		return NULL;

	if (data->param2)
		len = *((size_t *) (((u8 *) ssid) + (long) data->param2));
	else
		len = os_strlen(*src);

	return wpa_config_write_string((const u8 *) *src, len);
}
#endif /* NO_CONFIG_WRITE */


static int wpa_config_parse_int(const struct parse_data *data,
				struct wpa_ssid *ssid,
				int line, const char *value)
{
	int val, *dst;
	char *end;

	dst = (int *) (((u8 *) ssid) + (long) data->param1);
	val = strtol(value, &end, 0);
	if (*end) {
		wpa_printf(MSG_ERROR, "Line %d: invalid number \"%s\"",
			   line, value);
		return -1;
	}

	if (*dst == val)
		return 1;
	*dst = val;
	wpa_printf(MSG_MSGDUMP, "%s=%d (0x%x)", data->name, *dst, *dst);

	if (data->param3 && *dst < (long) data->param3) {
		wpa_printf(MSG_ERROR, "Line %d: too small %s (value=%d "
			   "min_value=%ld)", line, data->name, *dst,
			   (long) data->param3);
		*dst = (long) data->param3;
		return -1;
	}

	if (data->param4 && *dst > (long) data->param4) {
		wpa_printf(MSG_ERROR, "Line %d: too large %s (value=%d "
			   "max_value=%ld)", line, data->name, *dst,
			   (long) data->param4);
		*dst = (long) data->param4;
		return -1;
	}

	return 0;
}


#ifndef NO_CONFIG_WRITE
static char * wpa_config_write_int(const struct parse_data *data,
				   struct wpa_ssid *ssid)
{
	int *src, res;
	char *value;

	src = (int *) (((u8 *) ssid) + (long) data->param1);

	value = os_malloc(20);
	if (value == NULL)
		return NULL;
	res = os_snprintf(value, 20, "%d", *src);
	if (os_snprintf_error(20, res)) {
		os_free(value);
		return NULL;
	}
	value[20 - 1] = '\0';
	return value;
}
#endif /* NO_CONFIG_WRITE */


static int wpa_config_parse_addr_list(const struct parse_data *data,
				      int line, const char *value,
				      u8 **list, size_t *num, char *name,
				      u8 abort_on_error, u8 masked)
{
	const char *pos;
	u8 *buf, *n, addr[2 * ETH_ALEN];
	size_t count;

	buf = NULL;
	count = 0;

	pos = value;
	while (pos && *pos) {
		while (*pos == ' ')
			pos++;

		if (hwaddr_masked_aton(pos, addr, &addr[ETH_ALEN], masked)) {
			if (abort_on_error || count == 0) {
				wpa_printf(MSG_ERROR,
					   "Line %d: Invalid %s address '%s'",
					   line, name, value);
				os_free(buf);
				return -1;
			}
			/* continue anyway since this could have been from a
			 * truncated configuration file line */
			wpa_printf(MSG_INFO,
				   "Line %d: Ignore likely truncated %s address '%s'",
				   line, name, pos);
		} else {
			n = os_realloc_array(buf, count + 1, 2 * ETH_ALEN);
			if (n == NULL) {
				os_free(buf);
				return -1;
			}
			buf = n;
			os_memmove(buf + 2 * ETH_ALEN, buf,
				   count * 2 * ETH_ALEN);
			os_memcpy(buf, addr, 2 * ETH_ALEN);
			count++;
			wpa_printf(MSG_MSGDUMP,
				   "%s: addr=" MACSTR " mask=" MACSTR,
				   name, MAC2STR(addr),
				   MAC2STR(&addr[ETH_ALEN]));
		}

		pos = os_strchr(pos, ' ');
	}

	os_free(*list);
	*list = buf;
	*num = count;

	return 0;
}


#ifndef NO_CONFIG_WRITE
static char * wpa_config_write_addr_list(const struct parse_data *data,
					 const u8 *list, size_t num, char *name)
{
	char *value, *end, *pos;
	int res;
	size_t i;

	if (list == NULL || num == 0)
		return NULL;

	value = os_malloc(2 * 20 * num);
	if (value == NULL)
		return NULL;
	pos = value;
	end = value + 2 * 20 * num;

	for (i = num; i > 0; i--) {
		const u8 *a = list + (i - 1) * 2 * ETH_ALEN;
		const u8 *m = a + ETH_ALEN;

		if (i < num)
			*pos++ = ' ';
		res = hwaddr_mask_txt(pos, end - pos, a, m);
		if (res < 0) {
			os_free(value);
			return NULL;
		}
		pos += res;
	}

	return value;
}
#endif /* NO_CONFIG_WRITE */

static int wpa_config_parse_bssid(const struct parse_data *data,
				  struct wpa_ssid *ssid, int line,
				  const char *value)
{
	if (value[0] == '\0' || os_strcmp(value, "\"\"") == 0 ||
	    os_strcmp(value, "any") == 0) {
		ssid->bssid_set = 0;
		wpa_printf(MSG_MSGDUMP, "BSSID any");
		return 0;
	}
	if (hwaddr_aton(value, ssid->bssid)) {
		wpa_printf(MSG_ERROR, "Line %d: Invalid BSSID '%s'.",
			   line, value);
		return -1;
	}
	ssid->bssid_set = 1;
	wpa_hexdump(MSG_MSGDUMP, "BSSID", ssid->bssid, ETH_ALEN);
	return 0;
}


#ifndef NO_CONFIG_WRITE
static char * wpa_config_write_bssid(const struct parse_data *data,
				     struct wpa_ssid *ssid)
{
	char *value;
	int res;

	if (!ssid->bssid_set)
		return NULL;

	value = os_malloc(20);
	if (value == NULL)
		return NULL;
	res = os_snprintf(value, 20, MACSTR, MAC2STR(ssid->bssid));
	if (os_snprintf_error(20, res)) {
		os_free(value);
		return NULL;
	}
	value[20 - 1] = '\0';
	return value;
}
#endif /* NO_CONFIG_WRITE */


static int wpa_config_parse_bssid_hint(const struct parse_data *data,
				       struct wpa_ssid *ssid, int line,
				       const char *value)
{
	if (value[0] == '\0' || os_strcmp(value, "\"\"") == 0 ||
	    os_strcmp(value, "any") == 0) {
		ssid->bssid_hint_set = 0;
		wpa_printf(MSG_MSGDUMP, "BSSID hint any");
		return 0;
	}
	if (hwaddr_aton(value, ssid->bssid_hint)) {
		wpa_printf(MSG_ERROR, "Line %d: Invalid BSSID hint '%s'.",
			   line, value);
		return -1;
	}
	ssid->bssid_hint_set = 1;
	wpa_hexdump(MSG_MSGDUMP, "BSSID hint", ssid->bssid_hint, ETH_ALEN);
	return 0;
}


#ifndef NO_CONFIG_WRITE
static char * wpa_config_write_bssid_hint(const struct parse_data *data,
					  struct wpa_ssid *ssid)
{
	char *value;
	int res;

	if (!ssid->bssid_hint_set)
		return NULL;

	value = os_malloc(20);
	if (!value)
		return NULL;
	res = os_snprintf(value, 20, MACSTR, MAC2STR(ssid->bssid_hint));
	if (os_snprintf_error(20, res)) {
		os_free(value);
		return NULL;
	}
	return value;
}
#endif /* NO_CONFIG_WRITE */


static int wpa_config_parse_bssid_blacklist(const struct parse_data *data,
					    struct wpa_ssid *ssid, int line,
					    const char *value)
{
	return wpa_config_parse_addr_list(data, line, value,
					  &ssid->bssid_blacklist,
					  &ssid->num_bssid_blacklist,
					  "bssid_blacklist", 1, 1);
}


#ifndef NO_CONFIG_WRITE
static char * wpa_config_write_bssid_blacklist(const struct parse_data *data,
					       struct wpa_ssid *ssid)
{
	return wpa_config_write_addr_list(data, ssid->bssid_blacklist,
					  ssid->num_bssid_blacklist,
					  "bssid_blacklist");
}
#endif /* NO_CONFIG_WRITE */


static int wpa_config_parse_bssid_whitelist(const struct parse_data *data,
					    struct wpa_ssid *ssid, int line,
					    const char *value)
{
	return wpa_config_parse_addr_list(data, line, value,
					  &ssid->bssid_whitelist,
					  &ssid->num_bssid_whitelist,
					  "bssid_whitelist", 1, 1);
}


#ifndef NO_CONFIG_WRITE
static char * wpa_config_write_bssid_whitelist(const struct parse_data *data,
					       struct wpa_ssid *ssid)
{
	return wpa_config_write_addr_list(data, ssid->bssid_whitelist,
					  ssid->num_bssid_whitelist,
					  "bssid_whitelist");
}
#endif /* NO_CONFIG_WRITE */


static int wpa_config_parse_psk(const struct parse_data *data,
				struct wpa_ssid *ssid, int line,
				const char *value)
{
#ifdef CONFIG_EXT_PASSWORD
	if (os_strncmp(value, "ext:", 4) == 0) {
		str_clear_free(ssid->passphrase);
		ssid->passphrase = NULL;
		ssid->psk_set = 0;
		os_free(ssid->ext_psk);
		ssid->ext_psk = os_strdup(value + 4);
		if (ssid->ext_psk == NULL)
			return -1;
		wpa_printf(MSG_DEBUG, "PSK: External password '%s'",
			   ssid->ext_psk);
		return 0;
	}
#endif /* CONFIG_EXT_PASSWORD */

	if (*value == '"') {
#ifndef CONFIG_NO_PBKDF2
		const char *pos;
		size_t len;

		value++;
		pos = os_strrchr(value, '"');
		if (pos)
			len = pos - value;
		else
			len = os_strlen(value);
		if (len < 8 || len > 63) {
			wpa_printf(MSG_ERROR, "Line %d: Invalid passphrase "
				   "length %lu (expected: 8..63) '%s'.",
				   line, (unsigned long) len, value);
			return -1;
		}
		wpa_hexdump_ascii_key(MSG_MSGDUMP, "PSK (ASCII passphrase)",
				      (u8 *) value, len);
		if (has_ctrl_char((u8 *) value, len)) {
			wpa_printf(MSG_ERROR,
				   "Line %d: Invalid passphrase character",
				   line);
			return -1;
		}
		if (ssid->passphrase && os_strlen(ssid->passphrase) == len &&
		    os_memcmp(ssid->passphrase, value, len) == 0) {
			/* No change to the previously configured value */
			return 1;
		}
		ssid->psk_set = 0;
		str_clear_free(ssid->passphrase);
		ssid->passphrase = dup_binstr(value, len);
		if (ssid->passphrase == NULL)
			return -1;
		return 0;
#else /* CONFIG_NO_PBKDF2 */
		wpa_printf(MSG_ERROR, "Line %d: ASCII passphrase not "
			   "supported.", line);
		return -1;
#endif /* CONFIG_NO_PBKDF2 */
	}

	if (hexstr2bin(value, ssid->psk, PMK_LEN) ||
	    value[PMK_LEN * 2] != '\0') {
		wpa_printf(MSG_ERROR, "Line %d: Invalid PSK '%s'.",
			   line, value);
		return -1;
	}

	str_clear_free(ssid->passphrase);
	ssid->passphrase = NULL;

	ssid->psk_set = 1;
	wpa_hexdump_key(MSG_MSGDUMP, "PSK", ssid->psk, PMK_LEN);
	return 0;
}


#ifndef NO_CONFIG_WRITE
static char * wpa_config_write_psk(const struct parse_data *data,
				   struct wpa_ssid *ssid)
{
#ifdef CONFIG_EXT_PASSWORD
	if (ssid->ext_psk) {
		size_t len = 4 + os_strlen(ssid->ext_psk) + 1;
		char *buf = os_malloc(len);
		int res;

		if (buf == NULL)
			return NULL;
		res = os_snprintf(buf, len, "ext:%s", ssid->ext_psk);
		if (os_snprintf_error(len, res)) {
			os_free(buf);
			buf = NULL;
		}
		return buf;
	}
#endif /* CONFIG_EXT_PASSWORD */

	if (ssid->passphrase)
		return wpa_config_write_string_ascii(
			(const u8 *) ssid->passphrase,
			os_strlen(ssid->passphrase));

	if (ssid->psk_set)
		return wpa_config_write_string_hex(ssid->psk, PMK_LEN);

	return NULL;
}
#endif /* NO_CONFIG_WRITE */


static int wpa_config_parse_proto(const struct parse_data *data,
				  struct wpa_ssid *ssid, int line,
				  const char *value)
{
	int val = 0, last, errors = 0;
	char *start, *end, *buf;

	buf = os_strdup(value);
	if (buf == NULL)
		return -1;
	start = buf;

	while (*start != '\0') {
		while (*start == ' ' || *start == '\t')
			start++;
		if (*start == '\0')
			break;
		end = start;
		while (*end != ' ' && *end != '\t' && *end != '\0')
			end++;
		last = *end == '\0';
		*end = '\0';
		if (os_strcmp(start, "WPA") == 0)
			val |= WPA_PROTO_WPA;
		else if (os_strcmp(start, "RSN") == 0 ||
			 os_strcmp(start, "WPA2") == 0)
			val |= WPA_PROTO_RSN;
		else if (os_strcmp(start, "OSEN") == 0)
			val |= WPA_PROTO_OSEN;
		else {
			wpa_printf(MSG_ERROR, "Line %d: invalid proto '%s'",
				   line, start);
			errors++;
		}

		if (last)
			break;
		start = end + 1;
	}
	os_free(buf);

	if (val == 0) {
		wpa_printf(MSG_ERROR,
			   "Line %d: no proto values configured.", line);
		errors++;
	}

	if (!errors && ssid->proto == val)
		return 1;
	wpa_printf(MSG_MSGDUMP, "proto: 0x%x", val);
	ssid->proto = val;
	return errors ? -1 : 0;
}


#ifndef NO_CONFIG_WRITE
static char * wpa_config_write_proto(const struct parse_data *data,
				     struct wpa_ssid *ssid)
{
	int ret;
	char *buf, *pos, *end;

	pos = buf = os_zalloc(20);
	if (buf == NULL)
		return NULL;
	end = buf + 20;

	if (ssid->proto & WPA_PROTO_WPA) {
		ret = os_snprintf(pos, end - pos, "%sWPA",
				  pos == buf ? "" : " ");
		if (os_snprintf_error(end - pos, ret))
			return buf;
		pos += ret;
	}

	if (ssid->proto & WPA_PROTO_RSN) {
		ret = os_snprintf(pos, end - pos, "%sRSN",
				  pos == buf ? "" : " ");
		if (os_snprintf_error(end - pos, ret))
			return buf;
		pos += ret;
	}

	if (ssid->proto & WPA_PROTO_OSEN) {
		ret = os_snprintf(pos, end - pos, "%sOSEN",
				  pos == buf ? "" : " ");
		if (os_snprintf_error(end - pos, ret))
			return buf;
		pos += ret;
	}

	if (pos == buf) {
		os_free(buf);
		buf = NULL;
	}

	return buf;
}
#endif /* NO_CONFIG_WRITE */


static int wpa_config_parse_key_mgmt(const struct parse_data *data,
				     struct wpa_ssid *ssid, int line,
				     const char *value)
{
	int val = 0, last, errors = 0;
	char *start, *end, *buf;

	buf = os_strdup(value);
	if (buf == NULL)
		return -1;
	start = buf;

	while (*start != '\0') {
		while (*start == ' ' || *start == '\t')
			start++;
		if (*start == '\0')
			break;
		end = start;
		while (*end != ' ' && *end != '\t' && *end != '\0')
			end++;
		last = *end == '\0';
		*end = '\0';
		if (os_strcmp(start, "WPA-PSK") == 0)
			val |= WPA_KEY_MGMT_PSK;
		else if (os_strcmp(start, "WPA-EAP") == 0)
			val |= WPA_KEY_MGMT_IEEE8021X;
		else if (os_strcmp(start, "IEEE8021X") == 0)
			val |= WPA_KEY_MGMT_IEEE8021X_NO_WPA;
		else if (os_strcmp(start, "NONE") == 0)
			val |= WPA_KEY_MGMT_NONE;
		else if (os_strcmp(start, "WPA-NONE") == 0)
			val |= WPA_KEY_MGMT_WPA_NONE;
#ifdef CONFIG_IEEE80211R
		else if (os_strcmp(start, "FT-PSK") == 0)
			val |= WPA_KEY_MGMT_FT_PSK;
		else if (os_strcmp(start, "FT-EAP") == 0)
			val |= WPA_KEY_MGMT_FT_IEEE8021X;
#ifdef CONFIG_SHA384
		else if (os_strcmp(start, "FT-EAP-SHA384") == 0)
			val |= WPA_KEY_MGMT_FT_IEEE8021X_SHA384;
#endif /* CONFIG_SHA384 */
#endif /* CONFIG_IEEE80211R */
#ifdef CONFIG_IEEE80211W
		else if (os_strcmp(start, "WPA-PSK-SHA256") == 0)
			val |= WPA_KEY_MGMT_PSK_SHA256;
		else if (os_strcmp(start, "WPA-EAP-SHA256") == 0)
			val |= WPA_KEY_MGMT_IEEE8021X_SHA256;
#endif /* CONFIG_IEEE80211W */
#ifdef CONFIG_WPS
		else if (os_strcmp(start, "WPS") == 0)
			val |= WPA_KEY_MGMT_WPS;
#endif /* CONFIG_WPS */
#ifdef CONFIG_SAE
		else if (os_strcmp(start, "SAE") == 0)
			val |= WPA_KEY_MGMT_SAE;
		else if (os_strcmp(start, "FT-SAE") == 0)
			val |= WPA_KEY_MGMT_FT_SAE;
#endif /* CONFIG_SAE */
#ifdef CONFIG_HS20
		else if (os_strcmp(start, "OSEN") == 0)
			val |= WPA_KEY_MGMT_OSEN;
#endif /* CONFIG_HS20 */
#ifdef CONFIG_SUITEB
		else if (os_strcmp(start, "WPA-EAP-SUITE-B") == 0)
			val |= WPA_KEY_MGMT_IEEE8021X_SUITE_B;
#endif /* CONFIG_SUITEB */
#ifdef CONFIG_SUITEB192
		else if (os_strcmp(start, "WPA-EAP-SUITE-B-192") == 0)
			val |= WPA_KEY_MGMT_IEEE8021X_SUITE_B_192;
#endif /* CONFIG_SUITEB192 */
#ifdef CONFIG_FILS
		else if (os_strcmp(start, "FILS-SHA256") == 0)
			val |= WPA_KEY_MGMT_FILS_SHA256;
		else if (os_strcmp(start, "FILS-SHA384") == 0)
			val |= WPA_KEY_MGMT_FILS_SHA384;
#ifdef CONFIG_IEEE80211R
		else if (os_strcmp(start, "FT-FILS-SHA256") == 0)
			val |= WPA_KEY_MGMT_FT_FILS_SHA256;
		else if (os_strcmp(start, "FT-FILS-SHA384") == 0)
			val |= WPA_KEY_MGMT_FT_FILS_SHA384;
#endif /* CONFIG_IEEE80211R */
#endif /* CONFIG_FILS */
#ifdef CONFIG_OWE
		else if (os_strcmp(start, "OWE") == 0)
			val |= WPA_KEY_MGMT_OWE;
#endif /* CONFIG_OWE */
#ifdef CONFIG_DPP
		else if (os_strcmp(start, "DPP") == 0)
			val |= WPA_KEY_MGMT_DPP;
#endif /* CONFIG_DPP */
		else {
			wpa_printf(MSG_ERROR, "Line %d: invalid key_mgmt '%s'",
				   line, start);
			errors++;
		}

		if (last)
			break;
		start = end + 1;
	}
	os_free(buf);

	if (val == 0) {
		wpa_printf(MSG_ERROR,
			   "Line %d: no key_mgmt values configured.", line);
		errors++;
	}

	if (!errors && ssid->key_mgmt == val)
		return 1;
	wpa_printf(MSG_MSGDUMP, "key_mgmt: 0x%x", val);
	ssid->key_mgmt = val;
	return errors ? -1 : 0;
}


#ifndef NO_CONFIG_WRITE
static char * wpa_config_write_key_mgmt(const struct parse_data *data,
					struct wpa_ssid *ssid)
{
	char *buf, *pos, *end;
	int ret;

	pos = buf = os_zalloc(100);
	if (buf == NULL)
		return NULL;
	end = buf + 100;

	if (ssid->key_mgmt & WPA_KEY_MGMT_PSK) {
		ret = os_snprintf(pos, end - pos, "%sWPA-PSK",
				  pos == buf ? "" : " ");
		if (os_snprintf_error(end - pos, ret)) {
			end[-1] = '\0';
			return buf;
		}
		pos += ret;
	}

	if (ssid->key_mgmt & WPA_KEY_MGMT_IEEE8021X) {
		ret = os_snprintf(pos, end - pos, "%sWPA-EAP",
				  pos == buf ? "" : " ");
		if (os_snprintf_error(end - pos, ret)) {
			end[-1] = '\0';
			return buf;
		}
		pos += ret;
	}

	if (ssid->key_mgmt & WPA_KEY_MGMT_IEEE8021X_NO_WPA) {
		ret = os_snprintf(pos, end - pos, "%sIEEE8021X",
				  pos == buf ? "" : " ");
		if (os_snprintf_error(end - pos, ret)) {
			end[-1] = '\0';
			return buf;
		}
		pos += ret;
	}

	if (ssid->key_mgmt & WPA_KEY_MGMT_NONE) {
		ret = os_snprintf(pos, end - pos, "%sNONE",
				  pos == buf ? "" : " ");
		if (os_snprintf_error(end - pos, ret)) {
			end[-1] = '\0';
			return buf;
		}
		pos += ret;
	}

	if (ssid->key_mgmt & WPA_KEY_MGMT_WPA_NONE) {
		ret = os_snprintf(pos, end - pos, "%sWPA-NONE",
				  pos == buf ? "" : " ");
		if (os_snprintf_error(end - pos, ret)) {
			end[-1] = '\0';
			return buf;
		}
		pos += ret;
	}

#ifdef CONFIG_IEEE80211R
	if (ssid->key_mgmt & WPA_KEY_MGMT_FT_PSK) {
		ret = os_snprintf(pos, end - pos, "%sFT-PSK",
				  pos == buf ? "" : " ");
		if (os_snprintf_error(end - pos, ret)) {
			end[-1] = '\0';
			return buf;
		}
		pos += ret;
	}

	if (ssid->key_mgmt & WPA_KEY_MGMT_FT_IEEE8021X) {
		ret = os_snprintf(pos, end - pos, "%sFT-EAP",
				  pos == buf ? "" : " ");
		if (os_snprintf_error(end - pos, ret)) {
			end[-1] = '\0';
			return buf;
		}
		pos += ret;
	}

#ifdef CONFIG_SHA384
	if (ssid->key_mgmt & WPA_KEY_MGMT_FT_IEEE8021X_SHA384) {
		ret = os_snprintf(pos, end - pos, "%sFT-EAP-SHA384",
				  pos == buf ? "" : " ");
		if (os_snprintf_error(end - pos, ret)) {
			end[-1] = '\0';
			return buf;
		}
		pos += ret;
	}
#endif /* CONFIG_SHA384 */
#endif /* CONFIG_IEEE80211R */

#ifdef CONFIG_IEEE80211W
	if (ssid->key_mgmt & WPA_KEY_MGMT_PSK_SHA256) {
		ret = os_snprintf(pos, end - pos, "%sWPA-PSK-SHA256",
				  pos == buf ? "" : " ");
		if (os_snprintf_error(end - pos, ret)) {
			end[-1] = '\0';
			return buf;
		}
		pos += ret;
	}

	if (ssid->key_mgmt & WPA_KEY_MGMT_IEEE8021X_SHA256) {
		ret = os_snprintf(pos, end - pos, "%sWPA-EAP-SHA256",
				  pos == buf ? "" : " ");
		if (os_snprintf_error(end - pos, ret)) {
			end[-1] = '\0';
			return buf;
		}
		pos += ret;
	}
#endif /* CONFIG_IEEE80211W */

#ifdef CONFIG_WPS
	if (ssid->key_mgmt & WPA_KEY_MGMT_WPS) {
		ret = os_snprintf(pos, end - pos, "%sWPS",
				  pos == buf ? "" : " ");
		if (os_snprintf_error(end - pos, ret)) {
			end[-1] = '\0';
			return buf;
		}
		pos += ret;
	}
#endif /* CONFIG_WPS */

#ifdef CONFIG_SAE
	if (ssid->key_mgmt & WPA_KEY_MGMT_SAE) {
		ret = os_snprintf(pos, end - pos, "%sSAE",
				  pos == buf ? "" : " ");
		if (os_snprintf_error(end - pos, ret)) {
			end[-1] = '\0';
			return buf;
		}
		pos += ret;
	}

	if (ssid->key_mgmt & WPA_KEY_MGMT_FT_SAE) {
		ret = os_snprintf(pos, end - pos, "%sFT-SAE",
				  pos == buf ? "" : " ");
		if (os_snprintf_error(end - pos, ret)) {
			end[-1] = '\0';
			return buf;
		}
		pos += ret;
	}
#endif /* CONFIG_SAE */

#ifdef CONFIG_HS20
	if (ssid->key_mgmt & WPA_KEY_MGMT_OSEN) {
		ret = os_snprintf(pos, end - pos, "%sOSEN",
				  pos == buf ? "" : " ");
		if (os_snprintf_error(end - pos, ret)) {
			end[-1] = '\0';
			return buf;
		}
		pos += ret;
	}
#endif /* CONFIG_HS20 */

#ifdef CONFIG_SUITEB
	if (ssid->key_mgmt & WPA_KEY_MGMT_IEEE8021X_SUITE_B) {
		ret = os_snprintf(pos, end - pos, "%sWPA-EAP-SUITE-B",
				  pos == buf ? "" : " ");
		if (os_snprintf_error(end - pos, ret)) {
			end[-1] = '\0';
			return buf;
		}
		pos += ret;
	}
#endif /* CONFIG_SUITEB */

#ifdef CONFIG_SUITEB192
	if (ssid->key_mgmt & WPA_KEY_MGMT_IEEE8021X_SUITE_B_192) {
		ret = os_snprintf(pos, end - pos, "%sWPA-EAP-SUITE-B-192",
				  pos == buf ? "" : " ");
		if (os_snprintf_error(end - pos, ret)) {
			end[-1] = '\0';
			return buf;
		}
		pos += ret;
	}
#endif /* CONFIG_SUITEB192 */

#ifdef CONFIG_FILS
	if (ssid->key_mgmt & WPA_KEY_MGMT_FILS_SHA256) {
		ret = os_snprintf(pos, end - pos, "%sFILS-SHA256",
				  pos == buf ? "" : " ");
		if (os_snprintf_error(end - pos, ret)) {
			end[-1] = '\0';
			return buf;
		}
		pos += ret;
	}
	if (ssid->key_mgmt & WPA_KEY_MGMT_FILS_SHA384) {
		ret = os_snprintf(pos, end - pos, "%sFILS-SHA384",
				  pos == buf ? "" : " ");
		if (os_snprintf_error(end - pos, ret)) {
			end[-1] = '\0';
			return buf;
		}
		pos += ret;
	}
#ifdef CONFIG_IEEE80211R
	if (ssid->key_mgmt & WPA_KEY_MGMT_FT_FILS_SHA256) {
		ret = os_snprintf(pos, end - pos, "%sFT-FILS-SHA256",
				  pos == buf ? "" : " ");
		if (os_snprintf_error(end - pos, ret)) {
			end[-1] = '\0';
			return buf;
		}
		pos += ret;
	}
	if (ssid->key_mgmt & WPA_KEY_MGMT_FT_FILS_SHA384) {
		ret = os_snprintf(pos, end - pos, "%sFT-FILS-SHA384",
				  pos == buf ? "" : " ");
		if (os_snprintf_error(end - pos, ret)) {
			end[-1] = '\0';
			return buf;
		}
		pos += ret;
	}
#endif /* CONFIG_IEEE80211R */
#endif /* CONFIG_FILS */

#ifdef CONFIG_DPP
	if (ssid->key_mgmt & WPA_KEY_MGMT_DPP) {
		ret = os_snprintf(pos, end - pos, "%sDPP",
				  pos == buf ? "" : " ");
		if (os_snprintf_error(end - pos, ret)) {
			end[-1] = '\0';
			return buf;
		}
		pos += ret;
	}
#endif /* CONFIG_DPP */

#ifdef CONFIG_OWE
	if (ssid->key_mgmt & WPA_KEY_MGMT_OWE) {
		ret = os_snprintf(pos, end - pos, "%sOWE",
				  pos == buf ? "" : " ");
		if (os_snprintf_error(end - pos, ret)) {
			end[-1] = '\0';
			return buf;
		}
		pos += ret;
	}
#endif /* CONFIG_OWE */

	if (pos == buf) {
		os_free(buf);
		buf = NULL;
	}

	return buf;
}
#endif /* NO_CONFIG_WRITE */


static int wpa_config_parse_cipher(int line, const char *value)
{
#ifdef CONFIG_NO_WPA
	return -1;
#else /* CONFIG_NO_WPA */
	int val = wpa_parse_cipher(value);
	if (val < 0) {
		wpa_printf(MSG_ERROR, "Line %d: invalid cipher '%s'.",
			   line, value);
		return -1;
	}
	if (val == 0) {
		wpa_printf(MSG_ERROR, "Line %d: no cipher values configured.",
			   line);
		return -1;
	}
	return val;
#endif /* CONFIG_NO_WPA */
}


#ifndef NO_CONFIG_WRITE
static char * wpa_config_write_cipher(int cipher)
{
#ifdef CONFIG_NO_WPA
	return NULL;
#else /* CONFIG_NO_WPA */
	char *buf = os_zalloc(50);
	if (buf == NULL)
		return NULL;

	if (wpa_write_ciphers(buf, buf + 50, cipher, " ") < 0) {
		os_free(buf);
		return NULL;
	}

	return buf;
#endif /* CONFIG_NO_WPA */
}
#endif /* NO_CONFIG_WRITE */


static int wpa_config_parse_pairwise(const struct parse_data *data,
				     struct wpa_ssid *ssid, int line,
				     const char *value)
{
	int val;
	val = wpa_config_parse_cipher(line, value);
	if (val == -1)
		return -1;
	if (val & ~WPA_ALLOWED_PAIRWISE_CIPHERS) {
		wpa_printf(MSG_ERROR, "Line %d: not allowed pairwise cipher "
			   "(0x%x).", line, val);
		return -1;
	}

	if (ssid->pairwise_cipher == val)
		return 1;
	wpa_printf(MSG_MSGDUMP, "pairwise: 0x%x", val);
	ssid->pairwise_cipher = val;
	return 0;
}


#ifndef NO_CONFIG_WRITE
static char * wpa_config_write_pairwise(const struct parse_data *data,
					struct wpa_ssid *ssid)
{
	return wpa_config_write_cipher(ssid->pairwise_cipher);
}
#endif /* NO_CONFIG_WRITE */


static int wpa_config_parse_group(const struct parse_data *data,
				  struct wpa_ssid *ssid, int line,
				  const char *value)
{
	int val;
	val = wpa_config_parse_cipher(line, value);
	if (val == -1)
		return -1;

	/*
	 * Backwards compatibility - filter out WEP ciphers that were previously
	 * allowed.
	 */
	val &= ~(WPA_CIPHER_WEP104 | WPA_CIPHER_WEP40);

	if (val & ~WPA_ALLOWED_GROUP_CIPHERS) {
		wpa_printf(MSG_ERROR, "Line %d: not allowed group cipher "
			   "(0x%x).", line, val);
		return -1;
	}

	if (ssid->group_cipher == val)
		return 1;
	wpa_printf(MSG_MSGDUMP, "group: 0x%x", val);
	ssid->group_cipher = val;
	return 0;
}


#ifndef NO_CONFIG_WRITE
static char * wpa_config_write_group(const struct parse_data *data,
				     struct wpa_ssid *ssid)
{
	return wpa_config_write_cipher(ssid->group_cipher);
}
#endif /* NO_CONFIG_WRITE */


static int wpa_config_parse_group_mgmt(const struct parse_data *data,
				       struct wpa_ssid *ssid, int line,
				       const char *value)
{
	int val;

	val = wpa_config_parse_cipher(line, value);
	if (val == -1)
		return -1;

	if (val & ~WPA_ALLOWED_GROUP_MGMT_CIPHERS) {
		wpa_printf(MSG_ERROR,
			   "Line %d: not allowed group management cipher (0x%x).",
			   line, val);
		return -1;
	}

	if (ssid->group_mgmt_cipher == val)
		return 1;
	wpa_printf(MSG_MSGDUMP, "group_mgmt: 0x%x", val);
	ssid->group_mgmt_cipher = val;
	return 0;
}


#ifndef NO_CONFIG_WRITE
static char * wpa_config_write_group_mgmt(const struct parse_data *data,
					  struct wpa_ssid *ssid)
{
	return wpa_config_write_cipher(ssid->group_mgmt_cipher);
}
#endif /* NO_CONFIG_WRITE */


static int wpa_config_parse_auth_alg(const struct parse_data *data,
				     struct wpa_ssid *ssid, int line,
				     const char *value)
{
	int val = 0, last, errors = 0;
	char *start, *end, *buf;

	buf = os_strdup(value);
	if (buf == NULL)
		return -1;
	start = buf;

	while (*start != '\0') {
		while (*start == ' ' || *start == '\t')
			start++;
		if (*start == '\0')
			break;
		end = start;
		while (*end != ' ' && *end != '\t' && *end != '\0')
			end++;
		last = *end == '\0';
		*end = '\0';
		if (os_strcmp(start, "OPEN") == 0)
			val |= WPA_AUTH_ALG_OPEN;
		else if (os_strcmp(start, "SHARED") == 0)
			val |= WPA_AUTH_ALG_SHARED;
		else if (os_strcmp(start, "LEAP") == 0)
			val |= WPA_AUTH_ALG_LEAP;
		else {
			wpa_printf(MSG_ERROR, "Line %d: invalid auth_alg '%s'",
				   line, start);
			errors++;
		}

		if (last)
			break;
		start = end + 1;
	}
	os_free(buf);

	if (val == 0) {
		wpa_printf(MSG_ERROR,
			   "Line %d: no auth_alg values configured.", line);
		errors++;
	}

	if (!errors && ssid->auth_alg == val)
		return 1;
	wpa_printf(MSG_MSGDUMP, "auth_alg: 0x%x", val);
	ssid->auth_alg = val;
	return errors ? -1 : 0;
}


#ifndef NO_CONFIG_WRITE
static char * wpa_config_write_auth_alg(const struct parse_data *data,
					struct wpa_ssid *ssid)
{
	char *buf, *pos, *end;
	int ret;

	pos = buf = os_zalloc(30);
	if (buf == NULL)
		return NULL;
	end = buf + 30;

	if (ssid->auth_alg & WPA_AUTH_ALG_OPEN) {
		ret = os_snprintf(pos, end - pos, "%sOPEN",
				  pos == buf ? "" : " ");
		if (os_snprintf_error(end - pos, ret)) {
			end[-1] = '\0';
			return buf;
		}
		pos += ret;
	}

	if (ssid->auth_alg & WPA_AUTH_ALG_SHARED) {
		ret = os_snprintf(pos, end - pos, "%sSHARED",
				  pos == buf ? "" : " ");
		if (os_snprintf_error(end - pos, ret)) {
			end[-1] = '\0';
			return buf;
		}
		pos += ret;
	}

	if (ssid->auth_alg & WPA_AUTH_ALG_LEAP) {
		ret = os_snprintf(pos, end - pos, "%sLEAP",
				  pos == buf ? "" : " ");
		if (os_snprintf_error(end - pos, ret)) {
			end[-1] = '\0';
			return buf;
		}
		pos += ret;
	}

	if (pos == buf) {
		os_free(buf);
		buf = NULL;
	}

	return buf;
}
#endif /* NO_CONFIG_WRITE */


static int * wpa_config_parse_int_array(const char *value)
{
	int *freqs;
	size_t used, len;
	const char *pos;

	used = 0;
	len = 10;
	freqs = os_calloc(len + 1, sizeof(int));
	if (freqs == NULL)
		return NULL;

	pos = value;
	while (pos) {
		while (*pos == ' ')
			pos++;
		if (used == len) {
			int *n;
			size_t i;
			n = os_realloc_array(freqs, len * 2 + 1, sizeof(int));
			if (n == NULL) {
				os_free(freqs);
				return NULL;
			}
			for (i = len; i <= len * 2; i++)
				n[i] = 0;
			freqs = n;
			len *= 2;
		}

		freqs[used] = atoi(pos);
		if (freqs[used] == 0)
			break;
		used++;
		pos = os_strchr(pos + 1, ' ');
	}

	return freqs;
}


static int wpa_config_parse_scan_freq(const struct parse_data *data,
				      struct wpa_ssid *ssid, int line,
				      const char *value)
{
	int *freqs;

	freqs = wpa_config_parse_int_array(value);
	if (freqs == NULL)
		return -1;
	if (freqs[0] == 0) {
		os_free(freqs);
		freqs = NULL;
	}
	os_free(ssid->scan_freq);
	ssid->scan_freq = freqs;

	return 0;
}


static int wpa_config_parse_freq_list(const struct parse_data *data,
				      struct wpa_ssid *ssid, int line,
				      const char *value)
{
	int *freqs;

	freqs = wpa_config_parse_int_array(value);
	if (freqs == NULL)
		return -1;
	if (freqs[0] == 0) {
		os_free(freqs);
		freqs = NULL;
	}
	os_free(ssid->freq_list);
	ssid->freq_list = freqs;

	return 0;
}


#ifndef NO_CONFIG_WRITE
static char * wpa_config_write_freqs(const struct parse_data *data,
				     const int *freqs)
{
	char *buf, *pos, *end;
	int i, ret;
	size_t count;

	if (freqs == NULL)
		return NULL;

	count = 0;
	for (i = 0; freqs[i]; i++)
		count++;

	pos = buf = os_zalloc(10 * count + 1);
	if (buf == NULL)
		return NULL;
	end = buf + 10 * count + 1;

	for (i = 0; freqs[i]; i++) {
		ret = os_snprintf(pos, end - pos, "%s%u",
				  i == 0 ? "" : " ", freqs[i]);
		if (os_snprintf_error(end - pos, ret)) {
			end[-1] = '\0';
			return buf;
		}
		pos += ret;
	}

	return buf;
}


static char * wpa_config_write_scan_freq(const struct parse_data *data,
					 struct wpa_ssid *ssid)
{
	return wpa_config_write_freqs(data, ssid->scan_freq);
}


static char * wpa_config_write_freq_list(const struct parse_data *data,
					 struct wpa_ssid *ssid)
{
	return wpa_config_write_freqs(data, ssid->freq_list);
}
#endif /* NO_CONFIG_WRITE */


#ifdef IEEE8021X_EAPOL
static int wpa_config_parse_eap(const struct parse_data *data,
				struct wpa_ssid *ssid, int line,
				const char *value)
{
	int last, errors = 0;
	char *start, *end, *buf;
	struct eap_method_type *methods = NULL, *tmp;
	size_t num_methods = 0;

	buf = os_strdup(value);
	if (buf == NULL)
		return -1;
	start = buf;

	while (*start != '\0') {
		while (*start == ' ' || *start == '\t')
			start++;
		if (*start == '\0')
			break;
		end = start;
		while (*end != ' ' && *end != '\t' && *end != '\0')
			end++;
		last = *end == '\0';
		*end = '\0';
		tmp = methods;
		methods = os_realloc_array(methods, num_methods + 1,
					   sizeof(*methods));
		if (methods == NULL) {
			os_free(tmp);
			os_free(buf);
			return -1;
		}
		methods[num_methods].method = eap_peer_get_type(
			start, &methods[num_methods].vendor);
		if (methods[num_methods].vendor == EAP_VENDOR_IETF &&
		    methods[num_methods].method == EAP_TYPE_NONE) {
			wpa_printf(MSG_ERROR, "Line %d: unknown EAP method "
				   "'%s'", line, start);
			wpa_printf(MSG_ERROR, "You may need to add support for"
				   " this EAP method during wpa_supplicant\n"
				   "build time configuration.\n"
				   "See README for more information.");
			errors++;
		} else if (methods[num_methods].vendor == EAP_VENDOR_IETF &&
			   methods[num_methods].method == EAP_TYPE_LEAP)
			ssid->leap++;
		else
			ssid->non_leap++;
		num_methods++;
		if (last)
			break;
		start = end + 1;
	}
	os_free(buf);

	tmp = methods;
	methods = os_realloc_array(methods, num_methods + 1, sizeof(*methods));
	if (methods == NULL) {
		os_free(tmp);
		return -1;
	}
	methods[num_methods].vendor = EAP_VENDOR_IETF;
	methods[num_methods].method = EAP_TYPE_NONE;
	num_methods++;

	if (!errors && ssid->eap.eap_methods) {
		struct eap_method_type *prev_m;
		size_t i, j, prev_methods, match = 0;

		prev_m = ssid->eap.eap_methods;
		for (i = 0; prev_m[i].vendor != EAP_VENDOR_IETF ||
			     prev_m[i].method != EAP_TYPE_NONE; i++) {
			/* Count the methods */
		}
		prev_methods = i + 1;

		for (i = 0; prev_methods == num_methods && i < prev_methods;
		     i++) {
			for (j = 0; j < num_methods; j++) {
				if (prev_m[i].vendor == methods[j].vendor &&
				    prev_m[i].method == methods[j].method) {
					match++;
					break;
				}
			}
		}
		if (match == num_methods) {
			os_free(methods);
			return 1;
		}
	}
	wpa_hexdump(MSG_MSGDUMP, "eap methods",
		    (u8 *) methods, num_methods * sizeof(*methods));
	os_free(ssid->eap.eap_methods);
	ssid->eap.eap_methods = methods;
	return errors ? -1 : 0;
}


#ifndef NO_CONFIG_WRITE
static char * wpa_config_write_eap(const struct parse_data *data,
				   struct wpa_ssid *ssid)
{
	int i, ret;
	char *buf, *pos, *end;
	const struct eap_method_type *eap_methods = ssid->eap.eap_methods;
	const char *name;

	if (eap_methods == NULL)
		return NULL;

	pos = buf = os_zalloc(100);
	if (buf == NULL)
		return NULL;
	end = buf + 100;

	for (i = 0; eap_methods[i].vendor != EAP_VENDOR_IETF ||
		     eap_methods[i].method != EAP_TYPE_NONE; i++) {
		name = eap_get_name(eap_methods[i].vendor,
				    eap_methods[i].method);
		if (name) {
			ret = os_snprintf(pos, end - pos, "%s%s",
					  pos == buf ? "" : " ", name);
			if (os_snprintf_error(end - pos, ret))
				break;
			pos += ret;
		}
	}

	end[-1] = '\0';

	return buf;
}
#endif /* NO_CONFIG_WRITE */


static int wpa_config_parse_password(const struct parse_data *data,
				     struct wpa_ssid *ssid, int line,
				     const char *value)
{
	u8 *hash;

	if (os_strcmp(value, "NULL") == 0) {
		if (!ssid->eap.password)
			return 1; /* Already unset */
		wpa_printf(MSG_DEBUG, "Unset configuration string 'password'");
		bin_clear_free(ssid->eap.password, ssid->eap.password_len);
		ssid->eap.password = NULL;
		ssid->eap.password_len = 0;
		return 0;
	}

#ifdef CONFIG_EXT_PASSWORD
	if (os_strncmp(value, "ext:", 4) == 0) {
		char *name = os_strdup(value + 4);
		if (name == NULL)
			return -1;
		bin_clear_free(ssid->eap.password, ssid->eap.password_len);
		ssid->eap.password = (u8 *) name;
		ssid->eap.password_len = os_strlen(name);
		ssid->eap.flags &= ~EAP_CONFIG_FLAGS_PASSWORD_NTHASH;
		ssid->eap.flags |= EAP_CONFIG_FLAGS_EXT_PASSWORD;
		return 0;
	}
#endif /* CONFIG_EXT_PASSWORD */

	if (os_strncmp(value, "hash:", 5) != 0) {
		char *tmp;
		size_t res_len;

		tmp = wpa_config_parse_string(value, &res_len);
		if (tmp == NULL) {
			wpa_printf(MSG_ERROR, "Line %d: failed to parse "
				   "password.", line);
			return -1;
		}
		wpa_hexdump_ascii_key(MSG_MSGDUMP, data->name,
				      (u8 *) tmp, res_len);

		bin_clear_free(ssid->eap.password, ssid->eap.password_len);
		ssid->eap.password = (u8 *) tmp;
		ssid->eap.password_len = res_len;
		ssid->eap.flags &= ~EAP_CONFIG_FLAGS_PASSWORD_NTHASH;
		ssid->eap.flags &= ~EAP_CONFIG_FLAGS_EXT_PASSWORD;

		return 0;
	}


	/* NtPasswordHash: hash:<32 hex digits> */
	if (os_strlen(value + 5) != 2 * 16) {
		wpa_printf(MSG_ERROR, "Line %d: Invalid password hash length "
			   "(expected 32 hex digits)", line);
		return -1;
	}

	hash = os_malloc(16);
	if (hash == NULL)
		return -1;

	if (hexstr2bin(value + 5, hash, 16)) {
		os_free(hash);
		wpa_printf(MSG_ERROR, "Line %d: Invalid password hash", line);
		return -1;
	}

	wpa_hexdump_key(MSG_MSGDUMP, data->name, hash, 16);

	if (ssid->eap.password && ssid->eap.password_len == 16 &&
	    os_memcmp(ssid->eap.password, hash, 16) == 0 &&
	    (ssid->eap.flags & EAP_CONFIG_FLAGS_PASSWORD_NTHASH)) {
		bin_clear_free(hash, 16);
		return 1;
	}
	bin_clear_free(ssid->eap.password, ssid->eap.password_len);
	ssid->eap.password = hash;
	ssid->eap.password_len = 16;
	ssid->eap.flags |= EAP_CONFIG_FLAGS_PASSWORD_NTHASH;
	ssid->eap.flags &= ~EAP_CONFIG_FLAGS_EXT_PASSWORD;

	return 0;
}


#ifndef NO_CONFIG_WRITE
static char * wpa_config_write_password(const struct parse_data *data,
					struct wpa_ssid *ssid)
{
	char *buf;

	if (ssid->eap.password == NULL)
		return NULL;

#ifdef CONFIG_EXT_PASSWORD
	if (ssid->eap.flags & EAP_CONFIG_FLAGS_EXT_PASSWORD) {
		buf = os_zalloc(4 + ssid->eap.password_len + 1);
		if (buf == NULL)
			return NULL;
		os_memcpy(buf, "ext:", 4);
		os_memcpy(buf + 4, ssid->eap.password, ssid->eap.password_len);
		return buf;
	}
#endif /* CONFIG_EXT_PASSWORD */

	if (!(ssid->eap.flags & EAP_CONFIG_FLAGS_PASSWORD_NTHASH)) {
		return wpa_config_write_string(
			ssid->eap.password, ssid->eap.password_len);
	}

	buf = os_malloc(5 + 32 + 1);
	if (buf == NULL)
		return NULL;

	os_memcpy(buf, "hash:", 5);
	wpa_snprintf_hex(buf + 5, 32 + 1, ssid->eap.password, 16);

	return buf;
}
#endif /* NO_CONFIG_WRITE */
#endif /* IEEE8021X_EAPOL */


static int wpa_config_parse_wep_key(u8 *key, size_t *len, int line,
				    const char *value, int idx)
{
	char *buf, title[20];
	int res;

	buf = wpa_config_parse_string(value, len);
	if (buf == NULL) {
		wpa_printf(MSG_ERROR, "Line %d: Invalid WEP key %d '%s'.",
			   line, idx, value);
		return -1;
	}
	if (*len > MAX_WEP_KEY_LEN) {
		wpa_printf(MSG_ERROR, "Line %d: Too long WEP key %d '%s'.",
			   line, idx, value);
		os_free(buf);
		return -1;
	}
	if (*len && *len != 5 && *len != 13 && *len != 16) {
		wpa_printf(MSG_ERROR, "Line %d: Invalid WEP key length %u - "
			   "this network block will be ignored",
			   line, (unsigned int) *len);
	}
	os_memcpy(key, buf, *len);
	str_clear_free(buf);
	res = os_snprintf(title, sizeof(title), "wep_key%d", idx);
	if (!os_snprintf_error(sizeof(title), res))
		wpa_hexdump_key(MSG_MSGDUMP, title, key, *len);
	return 0;
}


static int wpa_config_parse_wep_key0(const struct parse_data *data,
				     struct wpa_ssid *ssid, int line,
				     const char *value)
{
	return wpa_config_parse_wep_key(ssid->wep_key[0],
					&ssid->wep_key_len[0], line,
					value, 0);
}


static int wpa_config_parse_wep_key1(const struct parse_data *data,
				     struct wpa_ssid *ssid, int line,
				     const char *value)
{
	return wpa_config_parse_wep_key(ssid->wep_key[1],
					&ssid->wep_key_len[1], line,
					value, 1);
}


static int wpa_config_parse_wep_key2(const struct parse_data *data,
				     struct wpa_ssid *ssid, int line,
				     const char *value)
{
	return wpa_config_parse_wep_key(ssid->wep_key[2],
					&ssid->wep_key_len[2], line,
					value, 2);
}


static int wpa_config_parse_wep_key3(const struct parse_data *data,
				     struct wpa_ssid *ssid, int line,
				     const char *value)
{
	return wpa_config_parse_wep_key(ssid->wep_key[3],
					&ssid->wep_key_len[3], line,
					value, 3);
}


#ifndef NO_CONFIG_WRITE
static char * wpa_config_write_wep_key(struct wpa_ssid *ssid, int idx)
{
	if (ssid->wep_key_len[idx] == 0)
		return NULL;
	return wpa_config_write_string(ssid->wep_key[idx],
				       ssid->wep_key_len[idx]);
}


static char * wpa_config_write_wep_key0(const struct parse_data *data,
					struct wpa_ssid *ssid)
{
	return wpa_config_write_wep_key(ssid, 0);
}


static char * wpa_config_write_wep_key1(const struct parse_data *data,
					struct wpa_ssid *ssid)
{
	return wpa_config_write_wep_key(ssid, 1);
}


static char * wpa_config_write_wep_key2(const struct parse_data *data,
					struct wpa_ssid *ssid)
{
	return wpa_config_write_wep_key(ssid, 2);
}


static char * wpa_config_write_wep_key3(const struct parse_data *data,
					struct wpa_ssid *ssid)
{
	return wpa_config_write_wep_key(ssid, 3);
}
#endif /* NO_CONFIG_WRITE */


#ifdef CONFIG_P2P

static int wpa_config_parse_go_p2p_dev_addr(const struct parse_data *data,
					    struct wpa_ssid *ssid, int line,
					    const char *value)
{
	if (value[0] == '\0' || os_strcmp(value, "\"\"") == 0 ||
	    os_strcmp(value, "any") == 0) {
		os_memset(ssid->go_p2p_dev_addr, 0, ETH_ALEN);
		wpa_printf(MSG_MSGDUMP, "GO P2P Device Address any");
		return 0;
	}
	if (hwaddr_aton(value, ssid->go_p2p_dev_addr)) {
		wpa_printf(MSG_ERROR, "Line %d: Invalid GO P2P Device Address '%s'.",
			   line, value);
		return -1;
	}
	ssid->bssid_set = 1;
	wpa_printf(MSG_MSGDUMP, "GO P2P Device Address " MACSTR,
		   MAC2STR(ssid->go_p2p_dev_addr));
	return 0;
}


#ifndef NO_CONFIG_WRITE
static char * wpa_config_write_go_p2p_dev_addr(const struct parse_data *data,
					       struct wpa_ssid *ssid)
{
	char *value;
	int res;

	if (is_zero_ether_addr(ssid->go_p2p_dev_addr))
		return NULL;

	value = os_malloc(20);
	if (value == NULL)
		return NULL;
	res = os_snprintf(value, 20, MACSTR, MAC2STR(ssid->go_p2p_dev_addr));
	if (os_snprintf_error(20, res)) {
		os_free(value);
		return NULL;
	}
	value[20 - 1] = '\0';
	return value;
}
#endif /* NO_CONFIG_WRITE */


static int wpa_config_parse_p2p_client_list(const struct parse_data *data,
					    struct wpa_ssid *ssid, int line,
					    const char *value)
{
	return wpa_config_parse_addr_list(data, line, value,
					  &ssid->p2p_client_list,
					  &ssid->num_p2p_clients,
					  "p2p_client_list", 0, 0);
}


#ifndef NO_CONFIG_WRITE
static char * wpa_config_write_p2p_client_list(const struct parse_data *data,
					       struct wpa_ssid *ssid)
{
	return wpa_config_write_addr_list(data, ssid->p2p_client_list,
					  ssid->num_p2p_clients,
					  "p2p_client_list");
}
#endif /* NO_CONFIG_WRITE */


static int wpa_config_parse_psk_list(const struct parse_data *data,
				     struct wpa_ssid *ssid, int line,
				     const char *value)
{
	struct psk_list_entry *p;
	const char *pos;

	p = os_zalloc(sizeof(*p));
	if (p == NULL)
		return -1;

	pos = value;
	if (os_strncmp(pos, "P2P-", 4) == 0) {
		p->p2p = 1;
		pos += 4;
	}

	if (hwaddr_aton(pos, p->addr)) {
		wpa_printf(MSG_ERROR, "Line %d: Invalid psk_list address '%s'",
			   line, pos);
		os_free(p);
		return -1;
	}
	pos += 17;
	if (*pos != '-') {
		wpa_printf(MSG_ERROR, "Line %d: Invalid psk_list '%s'",
			   line, pos);
		os_free(p);
		return -1;
	}
	pos++;

	if (hexstr2bin(pos, p->psk, PMK_LEN) || pos[PMK_LEN * 2] != '\0') {
		wpa_printf(MSG_ERROR, "Line %d: Invalid psk_list PSK '%s'",
			   line, pos);
		os_free(p);
		return -1;
	}

	dl_list_add(&ssid->psk_list, &p->list);

	return 0;
}


#ifndef NO_CONFIG_WRITE
static char * wpa_config_write_psk_list(const struct parse_data *data,
					struct wpa_ssid *ssid)
{
	return NULL;
}
#endif /* NO_CONFIG_WRITE */

#endif /* CONFIG_P2P */


#ifdef CONFIG_MESH

static int wpa_config_parse_mesh_basic_rates(const struct parse_data *data,
					     struct wpa_ssid *ssid, int line,
					     const char *value)
{
	int *rates = wpa_config_parse_int_array(value);

	if (rates == NULL) {
		wpa_printf(MSG_ERROR, "Line %d: Invalid mesh_basic_rates '%s'",
			   line, value);
		return -1;
	}
	if (rates[0] == 0) {
		os_free(rates);
		rates = NULL;
	}

	os_free(ssid->mesh_basic_rates);
	ssid->mesh_basic_rates = rates;

	return 0;
}


#ifndef NO_CONFIG_WRITE

static char * wpa_config_write_mesh_basic_rates(const struct parse_data *data,
						struct wpa_ssid *ssid)
{
	return wpa_config_write_freqs(data, ssid->mesh_basic_rates);
}

#endif /* NO_CONFIG_WRITE */

#endif /* CONFIG_MESH */


#ifdef CONFIG_MACSEC

static int wpa_config_parse_mka_cak(const struct parse_data *data,
				    struct wpa_ssid *ssid, int line,
				    const char *value)
{
	size_t len;

	len = os_strlen(value);
	if (len > 2 * MACSEC_CAK_MAX_LEN ||
	    (len != 2 * 16 && len != 2 * 32) ||
	    hexstr2bin(value, ssid->mka_cak, len / 2)) {
		wpa_printf(MSG_ERROR, "Line %d: Invalid MKA-CAK '%s'.",
			   line, value);
		return -1;
	}
	ssid->mka_cak_len = len / 2;
	ssid->mka_psk_set |= MKA_PSK_SET_CAK;

	wpa_hexdump_key(MSG_MSGDUMP, "MKA-CAK", ssid->mka_cak,
			ssid->mka_cak_len);
	return 0;
}


static int wpa_config_parse_mka_ckn(const struct parse_data *data,
				    struct wpa_ssid *ssid, int line,
				    const char *value)
{
	size_t len;

	len = os_strlen(value);
	if (len > 2 * MACSEC_CKN_MAX_LEN || /* too long */
	    len < 2 || /* too short */
	    len % 2 != 0 /* not an integral number of bytes */) {
		wpa_printf(MSG_ERROR, "Line %d: Invalid MKA-CKN '%s'.",
			   line, value);
		return -1;
	}
	ssid->mka_ckn_len = len / 2;
	if (hexstr2bin(value, ssid->mka_ckn, ssid->mka_ckn_len)) {
		wpa_printf(MSG_ERROR, "Line %d: Invalid MKA-CKN '%s'.",
			   line, value);
		return -1;
	}

	ssid->mka_psk_set |= MKA_PSK_SET_CKN;

	wpa_hexdump_key(MSG_MSGDUMP, "MKA-CKN", ssid->mka_ckn,
			ssid->mka_ckn_len);
	return 0;
}


#ifndef NO_CONFIG_WRITE

static char * wpa_config_write_mka_cak(const struct parse_data *data,
				       struct wpa_ssid *ssid)
{
	if (!(ssid->mka_psk_set & MKA_PSK_SET_CAK))
		return NULL;

	return wpa_config_write_string_hex(ssid->mka_cak, ssid->mka_cak_len);
}


static char * wpa_config_write_mka_ckn(const struct parse_data *data,
				       struct wpa_ssid *ssid)
{
	if (!(ssid->mka_psk_set & MKA_PSK_SET_CKN))
		return NULL;
	return wpa_config_write_string_hex(ssid->mka_ckn, ssid->mka_ckn_len);
}

#endif /* NO_CONFIG_WRITE */

#endif /* CONFIG_MACSEC */


#ifdef CONFIG_OCV

static int wpa_config_parse_ocv(const struct parse_data *data,
				struct wpa_ssid *ssid, int line,
				const char *value)
{
	char *end;

	ssid->ocv = strtol(value, &end, 0);
	if (*end || ssid->ocv < 0 || ssid->ocv > 1) {
		wpa_printf(MSG_ERROR, "Line %d: Invalid ocv value '%s'.",
			   line, value);
		return -1;
	}
	if (ssid->ocv && ssid->ieee80211w == NO_MGMT_FRAME_PROTECTION)
		ssid->ieee80211w = MGMT_FRAME_PROTECTION_OPTIONAL;
	return 0;
}


#ifndef NO_CONFIG_WRITE
static char * wpa_config_write_ocv(const struct parse_data *data,
				   struct wpa_ssid *ssid)
{
	char *value = os_malloc(20);

	if (!value)
		return NULL;
	os_snprintf(value, 20, "%d", ssid->ocv);
	value[20 - 1] = '\0';
	return value;
}
#endif /* NO_CONFIG_WRITE */

#endif /* CONFIG_OCV */


static int wpa_config_parse_peerkey(const struct parse_data *data,
				    struct wpa_ssid *ssid, int line,
				    const char *value)
{
	wpa_printf(MSG_INFO, "NOTE: Obsolete peerkey parameter ignored");
	return 0;
}


#ifndef NO_CONFIG_WRITE
static char * wpa_config_write_peerkey(const struct parse_data *data,
				       struct wpa_ssid *ssid)
{
	return NULL;
}
#endif /* NO_CONFIG_WRITE */


/* Helper macros for network block parser */

#ifdef OFFSET
#undef OFFSET
#endif /* OFFSET */
/* OFFSET: Get offset of a variable within the wpa_ssid structure */
#define OFFSET(v) ((void *) &((struct wpa_ssid *) 0)->v)

/* STR: Define a string variable for an ASCII string; f = field name */
#ifdef NO_CONFIG_WRITE
#define _STR(f) #f, wpa_config_parse_str, OFFSET(f)
#define _STRe(f) #f, wpa_config_parse_str, OFFSET(eap.f)
#else /* NO_CONFIG_WRITE */
#define _STR(f) #f, wpa_config_parse_str, wpa_config_write_str, OFFSET(f)
#define _STRe(f) #f, wpa_config_parse_str, wpa_config_write_str, OFFSET(eap.f)
#endif /* NO_CONFIG_WRITE */
#define STR(f) _STR(f), NULL, NULL, NULL, 0
#define STRe(f) _STRe(f), NULL, NULL, NULL, 0
#define STR_KEY(f) _STR(f), NULL, NULL, NULL, 1
#define STR_KEYe(f) _STRe(f), NULL, NULL, NULL, 1

/* STR_LEN: Define a string variable with a separate variable for storing the
 * data length. Unlike STR(), this can be used to store arbitrary binary data
 * (i.e., even nul termination character). */
#define _STR_LEN(f) _STR(f), OFFSET(f ## _len)
#define _STR_LENe(f) _STRe(f), OFFSET(eap.f ## _len)
#define STR_LEN(f) _STR_LEN(f), NULL, NULL, 0
#define STR_LENe(f) _STR_LENe(f), NULL, NULL, 0
#define STR_LEN_KEY(f) _STR_LEN(f), NULL, NULL, 1

/* STR_RANGE: Like STR_LEN(), but with minimum and maximum allowed length
 * explicitly specified. */
#define _STR_RANGE(f, min, max) _STR_LEN(f), (void *) (min), (void *) (max)
#define STR_RANGE(f, min, max) _STR_RANGE(f, min, max), 0
#define STR_RANGE_KEY(f, min, max) _STR_RANGE(f, min, max), 1

#ifdef NO_CONFIG_WRITE
#define _INT(f) #f, wpa_config_parse_int, OFFSET(f), (void *) 0
#define _INTe(f) #f, wpa_config_parse_int, OFFSET(eap.f), (void *) 0
#else /* NO_CONFIG_WRITE */
#define _INT(f) #f, wpa_config_parse_int, wpa_config_write_int, \
	OFFSET(f), (void *) 0
#define _INTe(f) #f, wpa_config_parse_int, wpa_config_write_int, \
	OFFSET(eap.f), (void *) 0
#endif /* NO_CONFIG_WRITE */

/* INT: Define an integer variable */
#define INT(f) _INT(f), NULL, NULL, 0
#define INTe(f) _INTe(f), NULL, NULL, 0

/* INT_RANGE: Define an integer variable with allowed value range */
#define INT_RANGE(f, min, max) _INT(f), (void *) (min), (void *) (max), 0

/* FUNC: Define a configuration variable that uses a custom function for
 * parsing and writing the value. */
#ifdef NO_CONFIG_WRITE
#define _FUNC(f) #f, wpa_config_parse_ ## f, NULL, NULL, NULL, NULL
#else /* NO_CONFIG_WRITE */
#define _FUNC(f) #f, wpa_config_parse_ ## f, wpa_config_write_ ## f, \
	NULL, NULL, NULL, NULL
#endif /* NO_CONFIG_WRITE */
#define FUNC(f) _FUNC(f), 0
#define FUNC_KEY(f) _FUNC(f), 1

/*
 * Table of network configuration variables. This table is used to parse each
 * network configuration variable, e.g., each line in wpa_supplicant.conf file
 * that is inside a network block.
 *
 * This table is generated using the helper macros defined above and with
 * generous help from the C pre-processor. The field name is stored as a string
 * into .name and for STR and INT types, the offset of the target buffer within
 * struct wpa_ssid is stored in .param1. .param2 (if not NULL) is similar
 * offset to the field containing the length of the configuration variable.
 * .param3 and .param4 can be used to mark the allowed range (length for STR
 * and value for INT).
 *
 * For each configuration line in wpa_supplicant.conf, the parser goes through
 * this table and select the entry that matches with the field name. The parser
 * function (.parser) is then called to parse the actual value of the field.
 *
 * This kind of mechanism makes it easy to add new configuration parameters,
 * since only one line needs to be added into this table and into the
 * struct wpa_ssid definition if the new variable is either a string or
 * integer. More complex types will need to use their own parser and writer
 * functions.
 */
static const struct parse_data ssid_fields[] = {
	{ STR_RANGE(ssid, 0, SSID_MAX_LEN) },
	{ INT_RANGE(scan_ssid, 0, 1) },
	{ FUNC(bssid) },
	{ FUNC(bssid_hint) },
	{ FUNC(bssid_blacklist) },
	{ FUNC(bssid_whitelist) },
	{ FUNC_KEY(psk) },
	{ INT(mem_only_psk) },
	{ STR_KEY(sae_password) },
	{ STR(sae_password_id) },
	{ FUNC(proto) },
	{ FUNC(key_mgmt) },
	{ INT(bg_scan_period) },
	{ FUNC(pairwise) },
	{ FUNC(group) },
	{ FUNC(group_mgmt) },
	{ FUNC(auth_alg) },
	{ FUNC(scan_freq) },
	{ FUNC(freq_list) },
	{ INT_RANGE(ht, 0, 1) },
	{ INT_RANGE(vht, 0, 1) },
	{ INT_RANGE(ht40, -1, 1) },
	{ INT_RANGE(max_oper_chwidth, VHT_CHANWIDTH_USE_HT,
		    VHT_CHANWIDTH_80P80MHZ) },
	{ INT(vht_center_freq1) },
	{ INT(vht_center_freq2) },
#ifdef IEEE8021X_EAPOL
	{ FUNC(eap) },
	{ STR_LENe(identity) },
	{ STR_LENe(anonymous_identity) },
	{ STR_LENe(imsi_identity) },
	{ FUNC_KEY(password) },
	{ STRe(ca_cert) },
	{ STRe(ca_path) },
	{ STRe(client_cert) },
	{ STRe(private_key) },
	{ STR_KEYe(private_key_passwd) },
	{ STRe(dh_file) },
	{ STRe(subject_match) },
	{ STRe(check_cert_subject) },
	{ STRe(altsubject_match) },
	{ STRe(domain_suffix_match) },
	{ STRe(domain_match) },
	{ STRe(ca_cert2) },
	{ STRe(ca_path2) },
	{ STRe(client_cert2) },
	{ STRe(private_key2) },
	{ STR_KEYe(private_key2_passwd) },
	{ STRe(dh_file2) },
	{ STRe(subject_match2) },
	{ STRe(check_cert_subject2) },
	{ STRe(altsubject_match2) },
	{ STRe(domain_suffix_match2) },
	{ STRe(domain_match2) },
	{ STRe(phase1) },
	{ STRe(phase2) },
	{ STRe(pcsc) },
	{ STR_KEYe(pin) },
	{ STRe(engine_id) },
	{ STRe(key_id) },
	{ STRe(cert_id) },
	{ STRe(ca_cert_id) },
	{ STR_KEYe(pin2) },
	{ STRe(engine2_id) },
	{ STRe(key2_id) },
	{ STRe(cert2_id) },
	{ STRe(ca_cert2_id) },
	{ INTe(engine) },
	{ INTe(engine2) },
	{ INT(eapol_flags) },
	{ INTe(sim_num) },
	{ STRe(openssl_ciphers) },
	{ INTe(erp) },
#endif /* IEEE8021X_EAPOL */
	{ FUNC_KEY(wep_key0) },
	{ FUNC_KEY(wep_key1) },
	{ FUNC_KEY(wep_key2) },
	{ FUNC_KEY(wep_key3) },
	{ INT(wep_tx_keyidx) },
	{ INT(priority) },
#ifdef IEEE8021X_EAPOL
	{ INT(eap_workaround) },
	{ STRe(pac_file) },
	{ INTe(fragment_size) },
	{ INTe(ocsp) },
#endif /* IEEE8021X_EAPOL */
#ifdef CONFIG_MESH
	{ INT_RANGE(mode, 0, 5) },
	{ INT_RANGE(no_auto_peer, 0, 1) },
	{ INT_RANGE(mesh_rssi_threshold, -255, 1) },
#else /* CONFIG_MESH */
	{ INT_RANGE(mode, 0, 4) },
#endif /* CONFIG_MESH */
	{ INT_RANGE(proactive_key_caching, 0, 1) },
	{ INT_RANGE(disabled, 0, 2) },
	{ STR(id_str) },
#ifdef CONFIG_IEEE80211W
	{ INT_RANGE(ieee80211w, 0, 2) },
#endif /* CONFIG_IEEE80211W */
#ifdef CONFIG_OCV
	{ FUNC(ocv) },
#endif /* CONFIG_OCV */
	{ FUNC(peerkey) /* obsolete - removed */ },
	{ INT_RANGE(mixed_cell, 0, 1) },
	{ INT_RANGE(frequency, 0, 65000) },
	{ INT_RANGE(fixed_freq, 0, 1) },
#ifdef CONFIG_ACS
	{ INT_RANGE(acs, 0, 1) },
#endif /* CONFIG_ACS */
#ifdef CONFIG_MESH
	{ FUNC(mesh_basic_rates) },
	{ INT(dot11MeshMaxRetries) },
	{ INT(dot11MeshRetryTimeout) },
	{ INT(dot11MeshConfirmTimeout) },
	{ INT(dot11MeshHoldingTimeout) },
#endif /* CONFIG_MESH */
	{ INT(wpa_ptk_rekey) },
	{ INT(group_rekey) },
	{ STR(bgscan) },
	{ INT_RANGE(ignore_broadcast_ssid, 0, 2) },
#ifdef CONFIG_P2P
	{ FUNC(go_p2p_dev_addr) },
	{ FUNC(p2p_client_list) },
	{ FUNC(psk_list) },
#endif /* CONFIG_P2P */
#ifdef CONFIG_HT_OVERRIDES
	{ INT_RANGE(disable_ht, 0, 1) },
	{ INT_RANGE(disable_ht40, -1, 1) },
	{ INT_RANGE(disable_sgi, 0, 1) },
	{ INT_RANGE(disable_ldpc, 0, 1) },
	{ INT_RANGE(ht40_intolerant, 0, 1) },
	{ INT_RANGE(tx_stbc, -1, 1) },
	{ INT_RANGE(rx_stbc, -1, 3) },
	{ INT_RANGE(disable_max_amsdu, -1, 1) },
	{ INT_RANGE(ampdu_factor, -1, 3) },
	{ INT_RANGE(ampdu_density, -1, 7) },
	{ STR(ht_mcs) },
#endif /* CONFIG_HT_OVERRIDES */
#ifdef CONFIG_VHT_OVERRIDES
	{ INT_RANGE(disable_vht, 0, 1) },
	{ INT(vht_capa) },
	{ INT(vht_capa_mask) },
	{ INT_RANGE(vht_rx_mcs_nss_1, -1, 3) },
	{ INT_RANGE(vht_rx_mcs_nss_2, -1, 3) },
	{ INT_RANGE(vht_rx_mcs_nss_3, -1, 3) },
	{ INT_RANGE(vht_rx_mcs_nss_4, -1, 3) },
	{ INT_RANGE(vht_rx_mcs_nss_5, -1, 3) },
	{ INT_RANGE(vht_rx_mcs_nss_6, -1, 3) },
	{ INT_RANGE(vht_rx_mcs_nss_7, -1, 3) },
	{ INT_RANGE(vht_rx_mcs_nss_8, -1, 3) },
	{ INT_RANGE(vht_tx_mcs_nss_1, -1, 3) },
	{ INT_RANGE(vht_tx_mcs_nss_2, -1, 3) },
	{ INT_RANGE(vht_tx_mcs_nss_3, -1, 3) },
	{ INT_RANGE(vht_tx_mcs_nss_4, -1, 3) },
	{ INT_RANGE(vht_tx_mcs_nss_5, -1, 3) },
	{ INT_RANGE(vht_tx_mcs_nss_6, -1, 3) },
	{ INT_RANGE(vht_tx_mcs_nss_7, -1, 3) },
	{ INT_RANGE(vht_tx_mcs_nss_8, -1, 3) },
#endif /* CONFIG_VHT_OVERRIDES */
	{ INT(ap_max_inactivity) },
	{ INT(dtim_period) },
	{ INT(beacon_int) },
#ifdef CONFIG_MACSEC
	{ INT_RANGE(macsec_policy, 0, 1) },
	{ INT_RANGE(macsec_integ_only, 0, 1) },
	{ INT_RANGE(macsec_replay_protect, 0, 1) },
	{ INT(macsec_replay_window) },
	{ INT_RANGE(macsec_port, 1, 65534) },
	{ INT_RANGE(mka_priority, 0, 255) },
	{ FUNC_KEY(mka_cak) },
	{ FUNC_KEY(mka_ckn) },
#endif /* CONFIG_MACSEC */
#ifdef CONFIG_HS20
	{ INT(update_identifier) },
	{ STR_RANGE(roaming_consortium_selection, 0, MAX_ROAMING_CONS_OI_LEN) },
#endif /* CONFIG_HS20 */
	{ INT_RANGE(mac_addr, 0, 2) },
	{ INT_RANGE(pbss, 0, 2) },
	{ INT_RANGE(wps_disabled, 0, 1) },
	{ INT_RANGE(fils_dh_group, 0, 65535) },
#ifdef CONFIG_DPP
	{ STR(dpp_connector) },
	{ STR_LEN(dpp_netaccesskey) },
	{ INT(dpp_netaccesskey_expiry) },
	{ STR_LEN(dpp_csign) },
#endif /* CONFIG_DPP */
	{ INT_RANGE(owe_group, 0, 65535) },
	{ INT_RANGE(owe_only, 0, 1) },
	{ INT_RANGE(multi_ap_backhaul_sta, 0, 1) },
};

#undef OFFSET
#undef _STR
#undef STR
#undef STR_KEY
#undef _STR_LEN
#undef STR_LEN
#undef STR_LEN_KEY
#undef _STR_RANGE
#undef STR_RANGE
#undef STR_RANGE_KEY
#undef _INT
#undef INT
#undef INT_RANGE
#undef _FUNC
#undef FUNC
#undef FUNC_KEY
#define NUM_SSID_FIELDS ARRAY_SIZE(ssid_fields)


/**
 * wpa_config_add_prio_network - Add a network to priority lists
 * @config: Configuration data from wpa_config_read()
 * @ssid: Pointer to the network configuration to be added to the list
 * Returns: 0 on success, -1 on failure
 *
 * This function is used to add a network block to the priority list of
 * networks. This must be called for each network when reading in the full
 * configuration. In addition, this can be used indirectly when updating
 * priorities by calling wpa_config_update_prio_list().
 */
int wpa_config_add_prio_network(struct wpa_config *config,
				struct wpa_ssid *ssid)
{
	int prio;
	struct wpa_ssid *prev, **nlist;

	/*
	 * Add to an existing priority list if one is avail NULL
#enconfig *coe is avail NULL
#enco4ype0, MAX_ROAs },
	fset to the)indirectly when updating
 * puonfset  && i < t  <X_ROAs ient_liist; < t ethods[i exi &&_ROAs iep to [< t ]LL;
		os exiiepet to th=har *namOL
	{ INT(ds[i ')
			poexiiepnex}
	os_i exi &&oexiiepnex}LL;
	oexiiepnex}char *n; "ext:", 4)EXT_Puf;
}
#ariair *c * confirectly whpet to th-ity list wLL
#enconfig *c
 * nndef NOhods + 1, sizeof(_ROAs iep to ,X_ROAs ient_liist		if (meth;
	if (!: Define a string ssid->ocnndef Ne;
	if (os_strncmp(pos,puonfset  && i < t  <X_ROAs ient_liist; < t ethods[i->ocnndef[< t ]iepet to th<ar *namOL
	{ INT(ds[i 0, ETHll, (&nndef[< t 		if], &nndef[< t ],)
{
	ret(_ROAs ient_liist	- < t )d achar *va	if (!: Define a string ssidend[-1] = 'uf;
}
#nndef[< t ]char *n; "_ROAs ient_liist++; "_ROAs iep to sed] prioritRITE
static chk - Add a network onfig_add_prio_n	- Unfig_c * confiL
#enconfig *rom wpa_config_read()
 * @ssid: Pointer to the network conure
 *
 * This function is used to add a network block to thof the fieonfig_. This must be calledr each ne additihis can be used iallingist of
 *  thbedef N succuoncell, 0twork wvaillsohof theill nstrus must beme */st of
 *  thconfgedwork(struct wpa_confionfig_add_prio_neruct wpa_ssid *ssid)
{
	ionst char *puct wpa_ssid *ddr(ssid-tethods;
	ssid->m_ROAs iep to ); "_ROAs iep to sed", ssid_ROAs ient_liist	thods;
 to sed_ROAs ieid *ddr')
			p{ FUNC{PROTECTIOpnex}cha;
		os_m->oct wpa_config *config,
				st)
{
	in { FUNC<s_strchd-tethSG_MSG to sedp_clienex}LL; wpa_configeturn}int wpa_config_parse_eap(const st a cohods[num_a_confiid->mes = ssid->[num_a_confhods;onst 	ssid->mds;;
}
# = methods;
, ssid->eap.pasds;;
) },
	{ f fi;;
) },
	{ CONFIG_W	ssid->mds;;
e(imsi_identity) },G_W	ssid->mds;;
sword) },
	{ Ss;
, ssid->eap.pasds;;
ndif /* NOds;;
ndif /* CONFIG_W	ssid->mds;;
{ STRe(cG_W	ssid->mds;;
{ S	{ STG_W	ssid->mds;;
{y) },
	{ STG_W	ssid->mds;;
te_key_passw;snprintf(title, sds;;
te_key_pass	{ STRe(G_W	ssid->mds;;
) },
	{ G_W	ssid->mds;;
suffix_match) G_W	ssid->mds;;
{subject_match) },
G_W	ssid->mds;;
en_suffix_match) G_W	ssid->mds;;
)main_match) },
	{ SG_W	ssid->mds;;
)main_match) G_W	ssid->mds;;
{	{ STRe(G_W	ssid->mds;;
{ S	{ Se(G_W	ssid->mds;;
{ey2) },
	{ SG_W	ssid->mds;;
te_key_pass2w;snprintf(title, sds;;
te_key_pass2	{ STRe(G_W	ssid->mds;;
) },
	{ SG_W	ssid->mds;;
_suffix_match2)G_W	ssid->mds;;
{subject_match) },2)G_W	ssid->mds;;
ain_suffix_match2)G_W	ssid->mds;;
)main_match) },
	{ 2)G_W	ssid->mds;;
)main_m,
	{ 2)G_W	ssid->mds;;
STRe(pcG_W	ssid->mds;;
STRe(2)G_W	ssid->mds;;
SRe(e;snprintf(title, sds;;
tiFIG_W	ssid->mds;;
	{ STRe(ceG_W	ssid->mds;;
 STRe(cG_W	ssid->mds;;
{{ STRe(G_W	ssid->mds;;
{	{ STRe(ceG_W	ssid->mds;;
 ST2Re(cG_W	ssid->mds;;
{{ S2Re(cG_W	ssid->mds;;
{
	{ INTe(en;snprintf(title, sds;;
tiF2)G_W	ssid->mds;;
,
	{ STRe(cG_W	ssid->mds;;
otp)G_W	ssid->mds;;
SGE(on netq_otp)G_W	ssid->mds;;
S) },
	{ s;
, ssid->eap.pasds;;
t w_ndif /* NOds;;
t w_ndif /* ;
	ssid->rintf(title, sds;;
ex}erna
#uimnetsp)G_W	ssid->mds;;
},
#endif /* IEE

/* Helper mapa_config_parse_wep_kk - Add a network id-> wpa_s- Fd->st of
 */wpa_sc_read()
 * @ssid: configuratg_read()
 * @ssid: Po4ype0st of
 *dd a network block toid->ailllrn Nourc>ailllocned aPo4ype0st of
 *sc_read()
 * @is can bwork(s a co a network id-> wpa_{
	if (ssid->wep_key_lonst char *pos;

	p = os_zallskds;
	ssid->mp_clie to ); ">rintf(title, sTECTIOpdifphrRe()G_W	ssid->mTECTIOex} },
	; ">rintf(title, sTECTIOord_id) },
	{G_W	ssid->mTECTIO) },
	{ FUNC(key;p_workaround) },
	{ STRe(hods[num_a_confiid->murn 0;
ds;o;FUNC_KEY(wep_key0) },
	{ FUNC_K	ssid->mTECTIO1W
	{ IG_W	ssid->mTECTIO)qs;

	returnfreq_list = freqs;

	returnfreq_list = froadcasturnfreq_list = frist) },
#endif /urnfreq_list = frowhitelist) },
	urnfreq_list = frowhite
	{ INT(me;T_RANGE(disable_ht, 0, 1) },
freq_list = frERRIDES;
#ifdef CONFIG_VHT_OVERRIDES
	{ INT_RANGE(disabl
	{ IN	ssid->mesh_basic_rates = rates;
pa_ptk_rekey) },
	{ INT(gidentifier) },
	{ ST	ssid->mesh_baMAX_ROAMING_CONS_OI_LEN) },
S;
#ifdef CONFIG_VHT_2) },
	{	ssid->mesh_banetaccesskey) s;
, ssid->eap.pasesh_banetaN(dpp_csign)0';
	retR_LEN(dpp_csign) ONFIG_W	ssid->mesh_banetac	{ INddr')
			pP */sedlist);

fir *turn 0;
}


#ifndechar *pos;

	p = os_z,)
{
	rete cal)e %d: Ilist);

del(&os;NO_CONFIGurn 1;
	}
	bin_cl != 'turn -1;
,
	
	str_c, ssid->eap.pasesh_ 'turn -1; to )rite_mk a co a network id-> cre_{
	if (ssid-cre_id)re_n(value);
	iids;
	ssid->m_re_baM + m	; ">rintf(title, s_re_bausernaNFIG_F>rintf(title, s_re_baid) },
	{G_W	ssid->m_re_ba{ STRe(cG_W	ssid->m_re_ba{y) },
	{ STG_W	ssid->m_re_baie_key_passw;snprintf(title, s_re_baie_key_pass	{ STRe(G_W	ssid->m_re_basworw;snprintf(title, s_re_bam
		nagFIG_F != EAP_VEND		fo_re_bant_l)main_s_zalloc(	ssid->m_re_ba)main_ - pos,	ssid->m_re_ba)main_pos,	ssid->m_re_ba)main_match) },
	{ SG_W	ssid->m_re_ba}
# = methTG_W	ssid->m_re_baiTRe(pcG_W	ssid->m_re_baiTRe(2SG_W	ssid->m_re_ba}xclusuc_ to ); "	ssid->m_re_baMAX_ROAMpartnerTG_W	ssid->m_re_baieovis},
ROAMsp)G_W != EAP_VEND		fo_re_bant_lqs;
ccesx_mcsbs_zalloc(	ssid->m_re_baqs;
ccesx_mcsbmka_p - pos,	ssid->m_re_baqs;
ccesx_mcsbmka_ppos,	ssid->m_re_baqs;
ccesx_mcsbmkINT(bos,	ssid->m_re_rite_mk a co a network iluc_ralobseruct wpa_ssid *ssid)
{
	ionstar * wpaFIG_VHT) _FUNC(f)BLOBSt char *puct etwork alob *alob,an exi(valulob ed_ROAs iealobssid_ROAs iealobscha;
		os_')
			palobhods[i exi &&alobIGurnlob ednlobienex}LL;	 a network id-> nlobpoexi
	str_#ifdef CONFIG_VHT) _FUNC(f)BLOBS},
	c chk - Add a network id->s- Fd->sc_read()
 * @ssid: confpa_config_read()
 * @ssid: Pointer to the network coa network block toid->ailllrn Nourc>ailllocned aPo4ype0sc_read()
 * @ssid: by Add a network etworkwork(s a co a network id->eruct wpa_ssid *ssid)
{
	ionst char *puct wpa_ssid *,an exicha;
		os_
	if (ssid-cre_id)re_,anc exi(vnd;
	cds;
 to sed_ROAs ieid *ddr')
			p{ FUNC{PRO exichar *n; "e to sedp_clienex}LL;	 a network id-> wpa_{oexi
	str_id_re_ied_ROAs ie_re_ddr')
			p_re_r

		tm exi &&_re_ddrd_re_ied_re_banex}LL;	 a network id-> cre_{coexi
	str_id a network iluc_ralobse)
{
	io"MKA-CKbufsid->m_ROAs ieGE(fthod);_ex} m1)G_W != EAP_VEND		foSG_ERPSs[i].metEXTs_zalloc(-CKbufsid->m_ROAs ieGE(fthod);_ex} - pos,	ssid->m_ROAs ie_trlE(macrfacepos,	ssid->m_ROAs ie_trlE(macrface(owe_opos,	ssid->m_ROAs ie},
#ec_	{ STRe	{ STG_W	ssid->m_ROAs iepkcs11_	{ STRe	{ STG_W	ssid->m_ROAs iepkcs11_modulRe	{ STG_W	ssid->m_ROAs ie},
#endif /* IEE

W	ssid->m_ROAs iepRe( etwoerTG_Wprintf(title, s_ROAs iepRe( tiFIG_W	ssid->m_ROAs iede_kum_e neeIG_W	ssid->m_ROAs iedSTR(s_naNFIG_F	ssid->m_ROAs iemanupdu_urerTG_W	ssid->m_ROAs iemodel_naNFIG_F	ssid->m_ROAs iemodel_n(MSG_IG_F	ssid->m_ROAs ieserial_n(MSG_IG_F	ssid->m_ROAs ieetwork = methods;
	ssid->m_ROAs iepst)whiteposth) ds;
	ssid->m_ROAs iep to ); "	ssid->m_ROAs iepst)oexf_conf); "	ssid->m_ROAs iepst)nose_deqs;.e for); "	ssid->m_ROAs iemeshdcasturnfreq_lis_ROAs ieeqs;

	return-CKbufsid->m_ROAs ieGE(fnfcNFIGpubassw;sn-CKbufsid->m_ROAs ieGE(fnfcNFIGpe_kassw;sn-CKbufsid->m_ROAs ieGE(fnfcNFev_pwturnfreq_lis_ROAs ieex} }	{ FUNC( OFFhodIG_F	ssid->m_ROAs iesae(owe_osw;sn-CKbufsid->m_ROAs ie
# thod);_elendifods;
	ssid->m_ROAs ieosu_di_IG_F	ssid->m_ROAs ieoadcasturnfreq_lis_ROAs ieGowls;
trigg IEE

W	ssid->m_ROAs ief;


	{ INo ); "	ssid->m_ROAs ieschuc_ },
	{ls;se;T_RANGE(disableMBO "	ssid->m_ROAs ie (laoexf_conf); pa_ptk_rekey) },
	BO_CONFI	ssid->m_ROAs )tic chk - Add a network  !=fullity lists
 Itfined okumupplicant.confedst of
 *dd  wpa_config_read()
 * @ssid: Pointer to the network conf blofiglll OFFk block tofigur as a full
 * conf confarnfiOpaqu evegundif fields intoclll OFFk block t coa neItfined okumupe0s* strucant.confedst of
 *sist().
 *pe0s*, min, mlled to parsethe full
{ Im. We guard agin__INFlll OFFsncell,R(), this cthrougedst of
 *work(s a co a network i!=fullity listtruct wpa_ssid *ssid)
{
	int pri a co(* to )e a con, NULL;
}
#endif /*)nt pri a co*vegonst char *puct wpa_ssid *,annex}LL;
 to sed_ROAs ieid *ddr')
			p{ FUNC{PROnex}char *nbanex}LL;	 to (vegn { FUN; "e to sednex}LL; wc chk - Add a network 			  y lists
 G'");
		bin_edst of
 * barior to ddd  wpa_config_read()
 * @ssid: Pointer to the network confuratUniqu et of
 *   * (i.(tichalue. */ure
 *
 *Nto the list
 * Returnhe %;
		  to thefINTeta ssidar *puct wpa_ssd a network 			  y listtruct wpa_ssid *ssid)
{
	inn[idx] onst char *puct wpa_ssid *dd;
 to sed_ROAs ieid *ddr')
			p{ FUNC{PRO2p_dedh=har *nami*/
		wd[-1] = ' to sedp_clienex}LL; wpa_configid *ddc chk - Add a network g *cty lists
 * @confiw
 * config funemptysc_read()
 * @is cwpa_config_read()
 * @ssid: Pointer to the network conure
 *
 *Tg or
 * to the list
 * Returnhe %;
		  toT,
	Returnd.", lta ssidar *puct wpa_ssd a network g *cty listeruct wpa_ssid *ssid)
{
	ionst [idx] ;t char *puct wpa_ssid *,anlas}cha;
		ost [dethSG_MS to sed_ROAs ieid *ddr')
			p{ FUNC{PRO2p_dr *nami* > i*/
		wo sedp_clie*n; "elas}char *n; "e to sedp_clienex}LL;11w d++dd;
 to sedNULL)
		return -1; to )ritO2p_dr *ns_snprintf(value, 20, MACSr *nami* =x] ;t list);

therturn 0;
}


#ifnritO2p_dlas}) "elas}ienex}char *n; "GE(m
		_ROAs ieid *char *n; id a network onfig_add_prio_ne)
{
	io"MKA_configid *ddc chk - Add a network cell, cty lists
 Rell, es a customedst of
 * barior to ddd  wpa_config_read()
 * @ssid: Pointer to the network confuratUniqu et of
 *   * (i.(tichalue. */ure
 *
 * This functionhe -1string or
 configaso thefINTeta sstruct wpa_conficell, cty listtruct wpa_ssid *ssid)
{
	inn[idx] onst char *puct wpa_ssid *,an exicha;
		os;
 to sed_ROAs ieid *ddr')
			p{ FUNC{PRO2p_dedh=har *nami*/
		wd[-1] = ' exichar *n; "e to sedp_clienex}LL;) {
		wpr *ns_snprintf(value, 2ash, 16)) oexi


	oexiienex}char *nbanex}LL;GE(m
		_ROAs ieid *char *nbanex}LLid a network onfig_add_prio_ne)
{
	io"M	 a network id-> wpa_{{ FUN; "RITE
static chk - Add a network s		  y listNFefaultss
 Se*c * confiFefaultind ofs configuration to be a to the list
 * Returnsid: co(s a co a network s		  y listNFefaults{
	if (ssid->wep_key_lonst c *namOLott	thDEFAULT}


#OACSr *nam FUNC(grif /* I	thDEFAULT}
AIRWISEACSr *nam
	{ INf /* I	thDEFAULT}GROUPACSr *namd) },
	{	thDEFAULT}, "LretuACSr *namse) },
	{ FUNC	thDEFAULT}BG_SCAN_PERIODACSr *namhGO P2P _workaround) },
	{ STRe(rn 0;
ds;	{ STRe(	thDEFAULT}{ STRrn wpa;e(rn 0;
ds; },
	{ INTe	thDEFAULT}{ S_WORKAROUND;e(rn 0;
ds;.,
#endif /* I	thDEFAULT}FRAGMENTonfig;e(rn 0;
ds;.rs) },
	thDEFAULT}USER_SELECTEDonfM;FUNC_KEY(wep_key0) },
	{ FUNC_T_RANGE(disabl
	{ INesh_ban11MeshRetryTimeout	thDEFAULT}
	{ id, 0RETRIEa;e(rn 0;
dot11MeshConfirmTimeo	thDEFAULT}
	{ iRETRY_TIMEOUT;e(rn 0;
dot11Meshg_readingTimeo	thDEFAULT}
	{ i(disaRM_TIMEOUT;e(rn 0;
dot11MeshIG_MESH */
	{ 	thDEFAULT}
	{ iHOLDFIG_TIMEOUT;e(rn 0;
#else /* CONFIG_MES	thDEFAULT}
	{ iRSSI_THR	{ OLD;
pa_ptk_rekey) },
	{ INT(gidentifier) },
ht, 0, 1) },
rn 0;
dGE(disabl	thDEFAULT}DISABLZ) };,
rn 0;
dGE(disabl40	thDEFAULT}DISABLZ) }40;,
rn 0;
dGE(disasgi	thDEFAULT}DISABLZ)SGI;,
rn 0;
dGE(disainto	thDEFAULT}DISABLZ)LDPC;,
rn 0;
x_stbc,	thDEFAULT}TX_STBC;,
rn 0;
r_stbc,	thDEFAULT}RX_STBC;,
rn 0;
NT_RANGE(ampdu_fa	thDEFAULT}DISABLZ)d, 0AMSDU;,
rn 0;
NGE(ampdu_de	thDEFAULT}AMPDU_FACTOR;,
rn 0;
NGE(am },
#en	thDEFAULT}AMPDU_DENSITY;
#ifdef CONFIG_VHT_OVERRIDES
	{ INT_RANGE(disablV
ht, 0, 1) },
rn 0;
T_RANGE(vht_rx_methSG_MS to ;
T_RANGE(vht_rx_2ethSG_MS to ;
T_RANGE(vht_rx_3ethSG_MS to ;
T_RANGE(vht_rx_4ethSG_MS to ;
T_RANGE(vht_rx_5ethSG_MS to ;
T_RANGE(vht_rx_6ethSG_MS to ;
T_RANGE(vht_rx_7ethSG_MS to ;
T_RANGE(vht_rx_8ethSG_MS to ;
T_RAtGE(vht_rx_methSG_MS to ;
T_RAtGE(vht_rx_2ethSG_MS to ;
T_RAtGE(vht_rx_3ethSG_MS to ;
T_RAtGE(vht_rx_4ethSG_MS to ;
T_RAtGE(vht_rx_5ethSG_MS to ;
T_RAtGE(vht_rx_6ethSG_MS to ;
T_RAtGE(vht_rx_7ethSG_MS to ;
T_RAtGE(vht_rx_8ethSG_M
	{ INT(ap_max_inactivity) },
	{ INc *namOLoNT_RANGE(disabled,ethSG_M
NGE(ieee80211w, 0, 2) },
r *nami_OPTIONAL;
	return 0;
}


#ifndef DEFAULT_M
	{ INT(ap_max_in{ FUNC(ocv) },
#endif /* CON, 0, 1) rn 0;
#EY(mka_cak)	thDEFAULT}

IO_NOT}, "LSERity;
pa_ptk_rekey) },
	T(update_ rn 0;
#ss, 0, ethSG_MS to ;
SE_HT,
		    VHT	thDEFAULT}
, 0OPER_CHter_ftic chk - Add a network s		s
 Se*cructure */
inst of
 *sc_read()
 * @is cfiguration to be a to the list
 * Returnsid: co @ctu: Vture */
naNFnt.conf "igur" co @ct of: Vture */
ct of co @tablm anble (MSG_Einslist
 * Return,
	{nhe 0  to theprio. */ure
 *
 * This functiig funpoigu */
confge additiofig_parsThis functiig fu for o
confge figureviously a customedsfig_parhe -1s used to add a network block tonary data
 * (i.e*c * confilist
 * Returnparse eac barior ta nebofunctiolist
 * Return,
	{nlicitlnagFndif (macrface (mput) is tct of co 


#ifndefhen readadditiose ofluematr STt wpaex}-bariorlist
 * Return,
	{nis conbove .pa_supxar ow,ex types areabove adou */
quotReturnr STswork(struct wpa_confi_ALENhar *puct wpa_ssid *,acSG_INFO, "NOTr,acSG_INFO, "NOTt,
				  lue)
{
	wn(value);
	iidsr(ssid-tethods;
		wpr *ns_snprin(MSGOTrs_snprin(MSGOT= os_snprintf(value, 2p(pos,puonfAP_VEND		foields)


/**
 *s_zall

		tm	       struct wpa_ssid n (.pa=p2p_cl0, SSID_i]LL;
		os	os_memset(sr,a, SSIbanaNFIf byt/
		wm	 tin/

#
chd-teth, SSIba*/
sta(, SSIn { FU,f (ssid->ocv && stes);-te< NULL;
	O2p_dlT(eapL;
	OInvalid ocv value '%s'.",
			   ld.", l* (i"int *rate"ld.
 *%eturn -1;f (ssid->rid->ocv && s;11wchd-tethSG_MSG11wcd[-1] = 11w == is_snprlds)


/**
 *NC{PRO2p_dlT(eapL;
	Onvalid ocv value '%s'.",
			   lunkns.
  * confir (.pa")
{
	ret"urn -1;f (ssid->r)_MSG11wcd-tethSG_MS wpa_configeturn}inttruct wpa_confi_AL_quote_{
	if (ssid->wep_key_l,acSG_INFO, "NOTr,
	}
	icSG_INFO, "NOTt,
n(value);
	if (lef (!valbufdsr(ssid-tlen > 2 * MACSEC_CKN_MAX_LEN buf	return NULL;> 2 +*/


O2p_dbuf	rsnprintf(value, 2p(po bufates  '"'; "	ssmemcpydbuf		if sfig_parONFIG_Wbufa> 2 +*1es  '"'; "bufa> 2 +*2 /* NO_CONFIG_ue);

	if (rat_ALEN);
id->ridbuf|| ssid	ssid->mbufN; "RITE
steturn}intk - Add a network 			 lllr
 G'")lllroprse_d Pointt of
 *sc_read()
 * @is cfiguration to be a to the list
 * Returnsid: co @			 E(ds thae _STRon pf E(ds/}	{ FUNCer and eadadclusucdaddRITE
s. */g *rom	(tring ynr y eadexka_pe_n( */ure
 *
 *%;
		 e _STR_L. */g *d strnd .e*cE(dsnlicinctionnd ofs additionuemg the  [
	{  sfig  s ST2 sfig2 s... */
#de]dd a network block tonary data
 * (isid /g *d strnd a customedst of
 * OLo,
	_pri.a netwading ir  thetspe_di
#enco4yid->.
 *pe0sRITE
s. */g *nlicirnd i from elendifowork(s (!valdd a network 			 lll{
	if (ssid->wep_key_len[idx			 E(dsonstar (f) #f, wpa_config_pvalue, 20, MACne _FUNC(f) #f, wpa_config_ptm	       struct wpa_ssid n (.plef (!valgn)0'ther_addrue);
	iidsr (!valdOLo,sdsr(ssi, SSID },
len 			 E(dsue)			 E(dsuAME_PROTEexka_p E(dspos, Lo,s	returc NULL;
om ields)


/**
 * 	if sturn -1 (!val)ritO2p_d! Lo,sfig_write_string_he, SSID },
ethods,puonfAP_VEND		foields)


/**
 *s_zall

		tn (.pa=p2p_cl0, SSID_i]LL;
		os, SSIbaE(di_ssidAME!			 E(dson		wm	 tin/

#	e == NULL, SSIbaonst s(, SSIn { FU && stes)OT= os_snprintf(vwm	 tin/

#	e		os	os_me_CKN_MAX_Ls = NULL;
	}
	value[20 - 1] = wm	 tin/

#	e wpa	0;
}* MACSECdup(, SSIbanaNFI
#	e		os0;
}* "Line %d: I}
	value[20 - 1] = wgott	err
#	e wpa	 Lo,s[, SSID },
e**2 /* 0;
;pa	 Lo,s[, SSID },
e**2 +*1es  her_add		tn (.pD },
++; " wpa_configOLo,sds
err:s,puonfAP_VEND Lo,s[i]L_zalloc(	ssid->m Lo,s[i]ssid	ssid->m Lo,sf;pvalue, 20, MACnee FUNC(f) _FUNC(f), 0
#defic char * wpa_config_write_pek - Add a network 			r
 G'")lucture */
inst of
 *sc_read()
 * @is cfiguration to be a to the list
 * Returnsid: co @ctu: Vture */
naNFnt.conf "igur" co ure
 *
 *Vd of mechanicture */
he %;
		  used to add a network block tonary data
 * (ige*c * confilist
 * Returnparse eac) is a neRITE
s. *OT= osig andopy* .param3 and .param4 can be u addiex}cluematen[.e,.ry thaiose ofluematr The t wpaex}-bariorlist
 * Return,
	{nic co

	if (rat_ALEn( */areabove aPo4ype0s#definetwading ir  thetspe_di
#enco4yid->.
 *pe0sRITE
s. ( */#definork(s (!vald a network 			{
	if (ssid->wep_key_l,acSG_INFO, "NOTrn(value);
	iids;
		wpr *ns_snprin(MSGOTrs_snprinfig_write_string_he,uonfAP_VEND		foields)


/**
 *s_zall

		tm	       struct wpa_ssid n (.pa=p2p_cl0, SSID_i]LL;
		os	os_memset(sr,a, SSIbanaNFIf = NULL;
	}FO, "Nd-teth, SSIbaonst s(, SSIn { FU &&;
	O2p_dd-teAMEhaD }ew (ssdd-t)apL;
	OInvalid ocv value '%s'int *rate"FINTe	}ew (ss addnfiguratio%s;o thewrite_ In at"'int *rate->r)_MSG
	}

	os_fret)_MSG
	d-teth;
		os_me wpa	"RITE
steturn 'uf;
}
#G_WRITE */


/*chk - Add a network 			  o E(dr
 G'")lucture */
inst of
 *sc_read()
 * @ ( o
E(dsons cfiguration to be a to the list
 * Returnsid: co @ctu: Vture */
naNFnt.conf "igur" co ure
 *
 *Vd of mechanicture */
he %;
		  used to add a network block tonary data
 * (ige*c * confilist
 * Returnparse ea tore Add a network 			()netwadnto t FUfereed il valhe t ork block tsadoeso theexkase AddE(d/}	{ FUNC parerialeld name ilist
 * Returndirecari)luE(d/}	{ FUNC , SSIill nthetqofste_,ape0sRITE
s. *OT= osig annemptysx types w %;
		  tohanicture */ill nth the* strr "*"  tohanicture */d con stfregardlctiimeci fd->ocv ) is a neRITE
s. *OT= osig andopy* .param3 and .param4 can be u addiex}cluematen[.e,.ry thaiose ofluematr The t wpaex}-bariorlist
 * Return,
	{nic co

	if (rat_ALEn( */areabove aPo4ype0s#definetwading ir  thetspe_di
#enco4yid->.
 *pe0sRITE
s. ( */#definork(s (!vald a network 			  o E(d{
	if (ssid->wep_key_l,acSG_INFO, "NOTrn(value);
	iids;
		wpr *ns_snprin(MSGOTrs_snprinfig_write_string_he,uonfAP_VEND		foields)


/**
 *s_zall

		tm	       struct wpa_ssid n (.pa=p2p_cl0, SSID_i]LL;
		os	os_memset(sr,a, SSIbanaNFIf = NULL;
	}FO, "Nd-sULL, SSIbaonst s(, SSIn { FU && s
		os, SSIbaE(di_ssiapL;
	OI2p_dd-suAMEr	rateapL;
	OIInvalid ocv valuDEBUGf "Do*/) {
nd vi"int *rrate"E(di_ssidn (.pas: 0 o"int *rrate"exkaseNFIG_W prio;
ntf(title, sr(ssid->a	"RITE
stMACSECdup("*"sid->a	 wpa	"	}

	os_fres)_MSG
	d-te, 20, MACSs;11wchd-tE
stetsrn 'uf;
}
#G_WRITE */


/* Helper macros for network block - Add a network onfig_adsk	- Unfig_cWPAs_frebarior topdifphrRe(nic cs)

ns cfiguration to be a to the list
 * Returnsid: coa network block tohen reading in fieonfig_.WPAs_frellingre comps)

 o4ype0,co 

ifphrRe(nhaDhconfgedaPo4ype0st of
 *sc_read()
 * @work(s a co a network onfig_adsk{
	if (ssid->wep_key_lonstar * wpaFIG_VHT) _PBKDF2s, bkdf2_sha1sTECTIOpdifphrRe(0';
	retey_l,a;
	retey_l ONF, 4096				  lar *namO!= 'PMK
	{ I;KA-CKN", ssid->mka_ckn,
			ssid-_fre(ld napdifphrRe()"'int r *namO!= 'PMK
	{ I;KArn 0;
}


seGO P2P _ifdef CONFIG_VHT) _PBKDF2defic chey(const struct parse__AL_cre_lqs;
ccesx_mcsb{
	if (ssid-cre_id)re_'int *ratetf(MSG_INFO, "NOTE: Obsolu8an eottdsr(ssildOa_pdsr(ssilOa_ps,annOa_ps;


	ssid->ocv kas;

un	{ I* stru nt_lia_ps;
s, Lott	thhods + 1, sizeof(_re_baqs;
ccesx_mcsbmkINT(,)
{
	r_re_bant_lqs;
ccesx_mcsb 	if sturn -1u8)ritO2p_d Lott	tsnprintf(value, 2p(po _re_baqs;
ccesx_mcsbmkINT( &&oeottdss, n inthhods + 1, sizeof(_re_baqs;
ccesx_mcsbmka_pr)
{
	_re_bant_lqs;
ccesx_mcsb 	if sturn -1(ssil)ritO2p_d n intsnprintf(value, 2p(po _re_baqs;
ccesx_mcsbmkn inthOa_pdss, Lott[_re_bant_lqs;
ccesx_mcsbes  atoi[20 - 1] s, ns}* MACSECchrlue[20 -':'ritO2p_d ns}* "Line %d: Ika_p _re_bant_lqs;
ccesx_mcsbes  0, MACSs_re_bant_lqs;
ccesx_mcsb++; "xt:", 4)EXT_}s, ns++dd;
ia_pss  0, MACSnt_lia_psethods;
')
			p kasNC{PROnia_psethhods + 1, sizeof(Oa_ps,ant_lia_pse	if sturn -1(ss)I
#	e		osnia_pset "Line %d: I}
	value[ia_ps)_MSG
alue, 2p(po ;11wcia_psethnOa_ps;

cia_ps[nt_lia_ps++es  atoi[kasN&&;
	 ns}* MACSECchrl ns -','I
#	e		os ns}* "Line 
		wd[-1] = ' ns++dd;
}
#nia_psethhods + 1, sizeof(Oa_ps,ant_lia_pse	if sturn -1(ss)I
#			osnia_pset "Line %d: I
	value[ia_ps)_MSGsid->ieee80211wia_psethnOa_ps;

ia_ps[nt_lia_ps]ethSG_M
Ika_p _re_bant_lqs;
ccesx_mcsbes  Oa_ps;


re_bant_lqs;
ccesx_mcsb++; "RITE
static chey(const struct parse__AL_cre_lqAX_ROAMING_CONS_Os{
	if (ssid-cre_id)re_'int *r	tf(MSG_INFO, "NOTE: Obsolu8aqAX_ROAMING_CONS_Os[f /* CONFIG_HS20][f /* CONFIG_HS20 */
	{ ]ddrue);
	iqAX_ROAMING_CONS_Os ONF[f /* CONFIG_HS20];

un	{ I* stru nt_lqAX_ROAMING_CONS_Osethods,
	ssid->ocv kas,, &end,lue);
	if (le "	ssmem_ALEqAX_ROAMING_CONS_Osef _Sturn -1qAX_ROAMING_CONS_Os)); "	ssmem_ALEqAX_ROAMING_CONS_Os ONF,  _Sturn -1qAX_ROAMING_CONS_Os"Line pos,puonfsns}* her_ad; %d: Iend}* MACSECchrl ns -','I
#	e> 2 * end}? (ue);
	) (end}- kasNC: MACSEC_CKNkasN&&	e		os!end}AME> 2 *byt/
		wd[-1] = '2p_dl 2 *byt(MSGdl 2 &STR
!byt(MS			  lal 2 / 2 >if /* CONFIG_HS20 */
	{ (MS			  la", SEC2biKNkas,
	}
	iiiiiiqAX_ROAMING_CONS_Os[nt_lqAX_ROAMING_CONS_Os],
	}
	iiiiiil 2 / 2)e< NULL;
	Oete peerkey paramete)
{
	ret"ine, valqAX_ROAMING_CONS_Ose os_z: %s"e)
{
	retkasN&&	e
alue, 2p(po ;11wcqAX_ROAMING_CONS_Os ONF[nt_lqAX_ROAMING_CONS_Os] * l 2 / 2po ;nt_lqAX_ROAMING_CONS_Os++dd;
e		os!end/
		wd[-1] =#	e		osnt_lqAX_ROAMING_CONS_Ose>=if /* CONFIG_HS20ULL;
	Oete peerkey paramete)
{
	ret"Tofor nylqAX_ROAMING_CONS_OseOIs"N&&	e
alue, 2p(po ;11;
	 ns}* end}+ G_MS wpa	ssmemcpyd_re_baMAX_ROAMING_CONS_OsefMAX_ROAMING_CONS_Ose			  turn -1qAX_ROAMING_CONS_Os)); "	ssmemcpyd_re_baMAX_ROAMING_CONS_Os ONF, MAX_ROAMING_CONS_Os ONF,			  turn -1qAX_ROAMING_CONS_Os"Line po

re_bant_lqAX_ROAMING_CONS_Osethnt_lqAX_ROAMING_CONS_OsoritRITE
static cht struct parse__AL_cre_{
	if (ssid-cre_id)re_'acSG_INFO, "NOTr,
	}
cSG_INFO, "NOTt,
	lue)
{
	wn(valFO, "NOTtd,lue);
	if (ler(ssid-sds;
		wp	os_memset(sr,a"temOa_ary"If = NULL;
	
re_batemOa_arys  atoi[20 - 1] "xt:", 4)EXT_}s;
		wp	os_memset(sr,a"mka_cak)"If = NULL;
	
re_bamka_cak)	thatoi[20 - 1] "xt:", 4)EXT_}s;
		wp	os_memset(sr,a"sp_mka_cak)"If = NULL;
	 **nlist	thatoi[20 - 1] "x2p_d Lt  <Xt(MSG Lt  >	{ FU&	e
alue, 2p(po ;
re_basp_mka_cak) &&oest;

xt:", 4)EXT_}s;
		wp	os_memset(sr,a"mcsc"If = NULL;
	
re_bamcsc	thatoi[20 - 1] "xt:", 4)EXT_}s;
		wp	os_memset(sr,a"eap"If = NULL;
	es = ssid->= meth_pars = meth] "x= meth.= meth}* eods[num_			 parslue[20 -&= meth.thod);1] "x2p_d= meth.thod);f = { S_[i].metIETF}AM			  la= meth.= meth}*= { S_TYPET) NEapL;
	Onvalid ocv value '%s'.",
			   lunkns.
 { S parsturn a")
{
	ret"me */s
re_},
	al",f (ssid->ocv && s
alue, 2p(po ;11wc	ssid->m_re_ba}
# = methTG_W	_re_ba}
# = meth	return NULL;turn -1;_re_ba}
# = methT1] "x2p_d_re_ba}
# = meth	r "Line 
		walue, 2p(po ;	ssmemcpyd_re_ba}
# = meth -&= meth_Sturn -1= methT1] "xt:", 4)EXT_}s;
		wp	os_memset(sr,a"m	{ FUNC"If = N}AM		  la	os_menmset(s[20 -"ext:"	{ IN = NULL;
	 	wphaD }ew (ssd->ocv  
		walue, 2p(po ;>rintf(title, s_re_baid) },
	{G_W	_re_baid) },
	}* MACSECdup(->ocv && s_re_ba}x} }	{ FUNCO P2P "xt:", 4)EXT_}s;
		wp	os_memset(sr,a"E(roaming_consort"If = NULL;
	
re_baE(roaming_consort	thatoi[20 - 1] "xt:", 4)EXT_}s;
		wp	os_memset(sr,a"_RO_dl_band  VHT_home"If = NULL;
	
re_ba_RO_dl_band  VHT_home	thatoi[20 - 1] "xt:", 4)EXT_}s;
		wp	os_memset(sr,a"_RO_ul_band  VHT_home"If = NULL;
	
re_ba_RO_ul_band  VHT_home	thatoi[20 - 1] "xt:", 4)EXT_}s;
		wp	os_memset(sr,a"_RO_dl_band  VHT_qAX_ROA"If = NULL;
	
re_ba_RO_dl_band  VHT_qAX_ROA	thatoi[20 - 1] "xt:", 4)EXT_}s;
		wp	os_memset(sr,a"_RO_ul_band  VHT_qAX_ROA"If = NULL;
	
re_ba_RO_ul_band  VHT_qAX_ROA	thatoi[20 - 1] "xt:", 4)EXT_}s;
		wp	os_memset(sr,a"_ax_bss"Load"If = NULL;
	
re_ba_ax_bss"Load	thatoi[20 - 1] "xt:", 4)EXT_}s;
		wp	os_memset(sr,a"qs;
ccesx_mcsb"If = NU "xt:", 4)ruct parse__AL_cre_lqs;
ccesx_mcsb{)re_'a20 - 1] s,		wp	os_memset(sr,a"L */"If = NULL;
	
re_baL */	thatoi[20 - 1] "xt:", 4)EXT_}s;
		wp	os_memset(sr,a"ss) },
"If = NULL;
	
re_bars) },
	thatoi[20 - 1] "xt:", 4)EXT_}s;
20 ue);

	if (ratct wpax typelue[20 -&ONFIG_Wtes)OT=s_snprin(MS		  lap	os_memset(sr,a"exclusuc_ to "R
!byt(AM		  la 	os_memset(sr,a"qAX_ROAMING_CONS_O"R
!byt(AM		  la 	os_memset(sr,a"qequire_lqAX_ROAMING_CONS_O"R
!byt(AM		  la haD }ew (ssd->o)e %d: Invalid ocv value '%s'.",
			   line, valn (.paurn ax types"
	}
	ii"OT= osurn -1;f (ssid->rid->ocv && s
	value[20 )_MSGsid->ieee80211;
		wp	os_memset(sr,a"qsal
"If = NULL;
		ssid->m_re_baM + m	; "	_re_baM + m}* herP "xt:", 4)EXT_}s;
		wp	os_memset(sr,a"EsernaNF"If = NULL;
	es ntf(title, s_re_bausernaNFIG_F	_re_bausernaNF}* herP "xt:", 4)EXT_}s;
		wp	os_memset(sr,a"m	{ FUNC"If = NULL;
	es ntf(title, s_re_baid) },
	{G_W	_re_baid) },
	}* herP "x_re_ba}x} }	{ FUNCO P0P "xt:", 4)EXT_}s;
		wp	os_memset(sr,a"{ STRe("If = NULL;
		ssid->m_re_ba{ STRe(cG_W	_re_ba{ STRe(}* herP "xt:", 4)EXT_}s;
		wp	os_memset(sr,a"{y) },
	{ S"If = NULL;
		ssid->m_re_ba{y) },
	{ STG_W	_re_ba{y) },
	{ S}* herP "xt:", 4)EXT_}s;
		wp	os_memset(sr,a"me_key_pass"If = NULL;
		ssid->m_re_baie_key_passw;sn	_re_baie_key_pass}* herP "xt:", 4)EXT_}s;
		wp	os_memset(sr,a"me_key_pass	{ STRe"If = NULL;
	es ntf(title, s_re_baie_key_pass	{ STRe(G_W	_re_baie_key_pass	{ STRe}* herP "xt:", 4)EXT_}s;
		wp	os_memset(sr,a"swor"If = NULL;
		ssid->m_re_basworw;sn	_re_baswor}* herP "xt:", 4)EXT_}s;
		wp	os_memset(sr,a"m
		nagF"If = NULL;
	es ntf(title, s_re_bam
		nagFIG_F	_re_bam
		nagF}* herP "xt:", 4)EXT_}s;
		wp	os_memset(sr,a")main_match) },
	{ "If = NULL;
		ssid->m_re_ba)main_match) },
	{ SG_W	_re_ba)main_match) },
	{ }* herP "xt:", 4)EXT_}s;
		wp	os_memset(sr,a")main_"If = NULL;
	
(!valdt w_)main_so ;n w_)main_nthhods + 1, sizeof(_re_ba)main_'int *ratetf(Mre_bant_l)main_		if (methratetf(turn -1 (!val)ritOe		osn w_)main_nt "Line %d: I}
	value[20  && s
alue, 2p(po ;11wcn w_)main_[Mre_bant_l)main_++es  herP "x_re_ba)main_ntht w_)main_so ;t:", 4)EXT_}s;
		wp	os_memset(sr,a"mTRe(p"If = NULL;
		ssid->m_re_baiTRe(pcG_W	_re_baiTRe(p}* herP "xt:", 4)EXT_}s;
		wp	os_memset(sr,a"mTRe(2"If = NULL;
		ssid->m_re_baiTRe(2cG_W	_re_baiTRe(2}* herP "xt:", 4)EXT_}s;
		wp	os_memset(sr,a"qAX_ROAMING_CONS_O"R
 = NULL;
	 	wpl 2 < 3(MSGl 2 >(turn -1 re_baMAX_ROAMING_CONS_O)apL;
	Onvalid ocv value '%s'.",
			   line, val")
{
	ret"MAX_ROAMING_CONS_OGl 2gth	   (3..15l")
{
	ret"expecpe_n1;f (ssid1(ss)rONFIG_WI}
	value[20  && s
alue, 2p(po ;11wc	ssmemcpyd_re_baMAX_ROAMING_CONS_Oid->oarONFIG_W	_re_baMAX_ROAMING_CONS_O_> 2 * f (lers
	value[20 )_MSGsid->ieEXT_}s;
		wp	os_memset(sr,a"qs;uire_lqAX_ROAMING_CONS_O"R
 = NULL;
	 	wpl 2 < 3(MSGl 2 >(turn -1 re_baMs;uire_lqAX_ROAMING_CONS_O  
		L;
	Onvalid ocv value '%s'.",
			   line, val")
{
	ret"Ms;uire_lqAX_ROAMING_CONS_OGl 2gth	   ")
{
	ret"(3..15lexpecpe_n1;f (ssid1(ss)rONFIG_WI}
	value[20  && s
alue, 2p(po ;11wc	ssmemcpyd_re_baMs;uire_lqAX_ROAMING_CONS_Oid->oarONFIG_W	_re_baMs;uire_lqAX_ROAMING_CONS_O_> 2 * f (lers
	value[20 )_MSGsid->ieEXT_}s;
		wp	os_memset(sr,a"qAX_ROAMING_CONS_Os"R
 = NULL;
	d-sULLruct parse__AL_cre_lqAX_ROAMING_CONS_Os{)re_'a20  && stes);-sC<s_strchnvalid ocv value '%s'int *ret",
			   line, valqAX_ROAMING_CONS_Os"'int *ret{
	wnlers
	value[20 )_MSGsid->ieetsrn }s;
		wp	os_memset(sr,a"exclusuc_ to "R
 = NULL;
	es = ssixclusuc_ to  *e =#	e		osl 2 >(s)


f /*	{ INL;
	Onvalid ocv value '%s'.",
			   line, val")
{
	ret"ixclusuc_ to  l 2gth	  1;f (ssid1(ss)rONFIG_WI}
	value[20  && s
alue, 2p(po ;11o ;enthhods + 1, sizeof(_re_baixclusuc_ to ,)
{
	rete(Mre_bant_lixclusuc_ to  	if (meth;etf(turn -1es = ssixclusuc_ to )ritOe		osent "Line %d: I}
	value[20  && s
alue, 2p(po ;11wc_re_baixclusuc_ to }* e;1o ;enth&_re_baixclusuc_ to [Mre_bant_lixclusuc_ to ++epo ;	ssmemcpydeetey_l,a->oarONFIG_W	eetey_l ONF * f (leers
	value[20 )_MMSGsid->ieEXT_}s;
		wp	os_memset(sr,a"qAX_ROAMpartner"R
 = NULL;
	es = ssqAX_ROAMpartner *p;;
	
(!valkas;
;
	pnthhods + 1, sizeof(_re_baqAX_ROAMpartner,)
{
	rete(Mre_bant_lqAX_ROAMpartner 	if (meth;etf(turn -1es = ssMAX_ROAMpartnerT1] "x2p_d nt "Line %d: I}
	value[20  && s
alue, 2p(po ;11wc_re_baqAX_ROAMpartner = p;
;
	pnth&_re_baqAX_ROAMpartner[Mre_bant_lqAX_ROAMpartner]&&;
	 ns}* MACSECchrl->oar','I
#	e		os ns}* "Line %d: I}
	value[20  && s
alue, 2p(po ;11wc* ns++/* NO_CONFe		os ns}-a->o}-a1e>=i1(ss)rturn -1p->fqdn) %d: I}
	value[20  && s
alue, 2p(po ;11wc	ssmemcpydp->fqdn,a->oar ns}-a->oN&&;
	 baixaix_matchs  atoi[kasN&&;
	 ns}* MACSECchrl ns -','I
#	e		os ns}* "Line %d: I}
	value[20  && s
alue, 2p(po ;11wc* ns++/* NO_CON;
	 bamka_cak)	thatoi[kasN&&;
	 ns}* MACSECchrl ns -','I
#	e		os ns}* "Line %d: I}
	value[20  && s
alue, 2p(po ;11wc* ns++/* NO_CON;
			os	os_me_CKNkasNC>=iturn -1p->couos_z) %d: I}
	value[20  && s
alue, 2p(po ;11wc	ssmemcpydp->couos_zar ns, MACSEC_CKNkasN 	ifN&&;
	Mre_bant_lqAX_ROAMpartner++; "x
	value[20 )_MMSGsid->ieEXT_}s;
		wp	os_memset(sr,a"ieovis},
ROAMsp"If = NULL;
		ssid->m_re_baieovis},
ROAMsp)G_W	_re_baieovis},
ROAMsp}* herP "xt:", 4)EXT_}s;
		wplT(eapL;
	nvalid ocv value '%s'.",
			   lunkns.
 cre_in (.paurn .",
	}
	ii (ssid->r)_MS wpa	ssalue[20 )_MMSalue, 2p(poc chey(cons (!vald+ 1, siif /tr1(ssi20 )(valFSG_INun	{ I* stru buf/* I	th2ods,
(!valbufdsr(ssid-s;
;
buf	return NULL;buf/* I


O2p_dbuf	rsnprintf(value, 20, MACSd-sULL	os_nid ocv buf||buf/* I'."  1;f20  && 		wp	os_nid ocv_error(buf/* I'.res)ULL;
		ssid->mbufN; "
buf	re0, MACS}MSalue, 2bufdsc chey(cons (!vald+ 1, sSECdup(cSG_INFO, "N	{ Inst [	wprtrs_snprinfig_write_string_"RITE
stMACSECdup(	{ IG_c ch (!vald a network 			 cre_l o E(d{
	if (ssid-cre_id)re_'acSG_INFO, "NOTrInst [	wp	os_memset(sr,a"temOa_ary"If = NUig_write_s+ 1, siif /tr1
re_batemOa_ary1] s,		wp	os_memset(sr,a"mka_cak)"If = NUig_write_s+ 1, siif /tr1
re_baOL
	{ INT] s,		wp	os_memset(sr,a"sp_mka_cak)"If = NUig_write_s+ 1, siif /tr1
re_basp_mka_cak)1] s,		wp	os_memset(sr,a"mcsc"If = NUig_write_s+ 1, siif /tr1
re_baORe(e;s;
		wp	os_memset(sr,a"eap"If = NULL;
			os!_re_ba}
# = methT& s
alue, 20, MACSswrite_s+ 1, sSECdup(}
# 			  am>m_re_ba}
# = meth[0].thod);'int *r	t_re_ba}
# = meth[0].= methT1] "}s;
		wp	os_memset(sr,a"E(roaming_consort"If = NUig_write_s+ 1, siif /tr1
re_baE(roaming_consorti;s;
		wp	os_memset(sr,a"_RO_dl_band  VHT_home"If = NUig_write_s+ 1, siif /tr1
re_ba_RO_dl_band  VHT_homei;s;
		wp	os_memset(sr,a"_RO_ul_band  VHT_home"If = NUig_write_s+ 1, siif /tr1
re_ba_RO_ul_band  VHT_homei;s;
		wp	os_memset(sr,a"_RO_dl_band  VHT_qAX_ROA"If = NUig_write_s+ 1, siif /tr1
re_ba_RO_dl_band  VHT_qAX_ROAi;s;
		wp	os_memset(sr,a"_RO_ul_band  VHT_qAX_ROA"If = NUig_write_s+ 1, siif /tr1
re_ba_RO_ul_band  VHT_qAX_ROAi;s;
		wp	os_memset(sr,a"_ax_bss"Load"If = NUig_write_s+ 1, siif /tr1
re_ba_ax_bss"Loadi;s;
		wp	os_memset(sr,a"qs;
ccesx_mcsb"If = NULL;
	un	{ I* stru i;;
	
(!valbuf|| &en,v kas;

r(ssid-tlen 			os!_re_bant_lqs;
ccesx_mcsbT& s
alue, 20, MAC "
buf	return NULL;4000I
#	e		osbuf	rsnprintf(v
alue, 20, MACSs ns}* bufdsrIend}*  ns}+ 4000dsrI != EAP_VEND		fo_re_bant_lqs;
ccesx_mcsbs_zallLL;
	O2ssilOa_ps&&;
	Od-teth	os_nid ocv  ns, end}- kas'." s%u"'int *rati >(0 ? "\n" : ""'int *rat_re_baqs;
ccesx_mcsbmkINT([i]ssid	 		wp	os_nid ocv_error(end}- kas'.d-t)a
SG
	d-te, 2bufdsrIs ns}+=id-tlen 	wia_pseth_re_baqs;
ccesx_mcsbmkn i_i]LL;
O2p_d n isapL;
	OI2ssijLL;
OI != EjP_VEND a_ps[j]
!byp(p jallLL;
	O	Od-teth	os_nid ocv  ns, end}- kas'int *r	rat" s%d"'int *r	ratj >(0 ? "," : ":"'int *r	rat a_ps[j]sid->a	"		wp	os_nid ocv_error(end}- kas'.d-t)a
SG
	
	d-te, 2bufdsrIsIs ns}+=id-tleIsIs11wch}o ;11o ;d-te, 2bufdsr}s;
		wp	os_memset(sr,a"L */"If = NUig_write_s+ 1, siif /tr1
re_baL */i;s;
		wp	os_memset(sr,a"qsal
"If = NUCSswrite_s+ 1, sSECdup(_re_baM + m	; ;
		wp	os_memset(sr,a"EsernaNF"If = NUCSswrite_s+ 1, sSECdup(_re_bausernaNFIG_;
		wp	os_memset(sr,a"m	{ FUNC"If = NULL;
			os!_re_baid) },
	{& s
alue, 20, MACSswrite_s+ 1, sSECdup("*"sid-}s;
		wp	os_memset(sr,a"{ STRe("If = NUCSswrite_s+ 1, sSECdup(_re_ba{ STRe(cG_;
		wp	os_memset(sr,a"{y) },
	{ S"If = NUCSswrite_s+ 1, sSECdup(_re_ba{y) },
	{ STG_;
		wp	os_memset(sr,a"me_key_pass"If = NUCSswrite_s+ 1, sSECdup(_re_baie_key_passw;s;
		wp	os_memset(sr,a"me_key_pass	{ STRe"If = NULL;
			os!_re_baie_key_pass	{ STRe(& s
alue, 20, MACSswrite_s+ 1, sSECdup("*"sid-}s;
		wp	os_memset(sr,a"swor"If = NUCSswrite_s+ 1, sSECdup(_re_basworw;s;
		wp	os_memset(sr,a"m
		nagF"If = NULL;
			os!s_re_bam
		nagFI(& s
alue, 20, MACSswrite_s+ 1, sSECdup("*"sid-}s;
		wp	os_memset(sr,a")main_match) },
	{ "If = NUCSswrite_s+ 1, sSECdup(_re_ba)main_match) },
	{ SG_;
		wp	os_memset(sr,a")main_"If = NULL;
	un	{ I* stru i;;
	
(!valbuf|| &en,v kas;

r(ssid-tlen 			os!_re_bant_l)main_p& s
alue, 20, MAC "
buf	return NULL;4000I
#	e		osbuf	rsnprintf(v
alue, 20, MACSs ns}* bufdsrIend}*  ns}+ 4000dssrI != EAP_VEND		fo_re_bant_l)main_s_zallLL;
	Od-teth	os_nid ocv  ns, end}- kas'." s%s"'int *rati >(0 ? "\n" : ""' _re_ba)main_[i]ssid	 		wp	os_nid ocv_error(end}- kas'.d-t)a
SG
	d-te, 2bufdsrIs ns}+=id-tle ;11o ;d-te, 2bufdsr}s;
		wp	os_memset(sr,a"mTRe(p"If = NUCSswrite_s+ 1, sSECdup(_re_baiTRe(pcG_;
		wp	os_memset(sr,a"mTRe(2"If = NUCSswrite_s+ 1, sSECdup(_re_baiTRe(2i;s;
		wp	os_memset(sr,a"qAX_ROAMING_CONS_O"R
 = NULL;
	ue);
	ibuff (lers
(!valbufdsn 			os!_re_baqAX_ROAMING_CONS_O_> 2tf(v
alue, 20, MACSsbuff (eth_re_baqAX_ROAMING_CONS_O_> 2 **2 +*1; "
buf	return NULL;buff (I
#	e		osbuf	rsnprintf(v
alue, 20, MACSssid->nid ocv_hex buf||bufONF, _re_baMAX_ROAMING_CONS_Oi
 *r	t_re_baqAX_ROAMING_CONS_O_> 2t;o ;d-te, 2bufdsr}s;
		wp	os_memset(sr,a"qs;uire_lqAX_ROAMING_CONS_O"R
 = NULL;
	ue);
	ibuff (lers
(!valbufdsn 			os!_re_baqs;uire_lqAX_ROAMING_CONS_O_> 2tf(v
alue, 20, MACSsbuff (eth_re_baqs;uire_lqAX_ROAMING_CONS_O_> 2 **2 +*1; "
buf	return NULL;buff (I
#	e		osbuf	rsnprintf(v
alue, 20, MACSssid->nid ocv_hex buf||bufONF, _re_baMs;uire_lqAX_ROAMING_CONS_Oi
 *r	t_re_baqs;uire_lqAX_ROAMING_CONS_O_> 2t;o ;d-te, 2bufdsr}s;
		wp	os_memset(sr,a"qAX_ROAMING_CONS_Os"R
 = NULL;
	ue);
	ibuff (lers
(!valbuf,v kas;

rue);
	iids;
			os!_re_bant_lqAX_ROAMING_CONS_Os)f(v
alue, 20, MACSsbuff (eth_re_bant_lqAX_ROAMING_CONS_Ose*f(v
f /* CONFIG_HS20 */
	{ (**2 +*1; "
buf	return NULL;buff (I
#	e		os!bufNf(v
alue, 20, MACSs ns}* bufdsrI != EAP_VEND		fo_re_bant_lqAX_ROAMING_CONS_Oso_zallLL;
	O2== is>s_strchc* ns++/* N,'dsrIs ns}+=isid->nid ocv_hex 
IsIs ns||buf +*buff (e- kas'int *_re_baMAX_ROAMING_CONS_Os[i]'int *_re_baMAX_ROAMING_CONS_Os ONF[i]ssid	11wc* ns/* NO_CONFed-te, 2bufdsr}s;
		wp	os_memset(sr,a"exclusuc_ to "R
 = NULL;
	un	{ I* stru i;;
	
(!valbuf|| &en,v kas;
;
			os!_re_bant_lixclusuc_ to )& s
alue, 20, MAC "
buf	return NULL;4000I
#	e		osbuf	rsnprintf(v
alue, 20, MACSs ns}* bufdsrIend}*  ns}+ 4000dssrI != EAP_VEND		fo_re_bant_lixclusuc_ to o_zallLL;
	Oes = ssixclusuc_ to  *e =	
r(ssid-tlen 	;enth&_re_baixclusuc_ to [i]LL;
Od-teth	os_nid ocv  ns, end}- kas'." s%s"'int *rati >(0 ? "\n" : ""'int *ratsid->wep_txtdeetey_l,aeetey_l ONF)ssid	 		wp	os_nid ocv_error(end}- kas'.d-t)a
SG
	d-te, 2bufdsrIs ns}+=id-tle ;11o ;d-te, 2bufdsr}s;
		wp	os_memset(sr,a"qAX_ROAMpartner"R
 = NULL;
	un	{ I* stru i;;
	
(!valbuf|| &en,v kas;
;
			os!_re_bant_lMAX_ROAMpartnerT& s
alue, 20, MAC "
buf	return NULL;4000I
#	e		osbuf	rsnprintf(v
alue, 20, MACSs ns}* bufdsrIend}*  ns}+ 4000dssrI != EAP_VEND		fo_re_bant_lMAX_ROAMpartnero_zallLL;
	Oes = ssqAX_ROAMpartner *p;;
	r(ssid-tlen 	;pnth&_re_baqAX_ROAMpartner[i]LL;
Od-teth	os_nid ocv  ns, end}- kas'." s%s,%d,%u,%s"'int *rati >(0 ? "\n" : ""'int *ratp->fqdn,a baixaix_match,a bamka_cak)'int *ratp->couos_z)sid	 		wp	os_nid ocv_error(end}- kas'.d-t)a
SG
	d-te, 2bufdsrIs ns}+=id-tle ;11o ;d-te, 2bufdsr}s;
		wp	os_memset(sr,a"meovis},
ROAMsp"If = NUCSswrite_s+ 1, sSECdup(_re_baieovis},
ROAMsp)G_
#G_WRITE */


/*ch
	if (ssid-cre_idd a network 			 cre_truct wpa_ssid *ssid)
{
	inn[idx] onst char *puct cre_id)re_G_
#cre_ied_ROAs ie_re_ddr')
			p_re_r

		t2== ih	r "_re_bas*/
		wd[-1] = 'cre_ied_re_banex}LL; wpa_config_re_dd/*ch
	if (ssid-cre_idd a network g *ccre_truct wpa_ssid *ssid)
{
	ionst [idx] ;t char *puct cre_id)re_'anlas}cha;
		ost [dethSG_MScre_ied_ROAs ie_re_ddr')
			p_re_r

		t2== _re_bas* > i*/
		wo sed_re_bas* = 'las}cha_re_ddr'cre_ied_re_banex}LL; ww d++dd;
cre_iedoULL)
		return -1;_re_r && 		wpcre_iesnprinfig_write_string_"_re_bas* =x] ;t 
re_bass) },
	thDEFAULT}USER_SELECTEDonfM;F
		wplas}) "elas}ienex}cha_re_ddrGE(m
		_ROAs iecre_ied_re_;wpa_config_re_dd/*chtruct wpa_conficell, ccre_truct wpa_ssid *ssid)
{
	inn[idx] onst char *puct cre_id)re_,an exicha;
		os;
cre_ied_ROAs ie_re_ddr')
			p_re_r

		t2== ih	r "_re_bas*/
		wd[-1] = ' exi &&_re_ddrd_re_ied_re_banex}LL;}s;
		wpcre_iesnprinfig_write_sash, 16)) oexi


	oexiienex}cha_re_banex}LL;GE(m
		_ROAs iecre_ied_re_banex}LLid a network id-> cre_{creUN; "RITE
static char * wpaFIG_VHT) _FUNC(f)BLOBStk - Add a network 			 nlob 
 G'")lunaNForlist
 * Returnnlobdd  wpa_config_read()
 * @ssid: Pointer to the network confnaNF: NaNF} .paramnlobdd  RITE
ssation to be anlob sid: he %;
		  to thefINTeta ssm	       struuct etwork alob *d a network 			 nlobtruct wpa_ssid *ssid)
{
	int prir	tf(MSG_INFO, "NnaNFInst char *puct ctwork alob *ulob ed_ROAs iealobssis_')
			palobhods[i		wp	os_memsetnlobienaNFntnaNFIf = NUf(v
alue, 2alobIGurnlob ednlobienex}LL;}
#G_WRITE */


/*chk - Add a network s		 nlob 
 S strr a @confaNForlist
 * Returnnlobdd  wpa_config_read()
 * @ssid: Pointer to the network confnlob *Ntwdnfiguratioaramnlobdd  conAddsconfiw
list
 * Returnnlobtrr replac>aiaram3urrentind ofd strnsixistROAa neblobwork(s a co a network s		 nlobtruct wpa_ssid *ssid)
{
	int pr    struuct etwork alob *alobhnst t wpa_conficell, cnlobt)
{
	innnlobienaNFN; "nlobienex} ed_ROAs iealobssid_ROAs iealobschaalobIGc chk - Add a network id-> nlob 
 Fd->snlob sid: confnlob *ion to be anlob s: 0 oid->dork(s a co a network id-> nlobtruct wpa_ssid *ss alob *alobhnst 		osblobhods[i	ssid->mblobienaNFN; "	binntf(title, sblobiesid:nnnlobief (I
#	e	ssid->mblobsid-}sc chk - Add a network cell, cnlob 
 Rell, es naNForlist
 * Returnnlobdd  wpa_config_read()
 * @ssid: Pointer to the network confnaNF: NaNF} .paramnlob s: cell, . */ure
 *
 * T		onlob gasocell, dnhe -1strinlob gaso thefINTeta sstruct wpa_conficell, cnlobtruct wpa_ssid *ssid)
{
	in(MSG_INFO, "NnaNFInst char *puct ctwork alob * ns}* _ROAs iealobs,an exicha;
		os;
')
			pkasNC{PRO		wp	os_memsetkasienaNFntnaNFIf = NULL;
	O2== oexi


	
	oexiienex}chakasienex}LL;	;GE(m
			d_ROAs iealobschakasienex}LL;	; a network id-> nlobpoasN&&	e
alue, 20sid	11wc exichakas;

r ns}* kasienex}LL; wpa_configp(poc #ifdef CONFIG_VHT) _FUNC(f)BLOBS},
	chk - Add a network g 1, semptys- Allocned annemptyslist
 * Returdd  wptrlE(macrfacefig_rtrol (macrface 


#ifndesnt.conf 	{ S s: UNIX )main_is ctocketdd  wde_kum_e nee: De_kum 


#ifndesdd  RITE
ssation to be alllocned ac_read()
 * @ssid: he %;
		  used to add ssidar *puct id *ssidd a network g 1, sempty(cSG_INFO, "NptrlE(macrface (methratecSG_INFO, "Nde_kum_e neeInst char *puct ctworkid)
{
	i;alFSG_INtrucaCWmn_nth4,caCWmaxO P2ods,
	ssidchar *phostapd_wmm_ac_e neescoc_bk =(me{caCWmn_,caCWmax, 7,  _S0 }; CON OFFg INTe	trafficig_ptm	       struhostapd_wmm_ac_e neescoc_be =(me{caCWmn_,caCWmax, 3,  _S0 }; CON e   effn intrafficig_ptm	       struhostapd_wmm_ac_e neescoc_vAP_VCONvideontrafficig_pte{caCWmn_}-a1,caCWmn_,c2, 3000 / 32_S0 };ptm	       struhostapd_wmm_ac_e neescoc_voP_VCONvoice trafficig_pte{caCWmn_}-a2,caCWmn_}-a1,c2,c1500 / 32_S0 };pid_ROAs iedoULL)
		return -1;_
{
	io && 		wpcROAs iesnprinfig_write_string_"_ROAs ieds;	{ kums},
 thDEFAULT}{ STRrVERSIONg_"_ROAs ieap) },
 thDEFAULT}AP_SCANg_"_ROAs ieuser_mp
	thDEFAULT}USER_MPMg_"_ROAs ie_ax_[num_linkt	thDEFAULT}
AX_PEER_LINKSg_"_ROAs ie_else_ax_inNT_RAak)	thDEFAULT}
	{ id, 0INACTIVITY;
"_ROAs iedot11RSNASAERITransP FUNC	tig_DEFAULT}DOT11_RSNA_SAEiRETRANS_PERIODACS_ROAs iefas}netwuHT	thDEFAULT}FASTiREAU_ftiS_ROAs iepst)goE(macnl	thDEFAULT}P2P_GO0INTENTtiS_ROAs iepst)(mara_bss	thDEFAULT}P2P_INTRA_BSStiS_ROAs iepst)goEeqs;
confge_;	{icy	thDEFAULT}P2P_GO0FREQ_MOVEtiS_ROAs iepst)goE_ax_inNT_RAak)	thDEFAULT}P2P_GO0d, 0INACTIVITY;
"_ROAs iepst)oprsme);
/g *en
conf	thDEFAULT}P2P_OPTIMIZE_LISTEN_CHANg_"_ROAs iepst)goEctwindow	thDEFAULT}P2P_GO0CTWINDOWsid_ROAs ieassE_ax_couos	thDEFAULT}BSS0d, 0COUNTtiS_ROAs ieassEexpi)
 * @_agF}* DEFAULT}BSS0EXPIRAndef AGEtiS_ROAs ieassEexpi)
 * @_ },
	couos	thDEFAULT}BSS0EXPIRAndef SCAN_COUNTtiS_ROAs ie_ax_nt_lsta	thDEFAULT}
AX_ieldsTAg_"_ROAs ieap)isolned thDEFAULT}AP_ISOLATEtiS_ROAs ieauncti  y listNparstthDEFAULT}ACCESS0NETWORK_TYPEtiS_ROAs ie },
	cuitle,qtthDEFAULT}SCAN_CUR0FREQtiS_ROAs iewmm_ac_e neesates  oc_betiS_ROAs iewmm_ac_e neesa1es  oc_bktiS_ROAs iewmm_ac_e neesa2es  oc_vitiS_ROAs iewmm_ac_e neesa3es  oc_vog_"_ROAs iepst).(tich_dela)	thDEFAULT}P2P_SEARCH_DELAY;
"_ROAs ierand, 0, 
/gfersmstthDEFAULT}RAND_ADDR_LIFETIME;
"_ROAs ied) },
	{_offLoad	thDEFAULT}, "Lretu_OFFLOADACS_ROAs ie	{ S_inntb	thDEFAULT}CERT0IN_CBtiS_ROAs iewct rscnetlax
 * @sthDEFAULT}WPA_RSCiRELAXAndef;
,
#endif /* CON,BOiS_ROAs ie_boEcellx_mcs	thDEFAULT}
BO0CELL_CAPAg_"_ROAs ieNT_Rss, simSTRonte /* CONFIG_MES	tig_DEFAULT}DISASSOC_IMMINENToRSSI_THR	{ OLD;
"_ROAs ieocstthDEFAULT}OCE_SUPPORT_M
	{ INT(ap_max_in
BO},
	c 		wpctrlE(macrface)
		_ROAs iectrlE(macrface * MACSECdup(ctrlE(macrface)&& 		wpde_kum_e neeIn		_ROAs iede_kum_e nee * MACSECdup(de_kum_e neeI;
"_ROAs iegas_rand, 0, 
/gfersmstthDEFAULT}RAND_ADDR_LIFETIME;
pa_config_
{
	i;ac char * wpaFIG_VHT) _STDOUTuDEBUGhk - Add a network debuk dsid- y lists}-aDebuk dsid} .pc_read()edst of
 *sdd  wpa_config_read()
 * @ssid: Pointer to the network co(s a co a network debuk dsid- y liststruct wpa_ssid *ssid)
{
	ionst [idxoest;

ruct wpa_ss>wep_key_lpos,puonfsist	thEND Lt  <X_ROAs ient_liest;D Lt allLL;
	sto sed_ROAs iep to [ Lt ]ACSssid-id ocv valuDEBUGf "Pka_cak)	
	{ I %d"'int  lar *namOka_cak)1] 	r')
			p{ FUNC{PROssid-id ocv valuDEBUGf "  lud=%dar *n=urn "'int *retr *nami ,)
{
	retsid->wep_txtd;
	retey_l,a;
	retey_l ONF)ssid	 sd *char *nbapnex}LL;	}d-}sc #ifdef CONFIG_VHT) _STDOUTuDEBUG},
	chruct wpglobal_ct wpa_ssid{s,
(!valnaNF;t [idx(**/
sta)(m	       struglobal_ct wpa_ssid*sid:n
hratetf(tuct wpa_ssid *ssid)
{
	inn[idx (ssidcoG_INFO, "NOTE: O;t [idx(*get)(cSG_INFO, "NnaNFnttuct wpa_ssid *ssid)
{
	innlopes ffsetn
hrate
(!valbuf||ue);
	ibuff (nn[idx extty-id ocO;t  a co*e nee1,o*e nee2,o*e nee3;

un	{ I* stru confged STRe;ac; chey(const structglobal_cf (ratct wpat s(m	       struglobal_ct wpa_ssid*sid:n
hr}
	iiiiiituct wpa_ssid *ssid)
{
	inn[idx (ssi
hr}
	iiiiiicSG_INFO, "NoasNnst [idx->oar*ds}LL;FO, "N&end,
	ds}cha1(ssil) (((u8an)d_ROAs N 	i(lope)ssid:ba*/
ee1O;t  0 ue)tuctol  ns, &&en,v0)&& 		wpN&en %d: Invalid ocv value '%s'.",
			   line, val (MSG_E\"%s\"",
	}
	ii (ssidoasN&&	esid->ieee80211	*ds}chaherP 
ssid-id ocv valuDEBUGf "%s=  1;fsid:banaNFnt*ds}i;s;
		wpsid:ba*/
ee2}AME*ds}c<i(lope)ssid:ba*/
ee2 %d: Invalid ocv value '%s'.",
			   ltoo sn NU*%etlue[20=   ")
{
ret"_RO_ue[20= l_n1;f (ssidsid:banaNFnt*ds},
	}
	ii(lope)ssid:ba*/
ee2 &&	e*ds}cha(lope)ssid:ba*/
ee2&&	esid->ieee80211;
		wpsid:ba*/
ee3}AME*ds}c>a(lope)ssid:ba*/
ee3 %d: Invalid ocv value '%s'.",
			   ltoo large*%etlue[20=   ")
{
ret"_ax_ue[20= l_n1;f (ssidsid:banaNFnt*ds},
	}
	ii(lope)ssid:ba*/
ee3 &&	e*ds}cha(lope)ssid:ba*/
ee3&&	esid->ieee80211;
RITE
static chey(const structglobal_cf (ratct wpa/tr1
	       struglobal_ct wpa_ssid*sid:n
hr}
	iiiiiituct wpa_ssid *ssid)
{
	inn[idx (ssi
hr}
	iiiiiicSG_INFO, "NoasNnst ue);
	if (lef (!val*ds}, *tmplen > 2 * MACSEC_CKNoasN&&			wpsid:ba*/
ee2}AMEl 2 < (ue);
	) sid:ba*/
ee2 %d: Invalid ocv value '%s'.",
			   ltoo shn in%etll 2= lu ")
{
ret"_RO_l 2= l_n1;f (ssidsid:banaNFn
	}
	ii(un	{ I* slope)sf (nn(lope)ssid:ba*/
ee2 &&	esid->ieee80211;
		wpsid:ba*/
ee3}AMEl 2 >((ue);
	) sid:ba*/
ee3 %d: Invalid ocv value '%s'.",
			   ltoo lopes%etll 2= lu ")
{
ret"_ax_l 2= l_n1;f (ssidsid:banaNFn
	}
	ii(un	{ I* slope)sf (nn(lope)ssid:ba*/
ee3 &&	esid->ieee80211;
		wphaD }ew (ssdoasN %d: Invalid ocv value '%s'.",
			   line, val%fd->ocvig fun}ew (ss",
	}
	ii (ssidsid:banaNF &&	esid->ieee80211;
tmp * MACSECdup(oasN&&			wptmp *snprinfig_write_sash, 1ds}cha( (!val*) (((u8an)d_ROAs N 	i(lope)ssid:ba*/
ee1O;t 	ssid->m*ds}i;se*ds}chatmplessid-id ocv valuDEBUGf "%s=urn "'fsid:banaNFnt*ds}i;s;
RITE
static chey(const structcf (ratcroncti bg },
1
	       struglobal_ct wpa_ssid*sid:n
hr}
	iiiituct wpa_ssid *ssid)
{
	inn[idx (ssi
hr}
	iiiicSG_INFO, "NoasNnst ue);
	if (lef (!valtmples(ssid-s;
;
tmp * ;

	if (ratct wpax typel ns, &ONFIG_Wtes)tmp *snprinf%d: Invalid ocv value '%s'.",
			   ld.", l* (ild.
 *%e",
	}
	ii (ssidsid:banaNF &&	esid->ieee80211;
d-sULLructglobal_cf (ratct wpa/tr1sid:nn)
{
	innl(ssidtmpO;t 	ssid->mtmpO;t sid->ieetsrnc chey(const structglobal_cf (ratct wpabiKN
	       struglobal_ct wpa_ssid*sid:n
hr}
	iiiiiituct wpa_ssid *ssid)
{
	inn[idx (ssi
hr}
	iiiiiicSG_INFO, "NoasNnst uuct wpa_sbuf	l*ds}, *tmplen tmp * ;

buftct wpabiKNoasN&&			wp!tmpOig_write_sash, 1ds}cha(uuct wpa_sbuf	l*) (((u8an)d_ROAs N 	i(lope)ssid:ba*/
ee1O;t ;

buftid->m*ds}i;se*ds}chatmplessid-id ocv valuDEBUGf "%s"idsid:banaNF &&;
RITE
static chey(const structcf (ratcroncti eqs;
/g *N
	       struglobal_ct wpa_ssid*sid:n
hr}
 char *puct ctworkid)
{
	inn[idx (ssi
hr}

cSG_INFO, "NOTt,
Nnst [idx*eqs;s;
;
eqs;s * ;

	if (ratct wpaiif izeof(OTE: O;t [fe(lds;s *snprintf(value, 2p(po [fe(lds;sates = NULL;
		ssid->mlds;s &&	eeqs;s * 0, MACS}MS	ssid->m_ROAs iefqs;
/g *I;
"_ROAs iefqs;
/g * * eqs;s;
"RITE
static char  wpaFIG_VHTP2Phey(const structglobal_cf (ratct wpatpv4N
	       struglobal_ct wpa_ssid*sid:n
hr}
 char *puct ctworkid)
{
	inn[idx (ssi
hr}

cSG_INFO, "NoasNnst u32r*ds}LL;   struhostapd_ip, 0,  a @r;s;
		wphostapd_ct wpatp, 0, l ns, & 0, )C<s_strcalue, 2p(po [fe( 0, .af
!byAF_INETOig_write_sash, 1ds}cha(u32r*) (((u8an)d_ROAs N 	i(lope)ssid:ba*/
ee1O;t 	ssmemcpydds}, & 0, .u.v4.s, 0, 	{ Ilessid-id ocv valuDEBUGf "%s	thEx%x"idsid:banaNFn
	}iiiWPA_GET_BE32((u8an)dds}i &&;
RITE
static #ifdef CONFIG_VHTP2P},
	chru(const structcf (ratcroncti couos_zN
	       struglobal_ct wpa_ssid*sid:n
hr}
	iiiiituct wpa_ssid *ssid)
{
	inn[idx (ssi
hr}
	iiiiicSG_INFO, "NoasNnst [	wp!oasates|| !oasa1]f%d: Invalid ocv valuDEBUGf "ine, valcouos_zon s"N&&	esid->ieee80211	_ROAs iecouos_zates  oasate;1	_ROAs iecouos_za1es  oasa1]lessid-id ocv valuDEBUGf "couos_z=urc%c "'intiiicSGAs iecouos_zate,icSGAs iecouos_za1]N; "RITE
static chru(const structcf (ratcroncti Load_dynaNic_eap(ptm	       struglobal_ct wpa_ssid*sid:nituct wpa_ssid *ssid)
{
	int [idx (ssidcoG_INFO, "NsoNnst [idxd-tle sid-id ocv valuDEBUGf "Load_dynaNic_eap=%s"idsoN;NFIG_ue)eods[num_= meth_Load(soN;NFtes);-intsn-2 %d: Invalid ocv valuDEBUGf "twork{ S parstgasoaletwoy Loaded}-  the")
{
ret"reLoadype."sid-} e _FUtes);-if%d: Invalid ocv value '%s'.",
			   lF.", l* (iLoad	dynaNick{ S ")
{
ret"_ meth	urn -1;f (ssidsoN;NFesid->ieee80211;
RITE
static char  wpaFIG_VHTWPSchru(const structcf (ratcroncti uuidN
	       struglobal_ct wpa_ssid*sid:n
hr}
	iituct wpa_ssid *ssid)
{
	inn[idx (ssi
hr}
	iicSG_INFO, "NoasNnst FO, "buf[4te;1	tes)uuida/tr2biKNkas,icSGAs ieuuidN %d: Invalid ocv value '%s'.",
			   line, valUUID1;f (ssN&&	esid->ieee80211	uuidabiK2/tr1
	 As ieuuid||buf_Sturn -1bufNIlessid-id ocv valuDEBUGf "uuid=%s"idbufN; "RITE
static chru(const structcf (ratcroncti device parslptm	       struglobal_ct wpa_ssid*sid:nt char *puct ctworkid)
{
	inn[idx (ssidcoG_INFO, "NoasNnst RITE
stwpi dev parsa/tr2biKNkas,icSGAs iedevice pars)tic chru(const structcf (ratcroncti 	sskums},
N
	       struglobal_ct wpa_ssid*sid:n
hr}
 ituct wpa_ssid *ssid)
{
	inn[idx (ssi
hr}
	icSG_INFO, "NoasNnst [	wp", SEC2biKNkas,icSGAs ie	sskums},
	{ I %d: Invalid ocv value '%s'.",
			   line, val	sskums},
1;f (ssN&&	esid->ieee80211	sid-id ocv valuDEBUGf "	sskums},
=%08x"n
	}iiiWPA_GET_BE32(cSGAs ie	sskums},
)N; "RITE
static chru(const structcf (ratcroncti wpi thod);_}x} m1lptm	       struglobal_ct wpa_ssid*sid:nt char *puct ctworkid)
{
	inn[idx (ssidcoG_INFO, "NoasNnst uuct wpa_sbuf	ltmples(ssi> 2 * MACSEC_CKNoasN / 2po u8an ;s;
		wp!ONFI%d: Invalid ocv value '%s'.",
			   l")
{
ret"ine, valwpi thod);_}x} m11;f (ssN&&	esid->ieee80211n tmp * ;

buft)
		reONFIG_Wtes)tmp %d: Ik * ;

buftcut)tmparONFIG_PRO		wp", SEC2biKNkas,iparONFIINL;
	Onvalid ocv value '%s'.",
			   l")
{
	ret"ine, valwpi thod);_}x} m11;f (ssN&&	e ;

buftid->mtmpO;t s
alue, 2p(po ;11o ;;

buftid->m_ROAs iewci thod);_}x} m1)G_W	_ROAs iewci thod);_}x} m1chatmples} e _FUd: Invalid ocv value '%s'."Can*/) {
nd cned ")
{
ret"_ mo_zopuonwpi thod);_}x} m11N;NFesid->ieee80211;
RITE
static c#ifdef CONFIG_VHTWPS},
	car  wpaFIG_VHTP2Phey(const structcf (ratcroncti sec device parslptm	       struglobal_ct wpa_ssid*sid:nt char *puct ctworkid)
{
	inn[idx (ssidcoG_INFO, "NoasNnst [idx] x;s;
		wp_ROAs ient_lsec device parsse>=if /*SECuDEVICE_TYPES %d: Invalid ocv value '%s'.",
			   ltoo r nylsec device parsl")
{
ret"iteOs"'f (ssN&&	esid->ieee80211n ] xsed_ROAs ient_lsec device parss;s;
		wpwpi dev parsa/tr2biKNkas,icSGAs iesec device pars[] x])Oig_write_sash, 1_ROAs ient_lsec device parss++; "RITE
static chey(const struct parse_croncti pst)pref
conflptm	       struglobal_ct wpa_ssid*sid:nt char *puct ctworkid)
{
	inn[idx (ssidcoG_INFO, "NoasNnst uuct wppst)confnelan exf	re0, M,ann;

un	{ I* stru },
	thods,
	ssid->ocv kas2po u8aot)class,iconfh, 1CONluemat: class:conf,class:conf,...},
	c ')
			p kasNC{PROot)class thatoi[kasN&&
r ns2 * MACSECchrl ns -':'I
#	e		os ns2	rsnprintf(v
gNT( d.",&&
r ns2++; "xconf	thatoi[kas2i;s;
	_nthhods + 1, sizeof( exf,ant_ 	if (meth;etf(turn -1es = sspst)confnel)ritOe		osn	rsnprintf(v
gNT( d.",&&
r exf	ren&&
r exf[nt_].ot)class thot)class&&
r exf[nt_].conf	thconfh, ;nt_++dd;
e ns}* MACSECchrl ns2 -','I
#	e		os ns}* "Line 
		wd[-1] = ' ns++dd;
}
#	ssid->m_ROAs iepst)pref
confI;
"_ROAs iepst)pref
confs  oref; 1_ROAs ient_lpst)pref
confs  nt_;KA-CKN", ssid valuDEBUGf "P2P: Prefer)edsclass/confnelapairs"n
	}iii (u8an)d_ROAs iepst)pref
confn
	}iii _ROAs ient_lpst)pref
confs*(turn -1es = sspst)confnel)rit "RITE
stati
d.",:
#	ssid->mprefIlessid-id ocv value '%s'.",
			   line, valpst)pref
confs/g *"'f (ssN&&	_configp(poc chey(const struct parse_croncti pst)no)goEeqs;lptm	       struglobal_ct wpa_ssid*sid:nt char *puct ctworkid)
{
	inn[idx (ssidcoG_INFO, "NoasNnst [idxd-tlen IG_ue)fqs;
rnfge_/g *_ct wp(&_ROAs iepst)no)goEeqs;idoasN&&	tes);-in< NULL;
	sid-id ocv value '%s'.",
			   line, valpst)no)goEeqs;"'f (ssN&&	esid->ieee80211n sid-id ocv valuDEBUGf "P2P: pst)no)goEeqs;ig fun%u iteOs"'intiiicSGAs iepst)no)goEeqs;.nt_ &&;
RITE
static cey(const struct parse_croncti pst)device pums} *enx_mac, 0, lptm	       struglobal_ct wpa_ssid*sid:nt char *puct ctworkid)
{
	inn[idx (ssidcoG_INFO, "NoasNnst [	wp"w 0, 
aton2Nkas,icSGAs iepst)device pums} *enx_mac, 0, )n< NULL;
	sid-id ocv value '%s')
{
ret",
			   line, valpst)device pums} *enx_mac, 0,  urn "'int 	ii (ssidoasN&&	esid->ieee80211;
RITE
static c#ifdef CONFIG_VHTP2P},
	chru(const structcf (ratcroncti her *nlptm	       struglobal_ct wpa_ssid*sid:nt char *puct ctworkid)
{
	inn[idx (ssidcoG_INFO, "NoasNnst [	wp"w 0, 
aton2Nkas,icSGAs ieher *n)n< NULL;
	sid-id ocv value '%s't",
			   line, valher *n urn "'int 	ii (ssidoasN&&	esid->ieee80211;
RITE
static chey(const structcf (ratcroncti sae_
	{ Islptm	       struglobal_ct wpa_ssid*sid:nt char *puct ctworkid)
{
	inn[idx (ssidcoG_INFO, "NoasNnst [idx*
	{ Is * ;

	if (ratct wpaiif izeof(oasN&&	tes)
	{ Is *snprinf%d: Invalid ocv value '%s'.",
			   line, valsae_
	{ Is urn "'int 	ii (ssidoasN&&	esid->ieee80211;
	ssid->m_ROAs iesae_
	{ IsI;
"_ROAs iesae_
	{ Is =	
	{ IsoritRITE
static chey(const structcf (ratcroncti ap thod);_}lemenxslptm	       struglobal_ct wpa_ssid*sid:nt char *puct ctworkid)
{
	inn[idx (ssidcoG_INFO, "NoasNnst uuct wpa_sbuf	ltmples(ssi> 2 * MACSEC_CKNoasN / 2po u8an ;s;
		wp!ONFI%d: Invalid ocv value '%s'.",
			   line, valap thod);_}lemenxs"'int 	ii (ssN&&	esid->ieee80211n tmp * ;

buft)
		reONFIG_Wtes)tmp %d: Ik * ;

buftcut)tmparONFIG_PRO		wp", SEC2biKNkas,iparONFIINL;
	Onvalid ocv value '%s'.",
			   line, val")
{
	ret"ap thod);_}lemenxs"'f (ssN&&	e ;

buftid->mtmpO;t s
alue, 2p(po ;11o ;;

buftid->m_ROAs ieap thod);_}lemenxs)G_W	_ROAs ieap thod);_}lemenxschatmples} e _FUd: Invalid ocv value '%s'."Can/) {
nd cned _ mo_zopuon")
{
ret"ap thod);_}lemenxs"N;NFesid->ieee80211;
RITE
static char  wpaFIG_VHTCTRL_IFACEhey(const structcf (ratcroncti noEctrlE(macrfacelptm	       struglobal_ct wpa_ssid*sid:nt char *puct ctworkid)
{
	inn[idx (ssidcoG_INFO, "NoasNnst sid-id ocv valuDEBUGf "noEctrlE(macrface -> ctrlE(macrface=prin"O;t 	ssid->mcSGAs iectrlE(macrface)&& cSGAs iectrlE(macrface * 0, MACSRITE
static #ifdef CONFIG_VHTCTRL_IFACE},
	chru(const structcf (rat			 t s(m	    FO, "NnaNFnttuct wpa_ssid *ssid)
{
	in
r}
	iiiiilopes ffsetne
(!valbuf||ue);
	ibuff (n
r}
	iiiii[idx extty-id ocOnst [idx* 0 ue)1(ssil) (((u8an)d_ROAs N 	i(lope)s ffseti;s;
		wp extty-id ocOnFesid->ie	os_nid ocv buf||buff (nn"%s=  \
1;fnaNFnt*20  && sid->ie	os_nid ocv buf||buff (nn"% 1;f*20  &&c chey(const structcf (rat			 /tr1
	    FO, "NnaNFnttuct wpa_ssid *ssid)
{
	in
r}
	iiiiilopes ffsetne
(!valbuf||ue);
	ibuff (n
r}
	iiiii[idx extty-id ocOnst  (!val* 0 ue)1 (!val*) (((u8an)d_ROAs N 	i(lope)s ffseti;sr(ssid-sds;
		wp extty-id ocOnFesisULL	os_nid ocv buf||buff (nn"%s= s\
1;fnaNFn)
{
	re* 0 u?e* 0 u: "null"O;t e _FUtes)!*20  NFesid->ieee802GE(m
		sisULL	os_nid ocv buf||buff (nn"%s1;f*20  && 		wp	os_nid ocv_error(bufONF, Mes)U
		sisULLash, 1sid->ieetsrnc char  wpaFIG_VHTP2Phey(const structcf (rat			 tpv4N
	    FO, "NnaNFnttuct wpa_ssid *ssid)
{
	in
r}
	iiiiiilopes ffsetne
(!valbuf||ue);
	ibuff (n
r}
	iiiiii[idx extty-id ocOnst  a co* 0 ue)1(u8an)d_ROAs N 	i(lope)s ffset;sr(ssid-sds  (!va 0, [INET_ADDRSTRLEN];s;
		wp! 0 u|| !(sst_ntop(AF_INET,a->oar 0, 	{turn -1 0, ))Oig_write_sash, 1		wp extty-id ocOnFesisULL	os_nid ocv buf||buff (nn"%s= s\
1;fnaNFnr 0, )802GE(m
		sisULL	os_nid ocv buf||buff (nn"%s1;f 0, )80& 		wp	os_nid ocv_error(bufONF, Mes)U
		sisULLash, 1sid->ieetsrnc #ifdef CONFIG_VHTP2P},
	char  wpaOFFSET
#un wpaOFFSET
#ifdef CONOFFSET},
	CONOFFSET: G'") ffsetd strd->riablvig fuinparama_ssid *ssituct wure},
	# wp
			OFFSET(v) (( a co*) &(truct wpa_ssid *ssid) NU->v)
	# wp
			FUNC(f) #f||ructcf (ratcroncti  ## f||0, M,aOFFSET(f)||0, M,a0, M	# wp
			FUNCT) _VAR(f) #f||ructcf (ratcroncti  ## f||0, M,a0, M,a0, M,a0, M	# wp
			_INT(f) #f||ructglobal_cf (ratct wpat s,tructcf (rat			 t s,aOFFSET(f)	# wp
			INT(f) _INT(f),a0, M,a0, M	# wp
			INT}RANGE(f||mn_,cmax) _INT(f),a( a co*) mn_,c( a co*) max	# wp
			_STR(f) #f||ructglobal_cf (ratct wparuc,tructcf (rat			 ruc,tOFFSET(f)	# wp
			STR(f) _STR(f),a0, M,a0, M	# wp
			STR}RANGE(f||mn_,cmax) _STR(f),a( a co*) mn_,c( a co*) max	# wp
			BIN(f) #f||ructglobal_cf (ratct wpabn_,c0, M,aOFFSET(f)||0, M,a0, M	# wp
			IPV4(f) #f||ructglobal_cf (ratct wpatpv4,tructcf (rat			 tpv4,t \
	OFFSET(f)||0, M,a0, M	hey(cons 	       struglobal_ct wpa_ssidglobal_n (.ps[es  {har  wpaFIG_VHTCTRL_IFACEh	{	STR(ctrlE(macrface)_S0 },h	{	FUNCT) _VAR(noEctrlE(macrface)_S0 },h	{	STR(ctrlE(macrface_
	{ I)_S0 } CONde excned a*/, #ifdef CONFIG_VHTCTRL_IFACE},
	
#endif /* CON,ACSECh	{	INT}RANGE(ds;	{ kums},
,a1,c3)_S0 },h#e _FU(ap_max_in
ACSECig_pt{	INT}RANGE(ds;	{ kums},
,a1,c2)_S0 },h#e{ INT(ap_max_in
ACSECig_pt{	INT(ap) },
)_S0 },h	{	FUNC(bg },
)_S0 },h##endif /* CON,ESHpt{	INT(user_mp
)_S0 },h	{	INT}RANGE(_ax_[num_linkt,  _S255)_S0 },h	{	INT(_else_ax_inNT_RAak))_S0 },h	{	INT(dot11RSNASAERITransP FUNC)_S0 },h#e{ INT(ap_max_in
ESHig_pt{	INT(NT_Rblv_ },
	offLoad)_S0 },h	{	INT(fas}netwuHT)_S0 },h	{	STR(opensc_eng
		_	{ S)_S0 },h	{	STR(pkcs11_eng
		_	{ S)_S0 },h	{	STR(pkcs11_modul	_	{ S)_S0 },h	{	STR(openssl_ciphums)_S0 },h	{	STR(pcscnetader)_S0 },h	{	STR(pcscnpin)_S0 },h	{	INT(external_sim)_S0 },h	{	STR(de_kum_e neeI_S0 },h	{	INT(dot11RSNACf (raPMKLgfersmsI_S0 },h	{	INT(dot11RSNACf (raPMKRtwuHTTNFIG_MESI_S0 },h	{	INT(dot11RSNACf (raSATsmsout)_S0 },h##e* wpaFIG_VHT) _FUNC(f)WRITEpt{	INT(u(roami_ROAs N_S0 },h#e{ INT(ap_max_in) _FUNC(f)WRITEig_pt{	FUNCT) _VAR(Load_dynaNic_eap)_S0 },h##endif /* CONWPSc	{	FUNC(uuidN, CFG_CHANGED_UUID },h	{	INT}RANGE(wuHo_uuid|| _S1)_S0 },h	{	STR}RANGE(device naNFnr _SWPSuDEV_NAME
f /*	{ I,		  CFG_CHANGED_DEVICE_NAME },h	{	STR}RANGE(manufacwurernr _S64N, CFG_CHANGED_WPSuSTRING },h	{	STR}RANGE(model naNFnr _S32N, CFG_CHANGED_WPSuSTRING },h	{	STR}RANGE(model n(MSG_nr _S32N, CFG_CHANGED_WPSuSTRING },h	{	STR}RANGE(serial n(MSG_nr _S32N, CFG_CHANGED_WPSuSTRING },h	{	FUNC(device pars), CFG_CHANGED_DEVICE_TYPE },h	{	FUNC(	sskums},
), CFG_CHANGED_OSrVERSION },h	{	STR(cf (rat_ meths), CFG_CHANGED__max_in
ETHODS },h	{	INT}RANGE(wpi cre_lcronctiing,  _S2)_S0 },h	{	INT}RANGE(wpi cre_lg *csae|| _S1)_S0 },h	{	FUNC(wci thod);_}x} m1), CFG_CHANGED_VENDOR_EXTENSION },h#ifdef CONFIG_VHTWPS},
	ar  wpaFIG_VHTP2Ph	{	FUNC(sec device pars), CFG_CHANGED_SECuDEVICE_TYPE },h	{	INT(pst)/g *en
reg)class), CFG_CHANGED_P2P_LISTEN_CHANNEL },h	{	INT(pst)/g *en
confnel), CFG_CHANGED_P2P_LISTEN_CHANNEL },h	{	INT(pst)oper
reg)class), CFG_CHANGED_P2P_OPER_CHANNEL },h	{	INT(pst)oper
confnel), CFG_CHANGED_P2P_OPER_CHANNEL },h	{	INT}RANGE(pst)goE(macnl|| _S15)_S0 },h	{	STR(pst).y_l postfix), CFG_CHANGED_P2P_s)


POSTFIX },h	{	INT}RANGE(pums} *enx_excofnect|| _S1)_S0 },h	{	INT}RANGE(pst)imara_bss|| _S1)_SCFG_CHANGED_P2P_INTRA_BSS },h	{	INT(pst)
	{ I_idle)_S0 },h	{	INT}RANGE(pst)goEeqs;
confge_;	{icy|| _SP2P_GO0FREQ_MOVE
f /)_S0 },h	{	INT}RANGE(pst){ STphrawpaONF, 8_S63I,		  CFG_CHANGED_P2P_PASSPHRASE
	{ (},h	{	FUNC(pst)pref
confI_SCFG_CHANGED_P2P_PREF_CHAN(},h	{	FUNC(pst)no)goEeqs;I_SCFG_CHANGED_P2P_PREF_CHAN(},h	{	INT}RANGE(pst)g *ccli
confn| _S1)_S0 },h	{	INT}RANGE(pst)oprsme);
/g *en
confn| _S1)_S0 },h	{	INT(pst)goEht40)_S0 },h	{	INT(pst)goEvht)_S0 },h	{	INT(pst)goEhsI_S0 },h	{	INT(pst)dT_Rblvd)_S0 },h	{	INT}RANGE(pst)goEctwindown| _S127I_S0 },h	{	INT(pst)no)g	{ I_iface)_S0 },h	{	INT}RANGE(pst)ignorv_ hare_leqs;id _S1)_S0 },h	{	IPV4(tp, 0, )go)_S0 },h	{	IPV4(tp, 0, )mask)_S0 },h	{	IPV4(tp, 0, )ey(rt)_S0 },h	{	IPV4(tp, 0, )&en _S0 },h	{	INT}RANGE(pst)cli
crobe|| _S1)_S0 },h	{	INT(pst)device random_mac, 0, )_S0 },h	{	FUNC(pst)device pums} *enx_mac, 0, )_S0 },h	{	INT(pst)(macrface_random_mac, 0, )_S0 },h#ifdef CONFIG_VHTP2P},
		{	FUNC(couos_z), CFG_CHANGED__mUNTRY },h	{	INT(assE_ax_couos)_S0 },h	{	INT(assEexpi)
 * @_agF)_S0 },h	{	INT(assEexpi)
 * @_ },
	couos _S0 },h	{	INT}RANGE(filacr).y_lsn| _S1)_S0 },h	{	INT}RANGE(filacr) /* , -10 _S0)_S0 },h	{	INT(_ax_nt_lsta)_S0 },h	{	INT}RANGE(ap)isolnedn| _S1)_S0 },h	{	INT}RANGE(NT_Rss, slow_ackn| _S1)_S0 },har  wpaFIG_VHTHS20h	{	INT}RANGE(hs20n| _S1)_S0 },haifdef CONFIG_VHTHS20ig_pt{	INT}RANGE((macrlisting,  _S1)_S0 },h	{	FUNC(her *n)_S0 },h	{	INT}RANGE(auncti  y listNpars|| _S15)_S0 },h	{	INT}RANGE(goE(macrlisting,  _S1)_S0 },h	{	INT}RANGE(goEauncti  y listNpars|| _S15)_S0 },h	{	INT}RANGE(goE(macrnet|| _S1)_S0 },h	{	INT}RANGE(goEvenue_
	{ I,  _S255)_S0 },h	{	INT}RANGE(goEvenue_pars|| _S255)_S0 },h	{	INT}RANGE(pb sii_e1,o _S1)_S0 },h	{	STR(wuHo },
)_S0 },h	{	INT}RANGE(wpi nfc dev_pw_id|| x10n| xffffI,		  CFG_CHANGED_NFC_PASSWORD_TOK{ (},h	{	BIN(wpi nfc dh_pubassw, CFG_CHANGED_NFC_PASSWORD_TOK{ (},h	{	BIN(wpi nfc dh_pe_kassw, CFG_CHANGED_NFC_PASSWORD_TOK{ (},h	{	BIN(wpi nfc dev_pww, CFG_CHANGED_NFC_PASSWORD_TOK{ (},h	{	STR(}x} id) },
	_ OFF&en _SCFG_CHANGED_EXT_PW_BACK{ D },h	{	INT(pst)goE_ax_inNT_RAak))_S0 },h	{	INT}RANGE(auHo_(macrlisting,  _S1)_S0 },h	{	INT(okc)_S0 },h	{	INT(pmf)_S0 },h	{	FUNC(sae_
	{ IsI_S0 },h	{	INT(drsm pumUNC)_S0 },h	{	INT(aeacof_(ma)_S0 },h	{	FUNC(ap thod);_}lemenxs)_S0 },h	{	INT}RANGE(ignorv_MES_ },
	FIG,  _S1)_S0 },h	{	FUNC(fqs;
/g *I_S0 },h	{	INT( },
	cuitle,qI_S0 },h	{	INT( }heS_ },
	(macr20  _S0 },h	{	INT( }heS_ },
	ey(rt_dela) _S0 },h	{	INT(tdlsEexternal_c_rtrol _S0},h	{	STR(osu)dTr)_S0 },h	{	STR(wowl,
	triggums)_SCFG_CHANGED_WOWLAN_TRIGGERS },h	{	INT(pst).(tich_dela) _S0},h	{	INT(_ac, 0, )_S0 },h	{	INT(rand, 0, 
/gfersms)_S0 },h	{	INT(preRss, s_ac, 0, )_S0 },h	{	INT(d) },
	{_offLoad _S0},h	{	INT(id) ive) },
)_S0 },h	{	INT(reRss, ssaNF_bss"oprsm)_S0 },h	{	INT(wpi Oka_cak)1_S0},har  wpaFIG_VHTFSTh	{	STR}RANGE(fst)
	{ I_id,a1,cFST
f /*GROUP_ID*	{ I,S0 },h	{	INT}RANGE(f *_cka_cak)'a1,cFST
f /*PRI _VALUEI,S0 },h	{	INT}RANGE(f *_llt'a1,cFST
f /*LLT}
S)_S0 },haifdef CONFIG_VHTFSTig_pt{	INT}RANGE(	{ S_inntb|| _S1)_S0 },h	{	INT}RANGE(wct rscnetlax
 * @,o _S1)_S0 },h	{	STR( }heS_ },
	pl,
s)_SCFG_CHANGED_SCHED_SCAN_PLANS },h##endif /* CON,BOiS{	STR(nof_pref
confI_S0 },h	{	INT}RANGE(_boEcellx_mcs, 
BO0CELL_CAPA_AVAILABLE,
	}iii 
BO0CELL_CAPA_NOT_SUPPORTED)_S0 },h	{	INT}RANGE(NT_Rss, simSTRonte /* CONFIG_MES, -12 _S0)_S0 },h	{	INT}RANGE(oncnr _S3)_S0 },h#e{ INT(ap_max_in
BO},
		{	INT(gas_ 0, cti3I,S0 },h	{	INT}RANGE(ft_lqsspondG_nr _S1)_S0 },h	{	INT}RANGE(ft_linitiato_nr _S1)_S0 },h	{	INT(gas_rand, 0, 
/gfersms)_S0 },h	{	INT}RANGE(gas_rand,_ac, 0, ,  _S2)_S0 },h	{	INT}RANGE(dpptcf (ratcronctiing,  _S2)_S0 },h	{	INT}RANGE(co1, siifflqs a_ping,  _S1)_S0 },h	{	INT}RANGE(bti noEflush_when
dow@,o _S1)_S0 },hc; c#un wpaFUNCc#un wpa_INTc#un wpaINTc#un wpaINT}RANGEc#un wpa_STRc#un wpaSTRc#un wpaSTR}RANGEc#un wpaBINc#un wpaIPV4	# wp
			ieldGLOBAL_FIELDS ARRAY_SIZE(global_n (.ps)*chtruct wpa_confidsid-OTE: struct wpa_ssid *ssid)
{
	ine
(!valbuf||ue);
	ibuff (Nnst [idxd-sult	thods,ue);
	iids;
 != EAP_VEND		foieldGLOBAL_FIELDSo_zallLL;
	m	       struglobal_ct wpa_ssid*n (.pa= &global_n (.ps[i]LL;
[idxtmplen 
		wp!n (.p->get)
}

cSGpinuelen 
tmp * n (.p->get(n (.p->naNFnr)
{
	ine(lope)sn (.p->e nee1,)
{
	rbuf||buff (nn1I
#	e		ostmp < NUf(v
alue, 2-1; "
buf	+hatmplessbuff (e-hatmplessd-sult	+hatmples} 1sid->ieetsultdd/*chtruct wpa_confi			 OTE: N
	    FO, "NnaNFnttuct wpa_ssid *ssid)
{
	in
r}
	
(!valbuf||ue);
	ibuff (Nnst ue);
	iids;
 != EAP_VEND		foieldGLOBAL_FIELDSo_zallLL;
	m	       struglobal_ct wpa_ssid*n (.pa= &global_n (.ps[i]LL
RO		wp	os_memsetnaNFntn (.p->naNF)
!by0)
}

cSGpinuele 
		wp!n (.p->get)
}

d[-1] = 'sid->ien (.p->get(naNFnr)
{
	ine(lope)sn (.p->e nee1,)
{
	rrbuf||buff (nn0);L; wpa_configp(poc chtruct wpa_confi			 nt_lglobal_n (.p naNFs( a cNnst RITE
stieldGLOBAL_FIELDSooc ch
	    FO, "Nct wpa_confi			 global_n (.p naNF(un	{ I* stru inn[idx*noEvarNnst [	wpie>=iieldGLOBAL_FIELDSfig_write_string_t [	wpnoEvarNn		*noEvara= !global_n (.ps[i].e nee1&& sid->ieglobal_n (.ps[i].naNF;tc chtruct wpa_conficroncti globaltruct wpa_ssid *ssid)
{
	ine
(!valkas,i[idx (ssNnst ue);
	iids [idxd-t	thods;
 != EAP_VEND		foieldGLOBAL_FIELDSo_zallLL;
	m	       struglobal_ct wpa_ssid*n (.pa= &global_n (.ps[i]LL;
ue);
	if> 2 * MACSEC_CKNn (.p->naNF);
RO		wp	os_menmsetkasntn (.p->naNF,if> 2)
!by0 ||
	}iii oasaf> 2]
!by'=')
}

cSGpinuelen 
[fe(l (.p->e nser(l (.pnn)
{
	innl(ssid ns}+ f> 2 +n1IINL;
	Onvalid ocv value '%s'.",
			   ld.", l* (i")
{
	ret"ld.
 *urn -1;f (ssidoasN&&	e
aluULLash,d	11wc[fe(l (.p->confged STRe *snCFG_CHANGED_NFC_PASSWORD_TOK{ )
}

cSGAs iewci nfc pw_Poinsid *ssi=*1; "
cSGAs ieconfged 


#ifndes |* n (.p->confged STRe;a

d[-1] = }t [	wpie==iieldGLOBAL_FIELDSf {har  wpaFIG_VHTAP
RO		wp	os_menmsetkasnt"wmm_ac_1;f7If = NULL;
	O (!valtmp * MACSECchrl ns -'=')sid	 		wptmp *snprinf%d: I	 		wp (ss < NUf(v
v
alue, 2-1; "
	Onvalid ocv value '%s'.",
			   line, val (ss ")
{
		ret"urn "'f (ssidoasN&&	e

alue, 2-1; "
	11wchltmp++/* NO_CONFe
		wphostapd_a_confiwmm_acm_ROAs iewmm_ac_e nees, kas'int *r	 dtmpOf%d: I	 nvalid ocv value '%s'.",
			   line, valWMM ")
{
		ret"AC iteO"'f (ssN&&	e 
alue, 2-1; "
	11wcc #ifdef CONFIG_VHTAP},
		 		wp (ss < NUf(v
alue, 2-1; "
nvalid ocv value '%s'.",
			   lunknow@uglobal n (.p*urn -1;int 	ii (ssidoasN