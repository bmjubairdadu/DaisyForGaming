/*
 * WPA Supplicant
 * Copyright (c) 2003-2012, Jouni Malinen <j@w1.fi>
 *
 * This software may be distributed under the terms of the BSD license.
 * See README for more details.
 *
 * This file implements functions for registering and unregistering
 * %wpa_supplicant interfaces. In addition, this file contains number of
 * functions for managing network connections.
 */

#include "includes.h"

#include "common.h"
#include "crypto/random.h"
#include "crypto/sha1.h"
#include "eapol_supp/eapol_supp_sm.h"
#include "eap_peer/eap.h"
#include "eap_server/eap_methods.h"
#include "rsn_supp/wpa.h"
#include "eloop.h"
#include "config.h"
#include "utils/ext_password.h"
#include "l2_packet/l2_packet.h"
#include "wpa_supplicant_i.h"
#include "driver_i.h"
#include "ctrl_iface.h"
#include "pcsc_funcs.h"
#include "common/version.h"
#include "rsn_supp/preauth.h"
#include "rsn_supp/pmksa_cache.h"
#include "common/wpa_ctrl.h"
#include "common/ieee802_11_defs.h"
#include "p2p/p2p.h"
#include "blacklist.h"
#include "wpas_glue.h"
#include "wps_supplicant.h"
#include "ibss_rsn.h"
#include "sme.h"
#include "gas_query.h"
#include "ap.h"
#include "p2p_supplicant.h"
#include "wifi_display.h"
#include "notify.h"
#include "bgscan.h"
#include "autoscan.h"
#include "bss.h"
#include "scan.h"
#include "offchannel.h"
#include "hs20_supplicant.h"

const char *wpa_supplicant_version =
"wpa_supplicant v" VERSION_STR "\n"
"Copyright (c) 2003-2012, Jouni Malinen <j@w1.fi> and contributors";

const char *wpa_supplicant_license =
"This software may be distributed under the terms of the BSD license.\n"
"See README for more details.\n"
#ifdef EAP_TLS_OPENSSL
"\nThis product includes software developed by the OpenSSL Project\n"
"for use in the OpenSSL Toolkit (http://www.openssl.org/)\n"
#endif /* EAP_TLS_OPENSSL */
;

#ifndef CONFIG_NO_STDOUT_DEBUG
/* Long text divided into parts in order to fit in C89 strings size limits. */
const char *wpa_supplicant_full_license1 =
"";
const char *wpa_supplicant_full_license2 =
"This software may be distributed under the terms of the BSD license.\n"
"\n"
"Redistribution and use in source and binary forms, with or without\n"
"modification, are permitted provided that the following conditions are\n"
"met:\n"
"\n";
const char *wpa_supplicant_full_license3 =
"1. Redistributions of source code must retain the above copyright\n"
"   notice, this list of conditions and the following disclaimer.\n"
"\n"
"2. Redistributions in binary form must reproduce the above copyright\n"
"   notice, this list of conditions and the following disclaimer in the\n"
"   documentation and/or other materials provided with the distribution.\n"
"\n";
const char *wpa_supplicant_full_license4 =
"3. Neither the name(s) of the above-listed copyright holder(s) nor the\n"
"   names of its contributors may be used to endorse or promote products\n"
"   derived from this software without specific prior written permission.\n"
"\n"
"THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS\n"
"\"AS IS\" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT\n"
"LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR\n"
"A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT\n";
const char *wpa_supplicant_full_license5 =
"OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,\n"
"SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT\n"
"LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,\n"
"DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY\n"
"THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT\n"
"(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE\n"
"OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.\n"
"\n";
#endif /* CONFIG_NO_STDOUT_DEBUG */

extern int wpa_debug_level;
extern int wpa_debug_show_keys;
extern int wpa_debug_timestamp;
extern struct wpa_driver_ops *wpa_drivers[];

/* Configure default/group WEP keys for static WEP */
int wpa_set_wep_keys(struct wpa_supplicant *wpa_s, struct wpa_ssid *ssid)
{
	int i, set = 0;

	for (i = 0; i < NUM_WEP_KEYS; i++) {
		if (ssid->wep_key_len[i] == 0)
			continue;

		set = 1;
		wpa_drv_set_key(wpa_s, WPA_ALG_WEP, NULL,
				i, i == ssid->wep_tx_keyidx, NULL, 0,
				ssid->wep_key[i], ssid->wep_key_len[i]);
	}

	return set;
}


static int wpa_supplicant_set_wpa_none_key(struct wpa_supplicant *wpa_s,
					   struct wpa_ssid *ssid)
{
	u8 key[32];
	size_t keylen;
	enum wpa_alg alg;
	u8 seq[6] = { 0 };

	/* IBSS/WPA-None uses only one key (Group) for both receiving and
	 * sending unicast and multicast packets. */

	if (ssid->mode != WPAS_MODE_IBSS) {
		wpa_msg(wpa_s, MSG_INFO, "WPA: Invalid mode %d (not "
			"IBSS/ad-hoc) for WPA-None", ssid->mode);
		return -1;
	}

	if (!ssid->psk_set) {
		wpa_msg(wpa_s, MSG_INFO, "WPA: No PSK configured for "
			"WPA-None");
		return -1;
	}

	switch (wpa_s->group_cipher) {
	case WPA_CIPHER_CCMP:
		os_memcpy(key, ssid->psk, 16);
		keylen = 16;
		alg = WPA_ALG_CCMP;
		break;
	case WPA_CIPHER_GCMP:
		os_memcpy(key, ssid->psk, 16);
		keylen = 16;
		alg = WPA_ALG_GCMP;
		break;
	case WPA_CIPHER_TKIP:
		/* WPA-None uses the same Michael MIC key for both TX and RX */
		os_memcpy(key, ssid->psk, 16 + 8);
		os_memcpy(key + 16 + 8, ssid->psk + 16, 8);
		keylen = 32;
		alg = WPA_ALG_TKIP;
		break;
	default:
		wpa_msg(wpa_s, MSG_INFO, "WPA: Invalid group cipher %d for "
			"WPA-None", wpa_s->group_cipher);
		return -1;
	}

	/* TODO: should actually remember the previously used seq#, both for TX
	 * and RX from each STA.. */

	return wpa_drv_set_key(wpa_s, alg, NULL, 0, 1, seq, 6, key, keylen);
}


static void wpa_supplicant_timeout(void *eloop_ctx, void *timeout_ctx)
{
	struct wpa_supplicant *wpa_s = eloop_ctx;
	const u8 *bssid = wpa_s->bssid;
	if (is_zero_ether_addr(bssid))
		bssid = wpa_s->pending_bssid;
	wpa_msg(wpa_s, MSG_INFO, "Authentication with " MACSTR " timed out.",
		MAC2STR(bssid));
	wpa_blacklist_add(wpa_s, bssid);
	wpa_sm_notify_disassoc(wpa_s->wpa);
	wpa_supplicant_disassociate(wpa_s, WLAN_REASON_DEAUTH_LEAVING);
	wpa_s->reassociate = 1;

	/*
	 * If we timed out, the AP or the local radio may be busy.
	 * So, wait a second until scanning again.
	 */
	wpa_supplicant_req_scan(wpa_s, 1, 0);

#ifdef CONFIG_P2P
	if (wpa_s->global->p2p_cb_on_scan_complete && !wpa_s->global->p2p_disabled &&
	    wpa_s->global->p2p != NULL) {
		wpa_s->global->p2p_cb_on_scan_complete = 0;
		if (p2p_other_scan_completed(wpa_s->global->p2p) == 1) {
			wpa_dbg(wpa_s, MSG_DEBUG, "P2P: Pending P2P operation "
				"continued after timed out authentication");
		}
	}
#endif /* CONFIG_P2P */
}


/**
 * wpa_supplicant_req_auth_timeout - Schedule a timeout for authentication
 * @wpa_s: Pointer to wpa_supplicant data
 * @sec: Number of seconds after which to time out authentication
 * @usec: Number of microseconds after which to time out authentication
 *
 * This function is used to schedule a timeout for the current authentication
 * attempt.
 */
void wpa_supplicant_req_auth_timeout(struct wpa_supplicant *wpa_s,
				     int sec, int usec)
{
	if (wpa_s->conf && wpa_s->conf->ap_scan == 0 &&
	    (wpa_s->drv_flags & WPA_DRIVER_FLAGS_WIRED))
		return;

	wpa_dbg(wpa_s, MSG_DEBUG, "Setting authentication timeout: %d sec "
		"%d usec", sec, usec);
	eloop_cancel_timeout(wpa_supplicant_timeout, wpa_s, NULL);
	eloop_register_timeout(sec, usec, wpa_supplicant_timeout, wpa_s, NULL);
}


/**
 * wpa_supplicant_cancel_auth_timeout - Cancel authentication timeout
 * @wpa_s: Pointer to wpa_supplicant data
 *
 * This function is used to cancel authentication timeout scheduled with
 * wpa_supplicant_req_auth_timeout() and it is called when authentication has
 * been completed.
 */
void wpa_supplicant_cancel_auth_timeout(struct wpa_supplicant *wpa_s)
{
	wpa_dbg(wpa_s, MSG_DEBUG, "Cancelling authentication timeout");
	eloop_cancel_timeout(wpa_supplicant_timeout, wpa_s, NULL);
	wpa_blacklist_del(wpa_s, wpa_s->bssid);
}


/**
 * wpa_supplicant_initiate_eapol - Configure EAPOL state machine
 * @wpa_s: Pointer to wpa_supplicant data
 *
 * This function is used to configure EAPOL state machine based on the selected
 * authentication mode.
 */
void wpa_supplicant_initiate_eapol(struct wpa_supplicant *wpa_s)
{
#ifdef IEEE8021X_EAPOL
	struct eapol_config eapol_conf;
	struct wpa_ssid *ssid = wpa_s->current_ssid;

#ifdef CONFIG_IBSS_RSN
	if (ssid->mode == WPAS_MODE_IBSS &&
	    wpa_s->key_mgmt != WPA_KEY_MGMT_NONE &&
	    wpa_s->key_mgmt != WPA_KEY_MGMT_WPA_NONE) {
		/*
		 * RSN IBSS authentication is per-STA and we can disable the
		 * per-BSSID EAPOL authentication.
		 */
		eapol_sm_notify_portControl(wpa_s->eapol, ForceAuthorized);
		eapol_sm_notify_eap_success(wpa_s->eapol, TRUE);
		eapol_sm_notify_eap_fail(wpa_s->eapol, FALSE);
		return;
	}
#endif /* CONFIG_IBSS_RSN */

	eapol_sm_notify_eap_success(wpa_s->eapol, FALSE);
	eapol_sm_notify_eap_fail(wpa_s->eapol, FALSE);

	if (wpa_s->key_mgmt == WPA_KEY_MGMT_NONE ||
	    wpa_s->key_mgmt == WPA_KEY_MGMT_WPA_NONE)
		eapol_sm_notify_portControl(wpa_s->eapol, ForceAuthorized);
	else
		eapol_sm_notify_portControl(wpa_s->eapol, Auto);

	os_memset(&eapol_conf, 0, sizeof(eapol_conf));
	if (wpa_s->key_mgmt == WPA_KEY_MGMT_IEEE8021X_NO_WPA) {
		eapol_conf.accept_802_1x_keys = 1;
		eapol_conf.required_keys = 0;
		if (ssid->eapol_flags & EAPOL_FLAG_REQUIRE_KEY_UNICAST) {
			eapol_conf.required_keys |= EAPOL_REQUIRE_KEY_UNICAST;
		}
		if (ssid->eapol_flags & EAPOL_FLAG_REQUIRE_KEY_BROADCAST) {
			eapol_conf.required_keys |=
				EAPOL_REQUIRE_KEY_BROADCAST;
		}

		if (wpa_s->conf && (wpa_s->drv_flags & WPA_DRIVER_FLAGS_WIRED))
			eapol_conf.required_keys = 0;
	}
	if (wpa_s->conf)
		eapol_conf.fast_reauth = wpa_s->conf->fast_reauth;
	eapol_conf.workaround = ssid->eap_workaround;
	eapol_conf.eap_disabled =
		!wpa_key_mgmt_wpa_ieee8021x(wpa_s->key_mgmt) &&
		wpa_s->key_mgmt != WPA_KEY_MGMT_IEEE8021X_NO_WPA &&
		wpa_s->key_mgmt != WPA_KEY_MGMT_WPS;
	eapol_sm_notify_config(wpa_s->eapol, &ssid->eap, &eapol_conf);
#endif /* IEEE8021X_EAPOL */
}


/**
 * wpa_supplicant_set_non_wpa_policy - Set WPA parameters to non-WPA mode
 * @wpa_s: Pointer to wpa_supplicant data
 * @ssid: Configuration data for the network
 *
 * This function is used to configure WPA state machine and related parameters
 * to a mode where WPA is not enabled. This is called as part of the
 * authentication configuration when the selected network does not use WPA.
 */
void wpa_supplicant_set_non_wpa_policy(struct wpa_supplicant *wpa_s,
				       struct wpa_ssid *ssid)
{
	int i;

	if (ssid->key_mgmt & WPA_KEY_MGMT_WPS)
		wpa_s->key_mgmt = WPA_KEY_MGMT_WPS;
	else if (ssid->key_mgmt & WPA_KEY_MGMT_IEEE8021X_NO_WPA)
		wpa_s->key_mgmt = WPA_KEY_MGMT_IEEE8021X_NO_WPA;
	else
		wpa_s->key_mgmt = WPA_KEY_MGMT_NONE;
	wpa_sm_set_ap_wpa_ie(wpa_s->wpa, NULL, 0);
	wpa_sm_set_ap_rsn_ie(wpa_s->wpa, NULL, 0);
	wpa_sm_set_assoc_wpa_ie(wpa_s->wpa, NULL, 0);
	wpa_s->pairwise_cipher = WPA_CIPHER_NONE;
	wpa_s->group_cipher = WPA_CIPHER_NONE;
	wpa_s->mgmt_group_cipher = 0;

	for (i = 0; i < NUM_WEP_KEYS; i++) {
		if (ssid->wep_key_len[i] > 5) {
			wpa_s->pairwise_cipher = WPA_CIPHER_WEP104;
			wpa_s->group_cipher = WPA_CIPHER_WEP104;
			break;
		} else if (ssid->wep_key_len[i] > 0) {
			wpa_s->pairwise_cipher = WPA_CIPHER_WEP40;
			wpa_s->group_cipher = WPA_CIPHER_WEP40;
			break;
		}
	}

	wpa_sm_set_param(wpa_s->wpa, WPA_PARAM_RSN_ENABLED, 0);
	wpa_sm_set_param(wpa_s->wpa, WPA_PARAM_KEY_MGMT, wpa_s->key_mgmt);
	wpa_sm_set_param(wpa_s->wpa, WPA_PARAM_PAIRWISE,
			 wpa_s->pairwise_cipher);
	wpa_sm_set_param(wpa_s->wpa, WPA_PARAM_GROUP, wpa_s->group_cipher);
#ifdef CONFIG_IEEE80211W
	wpa_sm_set_param(wpa_s->wpa, WPA_PARAM_MGMT_GROUP,
			 wpa_s->mgmt_group_cipher);
#endif /* CONFIG_IEEE80211W */

	pmksa_cache_clear_current(wpa_s->wpa);
}


void free_hw_features(struct wpa_supplicant *wpa_s)
{
	int i;
	if (wpa_s->hw.modes == NULL)
		return;

	for (i = 0; i < wpa_s->hw.num_modes; i++) {
		os_free(wpa_s->hw.modes[i].channels);
		os_free(wpa_s->hw.modes[i].rates);
	}

	os_free(wpa_s->hw.modes);
	wpa_s->hw.modes = NULL;
}


static void wpa_supplicant_cleanup(struct wpa_supplicant *wpa_s)
{
	bgscan_deinit(wpa_s);
	autoscan_deinit(wpa_s);
	scard_deinit(wpa_s->scard);
	wpa_s->scard = NULL;
	wpa_sm_set_scard_ctx(wpa_s->wpa, NULL);
	eapol_sm_register_scard_ctx(wpa_s->eapol, NULL);
	l2_packet_deinit(wpa_s->l2);
	wpa_s->l2 = NULL;
	if (wpa_s->l2_br) {
		l2_packet_deinit(wpa_s->l2_br);
		wpa_s->l2_br = NULL;
	}

	if (wpa_s->conf != NULL) {
		struct wpa_ssid *ssid;
		for (ssid = wpa_s->conf->ssid; ssid; ssid = ssid->next)
			wpas_notify_network_removed(wpa_s, ssid);
	}

	os_free(wpa_s->confname);
	wpa_s->confname = NULL;

	wpa_sm_set_eapol(wpa_s->wpa, NULL);
	eapol_sm_deinit(wpa_s->eapol);
	wpa_s->eapol = NULL;

	rsn_preauth_deinit(wpa_s->wpa);

#ifdef CONFIG_TDLS
	wpa_tdls_deinit(wpa_s->wpa);
#endif /* CONFIG_TDLS */

	pmksa_candidate_free(wpa_s->wpa);
	wpa_sm_deinit(wpa_s->wpa);
	wpa_s->wpa = NULL;
	wpa_blacklist_clear(wpa_s);

	wpa_bss_deinit(wpa_s);

	wpa_supplicant_cancel_scan(wpa_s);
	wpa_supplicant_cancel_auth_timeout(wpa_s);
	eloop_cancel_timeout(wpa_supplicant_stop_countermeasures, wpa_s, NULL);
#ifdef CONFIG_DELAYED_MIC_ERROR_REPORT
	eloop_cancel_timeout(wpa_supplicant_delayed_mic_error_report,
			     wpa_s, NULL);
#endif /* CONFIG_DELAYED_MIC_ERROR_REPORT */

	wpas_wps_deinit(wpa_s);

	wpabuf_free(wpa_s->pending_eapol_rx);
	wpa_s->pending_eapol_rx = NULL;

#ifdef CONFIG_IBSS_RSN
	ibss_rsn_deinit(wpa_s->ibss_rsn);
	wpa_s->ibss_rsn = NULL;
#endif /* CONFIG_IBSS_RSN */

	sme_deinit(wpa_s);

#ifdef CONFIG_AP
	wpa_supplicant_ap_deinit(wpa_s);
#endif /* CONFIG_AP */

#ifdef CONFIG_P2P
	wpas_p2p_deinit(wpa_s);
#endif /* CONFIG_P2P */

#ifdef CONFIG_OFFCHANNEL
	offchannel_deinit(wpa_s);
#endif /* CONFIG_OFFCHANNEL */

	wpa_supplicant_cancel_sched_scan(wpa_s);

	os_free(wpa_s->next_scan_freqs);
	wpa_s->next_scan_freqs = NULL;

	gas_query_deinit(wpa_s->gas);
	wpa_s->gas = NULL;

	free_hw_features(wpa_s);

	os_free(wpa_s->bssid_filter);
	wpa_s->bssid_filter = NULL;

	wnm_bss_keep_alive_deinit(wpa_s);

	ext_password_deinit(wpa_s->ext_pw);
	wpa_s->ext_pw = NULL;

	wpabuf_free(wpa_s->last_gas_resp);

	os_free(wpa_s->last_scan_res);
	wpa_s->last_scan_res = NULL;
}


/**
 * wpa_clear_keys - Clear keys configured for the driver
 * @wpa_s: Pointer to wpa_supplicant data
 * @addr: Previously used BSSID or %NULL if not available
 *
 * This function clears the encryption keys that has been previously configured
 * for the driver.
 */
void wpa_clear_keys(struct wpa_supplicant *wpa_s, const u8 *addr)
{
	if (wpa_s->keys_cleared) {
		/* Some drivers (e.g., ndiswrapper & NDIS drivers) seem to have
		 * timing issues with keys being cleared just before new keys
		 * are set or just after association or something similar. This
		 * shows up in group key handshake failing often because of the
		 * client not receiving the first encrypted packets correctly.
		 * Skipping some of the extra key clearing steps seems to help
		 * in completing group key handshake more reliably. */
		wpa_dbg(wpa_s, MSG_DEBUG, "No keys have been configured - "
			"skip key clearing");
		return;
	}

	/* MLME-DELETEKEYS.request */
	wpa_drv_set_key(wpa_s, WPA_ALG_NONE, NULL, 0, 0, NULL, 0, NULL, 0);
	wpa_drv_set_key(wpa_s, WPA_ALG_NONE, NULL, 1, 0, NULL, 0, NULL, 0);
	wpa_drv_set_key(wpa_s, WPA_ALG_NONE, NULL, 2, 0, NULL, 0, NULL, 0);
	wpa_drv_set_key(wpa_s, WPA_ALG_NONE, NULL, 3, 0, NULL, 0, NULL, 0);
#ifdef CONFIG_IEEE80211W
	wpa_drv_set_key(wpa_s, WPA_ALG_NONE, NULL, 4, 0, NULL, 0, NULL, 0);
	wpa_drv_set_key(wpa_s, WPA_ALG_NONE, NULL, 5, 0, NULL, 0, NULL, 0);
#endif /* CONFIG_IEEE80211W */
	if (addr) {
		wpa_drv_set_key(wpa_s, WPA_ALG_NONE, addr, 0, 0, NULL, 0, NULL,
				0);
		/* MLME-SETPROTECTION.request(None) */
		wpa_drv_mlme_setprotection(
			wpa_s, addr,
			MLME_SETPROTECTION_PROTECT_TYPE_NONE,
			MLME_SETPROTECTION_KEY_TYPE_PAIRWISE);
	}
	wpa_s->keys_cleared = 1;
}


/**
 * wpa_supplicant_state_txt - Get the connection state name as a text string
 * @state: State (wpa_state; WPA_*)
 * Returns: The state name as a printable text string
 */
const char * wpa_supplicant_state_txt(enum wpa_states state)
{
	switch (state) {
	case WPA_DISCONNECTED:
		return "DISCONNECTED";
	case WPA_INACTIVE:
		return "INACTIVE";
	case WPA_INTERFACE_DISABLED:
		return "INTERFACE_DISABLED";
	case WPA_SCANNING:
		return "SCANNING";
	case WPA_AUTHENTICATING:
		return "AUTHENTICATING";
	case WPA_ASSOCIATING:
		return "ASSOCIATING";
	case WPA_ASSOCIATED:
		return "ASSOCIATED";
	case WPA_4WAY_HANDSHAKE:
		return "4WAY_HANDSHAKE";
	case WPA_GROUP_HANDSHAKE:
		return "GROUP_HANDSHAKE";
	case WPA_COMPLETED:
		return "COMPLETED";
	default:
		return "UNKNOWN";
	}
}


#ifdef CONFIG_BGSCAN

static void wpa_supplicant_start_bgscan(struct wpa_supplicant *wpa_s)
{
	if (wpas_driver_bss_selection(wpa_s))
		return;
	if (wpa_s->current_ssid == wpa_s->bgscan_ssid)
		return;

	bgscan_deinit(wpa_s);
	if (wpa_s->current_ssid && wpa_s->current_ssid->bgscan) {
		if (bgscan_init(wpa_s, wpa_s->current_ssid)) {
			wpa_dbg(wpa_s, MSG_DEBUG, "Failed to initialize "
				"bgscan");
			/*
			 * Live without bgscan; it is only used as a roaming
			 * optimization, so the initial connection is not
			 * affected.
			 */
		} else {
			struct wpa_scan_results *scan_res;
			wpa_s->bgscan_ssid = wpa_s->current_ssid;
			scan_res = wpa_supplicant_get_scan_results(wpa_s, NULL,
								   0);
			if (scan_res) {
				bgscan_notify_scan(wpa_s, scan_res);
				wpa_scan_results_free(scan_res);
			}
		}
	} else
		wpa_s->bgscan_ssid = NULL;
}


static void wpa_supplicant_stop_bgscan(struct wpa_supplicant *wpa_s)
{
	if (wpa_s->bgscan_ssid != NULL) {
		bgscan_deinit(wpa_s);
		wpa_s->bgscan_ssid = NULL;
	}
}

#endif /* CONFIG_BGSCAN */


static void wpa_supplicant_start_autoscan(struct wpa_supplicant *wpa_s)
{
	if (autoscan_init(wpa_s, 0))
		wpa_dbg(wpa_s, MSG_DEBUG, "Failed to initialize autoscan");
}


static void wpa_supplicant_stop_autoscan(struct wpa_supplicant *wpa_s)
{
	autoscan_deinit(wpa_s);
}


void wpa_supplicant_reinit_autoscan(struct wpa_supplicant *wpa_s)
{
	if (wpa_s->wpa_state == WPA_DISCONNECTED ||
	    wpa_s->wpa_state == WPA_SCANNING) {
		autoscan_deinit(wpa_s);
		wpa_supplicant_start_autoscan(wpa_s);
	}
}


/**
 * wpa_supplicant_set_state - Set current connection state
 * @wpa_s: Pointer to wpa_supplicant data
 * @state: The new connection state
 *
 * This function is called whenever the connection state changes, e.g.,
 * association is completed for WPA/WPA2 4-Way Handshake is started.
 */
void wpa_supplicant_set_state(struct wpa_supplicant *wpa_s,
			      enum wpa_states state)
{
	enum wpa_states old_state = wpa_s->wpa_state;

	wpa_dbg(wpa_s, MSG_DEBUG, "State: %s -> %s",
		wpa_supplicant_state_txt(wpa_s->wpa_state),
		wpa_supplicant_state_txt(state));

#ifdef ANDROID_P2P
	if(state == WPA_ASSOCIATED && wpa_s->current_ssid) {
		wpa_s->current_ssid->assoc_retry = 0;
	}
#endif /* ANDROID_P2P */

	if (state != WPA_SCANNING)
		wpa_supplicant_notify_scanning(wpa_s, 0);

	if (state == WPA_COMPLETED && wpa_s->new_connection) {
#if defined(CONFIG_CTRL_IFACE) || !defined(CONFIG_NO_STDOUT_DEBUG)
		struct wpa_ssid *ssid = wpa_s->current_ssid;
		wpa_msg(wpa_s, MSG_INFO, WPA_EVENT_CONNECTED "- Connection to "
			MACSTR " completed %s [id=%d id_str=%s]",
			MAC2STR(wpa_s->bssid), wpa_s->reassociated_connection ?
			"(reauth)" : "(auth)",
			ssid ? ssid->id : -1,
			ssid && ssid->id_str ? ssid->id_str : "");
#endif /* CONFIG_CTRL_IFACE || !CONFIG_NO_STDOUT_DEBUG */
		wpas_clear_temp_disabled(wpa_s, ssid, 1);
		wpa_s->new_connection = 0;
		wpa_s->reassociated_connection = 1;
		wpa_drv_set_operstate(wpa_s, 1);
#ifndef IEEE8021X_EAPOL
		wpa_drv_set_supp_port(wpa_s, 1);
#endif /* IEEE8021X_EAPOL */
		wpa_s->after_wps = 0;
#ifdef CONFIG_P2P_PERSISTENT_CHECK_SOCIAL_CH
		wpa_s->p2p_persistent_check_social_ch = 0;
#endif //CONFIG_P2P_PERSISTENT_CHECK_SOCIAL_CH
#ifdef CONFIG_P2P
		wpas_p2p_completed(wpa_s);
#endif /* CONFIG_P2P */

		sme_sched_obss_scan(wpa_s, 1);
	} else if (state == WPA_DISCONNECTED || state == WPA_ASSOCIATING ||
		   state == WPA_ASSOCIATED) {
		wpa_s->new_connection = 1;
		wpa_drv_set_operstate(wpa_s, 0);
#ifndef IEEE8021X_EAPOL
		wpa_drv_set_supp_port(wpa_s, 0);
#endif /* IEEE8021X_EAPOL */
		sme_sched_obss_scan(wpa_s, 0);
	}
	wpa_s->wpa_state = state;

#ifdef CONFIG_BGSCAN
	if (state == WPA_COMPLETED)
		wpa_supplicant_start_bgscan(wpa_s);
	else
		wpa_supplicant_stop_bgscan(wpa_s);
#endif /* CONFIG_BGSCAN */

	if (state == WPA_AUTHENTICATING)
		wpa_supplicant_stop_autoscan(wpa_s);

	if (state == WPA_DISCONNECTED || state == WPA_INACTIVE)
		wpa_supplicant_start_autoscan(wpa_s);

	if (wpa_s->wpa_state != old_state) {
		wpas_notify_state_changed(wpa_s, wpa_s->wpa_state, old_state);

		if (wpa_s->wpa_state == WPA_COMPLETED ||
		    old_state == WPA_COMPLETED)
			wpas_notify_auth_changed(wpa_s);
	}
}


void wpa_supplicant_terminate_proc(struct wpa_global *global)
{
	int pending = 0;
#ifdef CONFIG_WPS
	struct wpa_supplicant *wpa_s = global->ifaces;
	while (wpa_s) {
		if (wpas_wps_terminate_pending(wpa_s) == 1)
			pending = 1;
		wpa_s = wpa_s->next;
	}
#endif /* CONFIG_WPS */
	if (pending)
		return;
	eloop_terminate();
}


static void wpa_supplicant_terminate(int sig, void *signal_ctx)
{
	struct wpa_global *global = signal_ctx;
	wpa_supplicant_terminate_proc(global);
}


void wpa_supplicant_clear_status(struct wpa_supplicant *wpa_s)
{
	enum wpa_states old_state = wpa_s->wpa_state;

	wpa_s->pairwise_cipher = 0;
	wpa_s->group_cipher = 0;
	wpa_s->mgmt_group_cipher = 0;
	wpa_s->key_mgmt = 0;
	if (wpa_s->wpa_state != WPA_INTERFACE_DISABLED)
		wpa_supplicant_set_state(wpa_s, WPA_DISCONNECTED);

	if (wpa_s->wpa_state != old_state)
		wpas_notify_state_changed(wpa_s, wpa_s->wpa_state, old_state);
}


/**
 * wpa_supplicant_reload_configuration - Reload configuration data
 * @wpa_s: Pointer to wpa_supplicant data
 * Returns: 0 on success or -1 if configuration parsing failed
 *
 * This function can be used to request that the configuration data is reloaded
 * (e.g., after configuration file change). This function is reloading
 * configuration only for one interface, so this may need to be called multiple
 * times if %wpa_supplicant is controlling multiple interfaces and all
 * interfaces need reconfiguration.
 */
int wpa_supplicant_reload_configuration(struct wpa_supplicant *wpa_s)
{
	struct wpa_config *conf;
	int reconf_ctrl;
	int old_ap_scan;

	if (wpa_s->confname == NULL)
		return -1;
	conf = wpa_config_read(wpa_s->confname);
	if (conf == NULL) {
		wpa_msg(wpa_s, MSG_ERROR, "Failed to parse the configuration "
			"file '%s' - exiting", wpa_s->confname);
		return -1;
	}
	conf->changed_parameters = (unsigned int) -1;

	reconf_ctrl = !!conf->ctrl_interface != !!wpa_s->conf->ctrl_interface
		|| (conf->ctrl_interface && wpa_s->conf->ctrl_interface &&
		    os_strcmp(conf->ctrl_interface,
			      wpa_s->conf->ctrl_interface) != 0);

	if (reconf_ctrl && wpa_s->ctrl_iface) {
		wpa_supplicant_ctrl_iface_deinit(wpa_s->ctrl_iface);
		wpa_s->ctrl_iface = NULL;
	}

	eapol_sm_invalidate_cached_session(wpa_s->eapol);
	if (wpa_s->current_ssid) {
		wpa_supplicant_deauthenticate(wpa_s,
					      WLAN_REASON_DEAUTH_LEAVING);
	}

	/*
	 * TODO: should notify EAPOL SM about changes in opensc_engine_path,
	 * pkcs11_engine_path, pkcs11_module_path.
	 */
	if (wpa_key_mgmt_wpa_psk(wpa_s->key_mgmt)) {
		/*
		 * Clear forced success to clear EAP state for next
		 * authentication.
		 */
		eapol_sm_notify_eap_success(wpa_s->eapol, FALSE);
	}
	eapol_sm_notify_config(wpa_s->eapol, NULL, NULL);
	wpa_sm_set_config(wpa_s->wpa, NULL);
	wpa_sm_pmksa_cache_flush(wpa_s->wpa, NULL);
	wpa_sm_set_fast_reauth(wpa_s->wpa, wpa_s->conf->fast_reauth);
	rsn_preauth_deinit(wpa_s->wpa);

	old_ap_scan = wpa_s->conf->ap_scan;
	wpa_config_free(wpa_s->conf);
	wpa_s->conf = conf;
	if (old_ap_scan != wpa_s->conf->ap_scan)
		wpas_notify_ap_scan_changed(wpa_s);

	if (reconf_ctrl)
		wpa_s->ctrl_iface = wpa_supplicant_ctrl_iface_init(wpa_s);

	wpa_supplicant_update_config(wpa_s);

	wpa_supplicant_clear_status(wpa_s);
	if (wpa_supplicant_enabled_networks(wpa_s)) {
		wpa_s->reassociate = 1;
		wpa_supplicant_req_scan(wpa_s, 0, 0);
	}
	wpa_dbg(wpa_s, MSG_DEBUG, "Reconfiguration completed");
	return 0;
}


static void wpa_supplicant_reconfig(int sig, void *signal_ctx)
{
	struct wpa_global *global = signal_ctx;
	struct wpa_supplicant *wpa_s;
	for (wpa_s = global->ifaces; wpa_s; wpa_s = wpa_s->next) {
		wpa_dbg(wpa_s, MSG_DEBUG, "Signal %d received - reconfiguring",
			sig);
		if (wpa_supplicant_reload_configuration(wpa_s) < 0) {
			wpa_supplicant_terminate_proc(global);
		}
	}
}


enum wpa_cipher cipher_suite2driver(int cipher)
{
	switch (cipher) {
	case WPA_CIPHER_NONE:
		return CIPHER_NONE;
	case WPA_CIPHER_WEP40:
		return CIPHER_WEP40;
	case WPA_CIPHER_WEP104:
		return CIPHER_WEP104;
	case WPA_CIPHER_CCMP:
		return CIPHER_CCMP;
	case WPA_CIPHER_GCMP:
		return CIPHER_GCMP;
	case WPA_CIPHER_TKIP:
	default:
		return CIPHER_TKIP;
	}
}


enum wpa_key_mgmt key_mgmt2driver(int key_mgmt)
{
	switch (key_mgmt) {
	case WPA_KEY_MGMT_NONE:
		return KEY_MGMT_NONE;
	case WPA_KEY_MGMT_IEEE8021X_NO_WPA:
		return KEY_MGMT_802_1X_NO_WPA;
	case WPA_KEY_MGMT_IEEE8021X:
		return KEY_MGMT_802_1X;
	case WPA_KEY_MGMT_WPA_NONE:
		return KEY_MGMT_WPA_NONE;
	case WPA_KEY_MGMT_FT_IEEE8021X:
		return KEY_MGMT_FT_802_1X;
	case WPA_KEY_MGMT_FT_PSK:
		return KEY_MGMT_FT_PSK;
	case WPA_KEY_MGMT_IEEE8021X_SHA256:
		return KEY_MGMT_802_1X_SHA256;
	case WPA_KEY_MGMT_PSK_SHA256:
		return KEY_MGMT_PSK_SHA256;
	case WPA_KEY_MGMT_WPS:
		return KEY_MGMT_WPS;
	case WPA_KEY_MGMT_PSK:
	default:
		return KEY_MGMT_PSK;
	}
}


static int wpa_supplicant_suites_from_ai(struct wpa_supplicant *wpa_s,
					 struct wpa_ssid *ssid,
					 struct wpa_ie_data *ie)
{
	int ret = wpa_sm_parse_own_wpa_ie(wpa_s->wpa, ie);
	if (ret) {
		if (ret == -2) {
			wpa_msg(wpa_s, MSG_INFO, "WPA: Failed to parse WPA IE "
				"from association info");
		}
		return -1;
	}

	wpa_dbg(wpa_s, MSG_DEBUG, "WPA: Using WPA IE from AssocReq to set "
		"cipher suites");
	if (!(ie->group_cipher & ssid->group_cipher)) {
		wpa_msg(wpa_s, MSG_INFO, "WPA: Driver used disabled group "
			"cipher 0x%x (mask 0x%x) - reject",
			ie->group_cipher, ssid->group_cipher);
		return -1;
	}
	if (!(ie->pairwise_cipher & ssid->pairwise_cipher)) {
		wpa_msg(wpa_s, MSG_INFO, "WPA: Driver used disabled pairwise "
			"cipher 0x%x (mask 0x%x) - reject",
			ie->pairwise_cipher, ssid->pairwise_cipher);
		return -1;
	}
	if (!(ie->key_mgmt & ssid->key_mgmt)) {
		wpa_msg(wpa_s, MSG_INFO, "WPA: Driver used disabled key "
			"management 0x%x (mask 0x%x) - reject",
			ie->key_mgmt, ssid->key_mgmt);
		return -1;
	}

#ifdef CONFIG_IEEE80211W
	if (!(ie->capabilities & WPA_CAPABILITY_MFPC) &&
	    ssid->ieee80211w == MGMT_FRAME_PROTECTION_REQUIRED) {
		wpa_msg(wpa_s, MSG_INFO, "WPA: Driver associated with an AP "
			"that does not support management frame protection - "
			"reject");
		return -1;
	}
#endif /* CONFIG_IEEE80211W */

	return 0;
}


/**
 * wpa_supplicant_set_suites - Set authentication and encryption parameters
 * @wpa_s: Pointer to wpa_supplicant data
 * @bss: Scan results for the selected BSS, or %NULL if not available
 * @ssid: Configuration data for the selected network
 * @wpa_ie: Buffer for the WPA/RSN IE
 * @wpa_ie_len: Maximum wpa_ie buffer size on input. This is changed to be the
 * used buffer length in case the functions returns success.
 * Returns: 0 on success or -1 on failure
 *
 * This function is used to configure authentication and encryption parameters
 * based on the network configuration and scan result for the selected BSS (if
 * available).
 */
int wpa_supplicant_set_suites(struct wpa_supplicant *wpa_s,
			      struct wpa_bss *bss, struct wpa_ssid *ssid,
			      u8 *wpa_ie, size_t *wpa_ie_len)
{
	struct wpa_ie_data ie;
	int sel, proto;
	const u8 *bss_wpa, *bss_rsn;

	if (bss) {
		bss_wpa = wpa_bss_get_vendor_ie(bss, WPA_IE_VENDOR_TYPE);
		bss_rsn = wpa_bss_get_ie(bss, WLAN_EID_RSN);
	} else
		bss_wpa = bss_rsn = NULL;

	if (bss_rsn && (ssid->proto & WPA_PROTO_RSN) &&
	    wpa_parse_wpa_ie(bss_rsn, 2 + bss_rsn[1], &ie) == 0 &&
	    (ie.group_cipher & ssid->group_cipher) &&
	    (ie.pairwise_cipher & ssid->pairwise_cipher) &&
	    (ie.key_mgmt & ssid->key_mgmt)) {
		wpa_dbg(wpa_s, MSG_DEBUG, "RSN: using IEEE 802.11i/D9.0");
		proto = WPA_PROTO_RSN;
	} else if (bss_wpa && (ssid->proto & WPA_PROTO_WPA) &&
		   wpa_parse_wpa_ie(bss_wpa, 2 +bss_wpa[1], &ie) == 0 &&
		   (ie.group_cipher & ssid->group_cipher) &&
		   (ie.pairwise_cipher & ssid->pairwise_cipher) &&
		   (ie.key_mgmt & ssid->key_mgmt)) {
		wpa_dbg(wpa_s, MSG_DEBUG, "WPA: using IEEE 802.11i/D3.0");
		proto = WPA_PROTO_WPA;
	} else if (bss) {
		wpa_msg(wpa_s, MSG_WARNING, "WPA: Failed to select WPA/RSN");
		return -1;
	} else {
		if (ssid->proto & WPA_PROTO_RSN)
			proto = WPA_PROTO_RSN;
		else
			proto = WPA_PROTO_WPA;
		if (wpa_supplicant_suites_from_ai(wpa_s, ssid, &ie) < 0) {
			os_memset(&ie, 0, sizeof(ie));
			ie.group_cipher = ssid->group_cipher;
			ie.pairwise_cipher = ssid->pairwise_cipher;
			ie.key_mgmt = ssid->key_mgmt;
#ifdef CONFIG_IEEE80211W
			ie.mgmt_group_cipher =
				ssid->ieee80211w != NO_MGMT_FRAME_PROTECTION ?
				WPA_CIPHER_AES_128_CMAC : 0;
#endif /* CONFIG_IEEE80211W */
			wpa_dbg(wpa_s, MSG_DEBUG, "WPA: Set cipher suites "
				"based on configuration");
		} else
			proto = ie.proto;
	}

	wpa_dbg(wpa_s, MSG_DEBUG, "WPA: Selected cipher suites: group %d "
		"pairwise %d key_mgmt %d proto %d",
		ie.group_cipher, ie.pairwise_cipher, ie.key_mgmt, proto);
#ifdef CONFIG_IEEE80211W
	if (ssid->ieee80211w) {
		wpa_dbg(wpa_s, MSG_DEBUG, "WPA: Selected mgmt group cipher %d",
			ie.mgmt_group_cipher);
	}
#endif /* CONFIG_IEEE80211W */

	wpa_s->wpa_proto = proto;
	wpa_sm_set_param(wpa_s->wpa, WPA_PARAM_PROTO, proto);
	wpa_sm_set_param(wpa_s->wpa, WPA_PARAM_RSN_ENABLED,
			 !!(ssid->proto & WPA_PROTO_RSN));

	if (bss || !wpa_s->ap_ies_from_associnfo) {
		if (wpa_sm_set_ap_wpa_ie(wpa_s->wpa, bss_wpa,
					 bss_wpa ? 2 + bss_wpa[1] : 0) ||
		    wpa_sm_set_ap_rsn_ie(wpa_s->wpa, bss_rsn,
					 bss_rsn ? 2 + bss_rsn[1] : 0))
			return -1;
	}

	sel = ie.group_cipher & ssid->group_cipher;
	if (sel & WPA_CIPHER_CCMP) {
		wpa_s->group_cipher = WPA_CIPHER_CCMP;
		wpa_dbg(wpa_s, MSG_DEBUG, "WPA: using GTK CCMP");
	} else if (sel & WPA_CIPHER_GCMP) {
		wpa_s->group_cipher = WPA_CIPHER_GCMP;
		wpa_dbg(wpa_s, MSG_DEBUG, "WPA: using GTK GCMP");
	} else if (sel & WPA_CIPHER_TKIP) {
		wpa_s->group_cipher = WPA_CIPHER_TKIP;
		wpa_dbg(wpa_s, MSG_DEBUG, "WPA: using GTK TKIP");
	} else if (sel & WPA_CIPHER_WEP104) {
		wpa_s->group_cipher = WPA_CIPHER_WEP104;
		wpa_dbg(wpa_s, MSG_DEBUG, "WPA: using GTK WEP104");
	} else if (sel & WPA_CIPHER_WEP40) {
		wpa_s->group_cipher = WPA_CIPHER_WEP40;
		wpa_dbg(wpa_s, MSG_DEBUG, "WPA: using GTK WEP40");
	} else {
		wpa_msg(wpa_s, MSG_WARNING, "WPA: Failed to select group "
			"cipher");
		return -1;
	}

	sel = ie.pairwise_cipher & ssid->pairwise_cipher;
	if (sel & WPA_CIPHER_CCMP) {
		wpa_s->pairwise_cipher = WPA_CIPHER_CCMP;
		wpa_dbg(wpa_s, MSG_DEBUG, "WPA: using PTK CCMP");
	} else if (sel & WPA_CIPHER_GCMP) {
		wpa_s->pairwise_cipher = WPA_CIPHER_GCMP;
		wpa_dbg(wpa_s, MSG_DEBUG, "WPA: using PTK GCMP");
	} else if (sel & WPA_CIPHER_TKIP) {
		wpa_s->pairwise_cipher = WPA_CIPHER_TKIP;
		wpa_dbg(wpa_s, MSG_DEBUG, "WPA: using PTK TKIP");
	} else if (sel & WPA_CIPHER_NONE) {
		wpa_s->pairwise_cipher = WPA_CIPHER_NONE;
		wpa_dbg(wpa_s, MSG_DEBUG, "WPA: using PTK NONE");
	} else {
		wpa_msg(wpa_s, MSG_WARNING, "WPA: Failed to select pairwise "
			"cipher");
		return -1;
	}

	sel = ie.key_mgmt & ssid->key_mgmt;
	if (0) {
#ifdef CONFIG_IEEE80211R
	} else if (sel & WPA_KEY_MGMT_FT_IEEE8021X) {
		wpa_s->key_mgmt = WPA_KEY_MGMT_FT_IEEE8021X;
		wpa_dbg(wpa_s, MSG_DEBUG, "WPA: using KEY_MGMT FT/802.1X");
	} else if (sel & WPA_KEY_MGMT_FT_PSK) {
		wpa_s->key_mgmt = WPA_KEY_MGMT_FT_PSK;
		wpa_dbg(wpa_s, MSG_DEBUG, "WPA: using KEY_MGMT FT/PSK");
#endif /* CONFIG_IEEE80211R */
#ifdef CONFIG_IEEE80211W
	} else if (sel & WPA_KEY_MGMT_IEEE8021X_SHA256) {
		wpa_s->key_mgmt = WPA_KEY_MGMT_IEEE8021X_SHA256;
		wpa_dbg(wpa_s, MSG_DEBUG,
			"WPA: using KEY_MGMT 802.1X with SHA256");
	} else if (sel & WPA_KEY_MGMT_PSK_SHA256) {
		wpa_s->key_mgmt = WPA_KEY_MGMT_PSK_SHA256;
		wpa_dbg(wpa_s, MSG_DEBUG,
			"WPA: using KEY_MGMT PSK with SHA256");
#endif /* CONFIG_IEEE80211W */
	} else if (sel & WPA_KEY_MGMT_IEEE8021X) {
		wpa_s->key_mgmt = WPA_KEY_MGMT_IEEE8021X;
		wpa_dbg(wpa_s, MSG_DEBUG, "WPA: using KEY_MGMT 802.1X");
	} else if (sel & WPA_KEY_MGMT_PSK) {
		wpa_s->key_mgmt = WPA_KEY_MGMT_PSK;
		wpa_dbg(wpa_s, MSG_DEBUG, "WPA: using KEY_MGMT WPA-PSK");
	} else if (sel & WPA_KEY_MGMT_WPA_NONE) {
		wpa_s->key_mgmt = WPA_KEY_MGMT_WPA_NONE;
		wpa_dbg(wpa_s, MSG_DEBUG, "WPA: using KEY_MGMT WPA-NONE");
	} else {
		wpa_msg(wpa_s, MSG_WARNING, "WPA: Failed to select "
			"authenticated key management type");
		return -1;
	}

	wpa_sm_set_param(wpa_s->wpa, WPA_PARAM_KEY_MGMT, wpa_s->key_mgmt);
	wpa_sm_set_param(wpa_s->wpa, WPA_PARAM_PAIRWISE,
			 wpa_s->pairwise_cipher);
	wpa_sm_set_param(wpa_s->wpa, WPA_PARAM_GROUP, wpa_s->group_cipher);

#ifdef CONFIG_IEEE80211W
	sel = ie.mgmt_group_cipher;
	if (ssid->ieee80211w == NO_MGMT_FRAME_PROTECTION ||
	    !(ie.capabilities & WPA_CAPABILITY_MFPC))
		sel = 0;
	if (sel & WPA_CIPHER_AES_128_CMAC) {
		wpa_s->mgmt_group_cipher = WPA_CIPHER_AES_128_CMAC;
		wpa_dbg(wpa_s, MSG_DEBUG, "WPA: using MGMT group cipher "
			"AES-128-CMAC");
	} else if (sel & WPA_CIPHER_BIP_GMAC_128) {
		wpa_s->mgmt_group_cipher = WPA_CIPHER_BIP_GMAC_128;
		wpa_dbg(wpa_s, MSG_DEBUG, "WPA: using MGMT group cipher "
			"BIP-GMAC-128");
	} else if (sel & WPA_CIPHER_BIP_GMAC_256) {
		wpa_s->mgmt_group_cipher = WPA_CIPHER_BIP_GMAC_256;
		wpa_dbg(wpa_s, MSG_DEBUG, "WPA: using MGMT group cipher "
			"BIP-GMAC-256");
	} else if (sel & WPA_CIPHER_BIP_CMAC_256) {
		wpa_s->mgmt_group_cipher = WPA_CIPHER_BIP_CMAC_256;
		wpa_dbg(wpa_s, MSG_DEBUG, "WPA: using MGMT group cipher "
			"BIP-CMAC-256");
	} else {
		wpa_s->mgmt_group_cipher = 0;
		wpa_dbg(wpa_s, MSG_DEBUG, "WPA: not using MGMT group cipher");
	}
	wpa_sm_set_param(wpa_s->wpa, WPA_PARAM_MGMT_GROUP,
			 wpa_s->mgmt_group_cipher);
	wpa_sm_set_param(wpa_s->wpa, WPA_PARAM_MFP, ssid->ieee80211w);
#endif /* CONFIG_IEEE80211W */

	if (wpa_sm_set_assoc_wpa_ie_default(wpa_s->wpa, wpa_ie, wpa_ie_len)) {
		wpa_msg(wpa_s, MSG_WARNING, "WPA: Failed to generate WPA IE");
		return -1;
	}

	if (wpa_key_mgmt_wpa_psk(ssid->key_mgmt)) {
		wpa_sm_set_pmk(wpa_s->wpa, ssid->psk, PMK_LEN);
#ifndef CONFIG_NO_PBKDF2
		if (bss && ssid->bssid_set && ssid->ssid_len == 0 &&
		    ssid->passphrase) {
			u8 psk[PMK_LEN];
		        pbkdf2_sha1(ssid->passphrase, bss->ssid, bss->ssid_len,
				    4096, psk, PMK_LEN);
		        wpa_hexdump_key(MSG_MSGDUMP, "PSK (from passphrase)",
					psk, PMK_LEN);
			wpa_sm_set_pmk(wpa_s->wpa, psk, PMK_LEN);
		}
#endif /* CONFIG_NO_PBKDF2 */
#ifdef CONFIG_EXT_PASSWORD
		if (ssid->ext_psk) {
			struct wpabuf *pw = ext_password_get(wpa_s->ext_pw,
							     ssid->ext_psk);
			char pw_str[64 + 1];
			u8 psk[PMK_LEN];

			if (pw == NULL) {
				wpa_msg(wpa_s, MSG_INFO, "EXT PW: No PSK "
					"found from external storage");
				return -1;
			}

			if (wpabuf_len(pw) < 8 || wpabuf_len(pw) > 64) {
				wpa_msg(wpa_s, MSG_INFO, "EXT PW: Unexpected "
					"PSK length %d in external storage",
					(int) wpabuf_len(pw));
				ext_password_free(pw);
				return -1;
			}

			os_memcpy(pw_str, wpabuf_head(pw), wpabuf_len(pw));
			pw_str[wpabuf_len(pw)] = '\0';

#ifndef CONFIG_NO_PBKDF2
			if (wpabuf_len(pw) >= 8 && wpabuf_len(pw) < 64 && bss)
			{
				pbkdf2_sha1(pw_str, bss->ssid, bss->ssid_len,
					    4096, psk, PMK_LEN);
				os_memset(pw_str, 0, sizeof(pw_str));
				wpa_hexdump_key(MSG_MSGDUMP, "PSK (from "
						"external passphrase)",
						psk, PMK_LEN);
				wpa_sm_set_pmk(wpa_s->wpa, psk, PMK_LEN);
			} else
#endif /* CONFIG_NO_PBKDF2 */
			if (wpabuf_len(pw) == 2 * PMK_LEN) {
				if (hexstr2bin(pw_str, psk, PMK_LEN) < 0) {
					wpa_msg(wpa_s, MSG_INFO, "EXT PW: "
						"Invalid PSK hex string");
					os_memset(pw_str, 0, sizeof(pw_str));
					ext_password_free(pw);
					return -1;
				}
				wpa_sm_set_pmk(wpa_s->wpa, psk, PMK_LEN);
			} else {
				wpa_msg(wpa_s, MSG_INFO, "EXT PW: No suitable "
					"PSK available");
				os_memset(pw_str, 0, sizeof(pw_str));
				ext_password_free(pw);
				return -1;
			}

			os_memset(pw_str, 0, sizeof(pw_str));
			ext_password_free(pw);
		}
#endif /* CONFIG_EXT_PASSWORD */
	} else
		wpa_sm_set_pmk_from_pmksa(wpa_s->wpa);

	return 0;
}


/**
 * wpa_supplicant_associate - Request association
 * @wpa_s: Pointer to wpa_supplicant data
 * @bss: Scan results for the selected BSS, or %NULL if not available
 * @ssid: Configuration data for the selected network
 *
 * This function is used to request %wpa_supplicant to associate with a BSS.
 */
void wpa_supplicant_associate(struct wpa_supplicant *wpa_s,
			      struct wpa_bss *bss, struct wpa_ssid *ssid)
{
	u8 wpa_ie[200];
	size_t wpa_ie_len;
	int use_crypt, ret, i, bssid_changed;
	int algs = WPA_AUTH_ALG_OPEN;
	enum wpa_cipher cipher_pairwise, cipher_group;
	struct wpa_driver_associate_params params;
	int wep_keys_set = 0;
	struct wpa_driver_capa capa;
	int assoc_failed = 0;
	struct wpa_ssid *old_ssid;
#ifdef CONFIG_HT_OVERRIDES
	struct ieee80211_ht_capabilities htcaps;
	struct ieee80211_ht_capabilities htcaps_mask;
#endif /* CONFIG_HT_OVERRIDES */

#ifdef CONFIG_IBSS_RSN
	ibss_rsn_deinit(wpa_s->ibss_rsn);
	wpa_s->ibss_rsn = NULL;
#endif /* CONFIG_IBSS_RSN */
#ifdef ANDROID_P2P
	int freq = 0;
#endif

	if (ssid->mode == WPAS_MODE_AP || ssid->mode == WPAS_MODE_P2P_GO ||
	    ssid->mode == WPAS_MODE_P2P_GROUP_FORMATION) {
#ifdef CONFIG_AP
		if (!(wpa_s->drv_flags & WPA_DRIVER_FLAGS_AP)) {
			wpa_msg(wpa_s, MSG_INFO, "Driver does not support AP "
				"mode");
			return;
		}
		if (wpa_supplicant_create_ap(wpa_s, ssid) < 0) {
			wpa_supplicant_set_state(wpa_s, WPA_DISCONNECTED);
			return;
		}
		wpa_s->current_bss = bss;
#else /* CONFIG_AP */
		wpa_msg(wpa_s, MSG_ERROR, "AP mode support not included in "
			"the build");
#endif /* CONFIG_AP */
		return;
	}

#ifdef CONFIG_TDLS
	if (bss)
		wpa_tdls_ap_ies(wpa_s->wpa, (const u8 *) (bss + 1),
				bss->ie_len);
#endif /* CONFIG_TDLS */

	if ((wpa_s->drv_flags & WPA_DRIVER_FLAGS_SME) &&
	    ssid->mode == IEEE80211_MODE_INFRA) {
		sme_authenticate(wpa_s, bss, ssid);
		return;
	}

	os_memset(&params, 0, sizeof(params));
	wpa_s->reassociate = 0;
	if (bss && !wpas_driver_bss_selection(wpa_s)) {
#ifdef CONFIG_IEEE80211R
		const u8 *ie, *md = NULL;
#endif /* CONFIG_IEEE80211R */
		wpa_msg(wpa_s, MSG_INFO, "Trying to associate with " MACSTR
			" (SSID='%s' freq=%d MHz)", MAC2STR(bss->bssid),
			wpa_ssid_txt(bss->ssid, bss->ssid_len), bss->freq);
		bssid_changed = !is_zero_ether_addr(wpa_s->bssid);
		os_memset(wpa_s->bssid, 0, ETH_ALEN);
		os_memcpy(wpa_s->pending_bssid, bss->bssid, ETH_ALEN);
		if (bssid_changed)
			wpas_notify_bssid_changed(wpa_s);
#ifdef CONFIG_IEEE80211R
		ie = wpa_bss_get_ie(bss, WLAN_EID_MOBILITY_DOMAIN);
		if (ie && ie[1] >= MOBILITY_DOMAIN_ID_LEN)
			md = ie + 2;
		wpa_sm_set_ft_params(wpa_s->wpa, ie, ie ? 2 + ie[1] : 0);
		if (md) {
			/* Prepare for the next transition */
			wpa_ft_prepare_auth_request(wpa_s->wpa, ie);
		}
#endif /* CONFIG_IEEE80211R */
#ifdef CONFIG_WPS
	} else if ((ssid->ssid == NULL || ssid->ssid_len == 0) &&
		   wpa_s->conf->ap_scan == 2 &&
		   (ssid->key_mgmt & WPA_KEY_MGMT_WPS)) {
		/* Use ap_scan==1 style network selection to find the network
		 */
		wpa_s->scan_req = 2;
		wpa_s->reassociate = 1;
		wpa_supplicant_req_scan(wpa_s, 0, 0);
		return;
#endif /* CONFIG_WPS */
	} else {
		wpa_msg(wpa_s, MSG_INFO, "Trying to associate with SSID '%s'",
			wpa_ssid_txt(ssid->ssid, ssid->ssid_len));
		os_memset(wpa_s->pending_bssid, 0, ETH_ALEN);
	}
	wpa_supplicant_cancel_sched_scan(wpa_s);
	wpa_supplicant_cancel_scan(wpa_s);

	/* Starting new association, so clear the possibly used WPA IE from the
	 * previous association. */
	wpa_sm_set_assoc_wpa_ie(wpa_s->wpa, NULL, 0);

#ifdef IEEE8021X_EAPOL
	if (ssid->key_mgmt & WPA_KEY_MGMT_IEEE8021X_NO_WPA) {
		if (ssid->leap) {
			if (ssid->non_leap == 0)
				algs = WPA_AUTH_ALG_LEAP;
			else
				algs |= WPA_AUTH_ALG_LEAP;
		}
	}
#endif /* IEEE8021X_EAPOL */
	wpa_dbg(wpa_s, MSG_DEBUG, "Automatic auth_alg selection: 0x%x", algs);
	if (ssid->auth_alg) {
		algs = ssid->auth_alg;
		wpa_dbg(wpa_s, MSG_DEBUG, "Overriding auth_alg selection: "
			"0x%x", algs);
	}

	if (bss && (wpa_bss_get_vendor_ie(bss, WPA_IE_VENDOR_TYPE) ||
		    wpa_bss_get_ie(bss, WLAN_EID_RSN)) &&
	    wpa_key_mgmt_wpa(ssid->key_mgmt)) {
		int try_opportunistic;
		try_opportunistic = ssid->proactive_key_caching &&
			(ssid->proto & WPA_PROTO_RSN);
		if (pmksa_cache_set_current(wpa_s->wpa, NULL, bss->bssid,
					    wpa_s->current_ssid,
					    try_opportunistic) == 0)
			eapol_sm_notify_pmkid_attempt(wpa_s->eapol, 1);
		wpa_ie_len = sizeof(wpa_ie);
		if (wpa_supplicant_set_suites(wpa_s, bss, ssid,
					      wpa_ie, &wpa_ie_len)) {
			wpa_msg(wpa_s, MSG_WARNING, "WPA: Failed to set WPA "
				"key management and encryption suites");
			return;
		}
	} else if ((ssid->key_mgmt & WPA_KEY_MGMT_IEEE8021X_NO_WPA) && bss &&
		   wpa_key_mgmt_wpa_ieee8021x(ssid->key_mgmt)) {
		/*
		 * Both WPA and non-WPA IEEE 802.1X enabled in configuration -
		 * use non-WPA since the scan results did not indicate that the
		 * AP is using WPA or WPA2.
		 */
		wpa_supplicant_set_non_wpa_policy(wpa_s, ssid);
		wpa_ie_len = 0;
		wpa_s->wpa_proto = 0;
	} else if (wpa_key_mgmt_wpa_any(ssid->key_mgmt)) {
		wpa_ie_len = sizeof(wpa_ie);
		if (wpa_supplicant_set_suites(wpa_s, NULL, ssid,
					      wpa_ie, &wpa_ie_len)) {
			wpa_msg(wpa_s, MSG_WARNING, "WPA: Failed to set WPA "
				"key management and encryption suites (no "
				"scan results)");
			return;
		}
#ifdef CONFIG_WPS
	} else if (ssid->key_mgmt & WPA_KEY_MGMT_WPS) {
		struct wpabuf *wps_ie;
		wps_ie = wps_build_assoc_req_ie(wpas_wps_get_req_type(ssid));
		if (wps_ie && wpabuf_len(wps_ie) <= sizeof(wpa_ie)) {
			wpa_ie_len = wpabuf_len(wps_ie);
			os_memcpy(wpa_ie, wpabuf_head(wps_ie), wpa_ie_len);
		} else
			wpa_ie_len = 0;
		wpabuf_free(wps_ie);
		wpa_supplicant_set_non_wpa_policy(wpa_s, ssid);
		if (!bss || (bss->caps & IEEE80211_CAP_PRIVACY))
			params.wps = WPS_MODE_PRIVACY;
		else
			params.wps = WPS_MODE_OPEN;
		wpa_s->wpa_proto = 0;
#endif /* CONFIG_WPS */
	} else {
		wpa_supplicant_set_non_wpa_policy(wpa_s, ssid);
		wpa_ie_len = 0;
		wpa_s->wpa_proto = 0;
	}

#ifdef CONFIG_P2P
	if (wpa_s->global->p2p) {
		u8 *pos;
		size_t len;
		int res;
		pos = wpa_ie + wpa_ie_len;
		len = sizeof(wpa_ie) - wpa_ie_len;
		res = wpas_p2p_assoc_req_ie(wpa_s, bss, pos, len,
					    ssid->p2p_group);
		if (res >= 0)
			wpa_ie_len += res;
	}

	wpa_s->cross_connect_disallowed = 0;
	if (bss) {
		struct wpabuf *p2p;
		p2p = wpa_bss_get_vendor_ie_multi(bss, P2P_IE_VENDOR_TYPE);
		if (p2p) {
			wpa_s->cross_connect_disallowed =
				p2p_get_cross_connect_disallowed(p2p);
			wpabuf_free(p2p);
			wpa_dbg(wpa_s, MSG_DEBUG, "P2P: WLAN AP %s cross "
				"connection",
				wpa_s->cross_connect_disallowed ?
				"disallows" : "allows");
		}
	}
#endif /* CONFIG_P2P */

#ifdef CONFIG_HS20
	if (wpa_s->conf->hs20) {
		struct wpabuf *hs20;
		hs20 = wpabuf_alloc(20);
		if (hs20) {
			wpas_hs20_add_indication(hs20);
			os_memcpy(wpa_ie + wpa_ie_len, wpabuf_head(hs20),
				  wpabuf_len(hs20));
			wpa_ie_len += wpabuf_len(hs20);
			wpabuf_free(hs20);
		}
	}
#endif /* CONFIG_HS20 */

#ifdef CONFIG_INTERWORKING
	if (wpa_s->conf->interworking) {
		u8 *pos = wpa_ie;
		if (wpa_ie_len > 0 && pos[0] == WLAN_EID_RSN)
			pos += 2 + pos[1];
		os_memmove(pos + 6, pos, wpa_ie_len - (pos - wpa_ie));
		wpa_ie_len += 6;
		*pos++ = WLAN_EID_EXT_CAPAB;
		*pos++ = 4;
		*pos++ = 0x00;
		*pos++ = 0x00;
		*pos++ = 0x00;
		*pos++ = 0x80; /* Bit 31 - Interworking */
	}
#endif /* CONFIG_INTERWORKING */

	wpa_clear_keys(wpa_s, bss ? bss->bssid : NULL);
	use_crypt = 1;
	cipher_pairwise = cipher_suite2driver(wpa_s->pairwise_cipher);
	cipher_group = cipher_suite2driver(wpa_s->group_cipher);
	if (wpa_s->key_mgmt == WPA_KEY_MGMT_NONE ||
	    wpa_s->key_mgmt == WPA_KEY_MGMT_IEEE8021X_NO_WPA) {
		if (wpa_s->key_mgmt == WPA_KEY_MGMT_NONE)
			use_crypt = 0;
		if (wpa_set_wep_keys(wpa_s, ssid)) {
			use_crypt = 1;
			wep_keys_set = 1;
		}
	}
	if (wpa_s->key_mgmt == WPA_KEY_MGMT_WPS)
		use_crypt = 0;

#ifdef IEEE8021X_EAPOL
	if (wpa_s->key_mgmt == WPA_KEY_MGMT_IEEE8021X_NO_WPA) {
		if ((ssid->eapol_flags &
		     (EAPOL_FLAG_REQUIRE_KEY_UNICAST |
		      EAPOL_FLAG_REQUIRE_KEY_BROADCAST)) == 0 &&
		    !wep_keys_set) {
			use_crypt = 0;
		} else {
			/* Assume that dynamic WEP-104 keys will be used and
			 * set cipher suites in order for drivers to expect
			 * encryption. */
			cipher_pairwise = cipher_group = CIPHER_WEP104;
		}
	}
#endif /* IEEE8021X_EAPOL */

	if (wpa_s->key_mgmt == WPA_KEY_MGMT_WPA_NONE) {
		/* Set the key before (and later after) association */
		wpa_supplicant_set_wpa_none_key(wpa_s, ssid);
	}

	wpa_supplicant_set_state(wpa_s, WPA_ASSOCIATING);
	if (bss) {
		params.ssid = bss->ssid;
		params.ssid_len = bss->ssid_len;
		if (!wpas_driver_bss_selection(wpa_s) || ssid->bssid_set) {
			wpa_printf(MSG_DEBUG, "Limit connection to BSSID "
				   MACSTR " freq=%u MHz based on scan results "
				   "(bssid_set=%d)",
				   MAC2STR(bss->bssid), bss->freq,
				   ssid->bssid_set);
			params.bssid = bss->bssid;
			params.freq = bss->freq;
		}
	} else {
		params.ssid = ssid->ssid;
		params.ssid_len = ssid->ssid_len;
	}

	if (ssid->mode == WPAS_MODE_IBSS && ssid->bssid_set &&
	    wpa_s->conf->ap_scan == 2) {
		params.bssid = ssid->bssid;
		params.fixed_bssid = 1;
	}

	if (ssid->mode == WPAS_MODE_IBSS && ssid->frequency > 0 &&
	    params.freq == 0)
		params.freq = ssid->frequency; /* Initial channel for IBSS */
	params.wpa_ie = wpa_ie;
	params.wpa_ie_len = wpa_ie_len;
	params.pairwise_suite = cipher_pairwise;
	params.group_suite = cipher_group;
	params.key_mgmt_suite = key_mgmt2driver(wpa_s->key_mgmt);
	params.wpa_proto = wpa_s->wpa_proto;
	params.auth_alg = algs;
	params.mode = ssid->mode;
	params.bg_scan_period = ssid->bg_scan_period;
	for (i = 0; i < NUM_WEP_KEYS; i++) {
		if (ssid->wep_key_len[i])
			params.wep_key[i] = ssid->wep_key[i];
		params.wep_key_len[i] = ssid->wep_key_len[i];
	}
	params.wep_tx_keyidx = ssid->wep_tx_keyidx;

	if ((wpa_s->drv_flags & WPA_DRIVER_FLAGS_4WAY_HANDSHAKE) &&
	    (params.key_mgmt_suite == KEY_MGMT_PSK ||
	     params.key_mgmt_suite == KEY_MGMT_FT_PSK)) {
		params.passphrase = ssid->passphrase;
		if (ssid->psk_set)
			params.psk = ssid->psk;
	}

	params.drop_unencrypted = use_crypt;

#ifdef CONFIG_IEEE80211W
	params.mgmt_frame_protection = ssid->ieee80211w;
	if (ssid->ieee80211w != NO_MGMT_FRAME_PROTECTION && bss) {
		const u8 *rsn = wpa_bss_get_ie(bss, WLAN_EID_RSN);
		struct wpa_ie_data ie;
		if (rsn && wpa_parse_wpa_ie(rsn, 2 + rsn[1], &ie) == 0 &&
		    ie.capabilities &
		    (WPA_CAPABILITY_MFPC | WPA_CAPABILITY_MFPR)) {
			wpa_dbg(wpa_s, MSG_DEBUG, "WPA: Selected AP supports "
				"MFP: require MFP");
			params.mgmt_frame_protection =
				MGMT_FRAME_PROTECTION_REQUIRED;
		}
	}
#endif /* CONFIG_IEEE80211W */

	params.p2p = ssid->p2p_group;

	if (wpa_s->parent->set_sta_uapsd)
		params.uapsd = wpa_s->parent->sta_uapsd;
	else
		params.uapsd = -1;

#ifdef CONFIG_HT_OVERRIDES
	os_memset(&htcaps, 0, sizeof(htcaps));
	os_memset(&htcaps_mask, 0, sizeof(htcaps_mask));
	params.htcaps = (u8 *) &htcaps;
	params.htcaps_mask = (u8 *) &htcaps_mask;
	wpa_supplicant_apply_ht_overrides(wpa_s, ssid, &params);
#endif /* CONFIG_HT_OVERRIDES */

#ifdef ANDROID_P2P
	/* If multichannel concurrency is not supported, check for any frequency
	 * conflict and take appropriate action.
	 */
	if (!(wpa_s->drv_flags & WPA_DRIVER_FLAGS_MULTI_CHANNEL_CONCURRENT) &&
		((freq = wpa_drv_shared_freq(wpa_s)) > 0) && (freq != params.freq)) {
		wpa_printf(MSG_DEBUG, "Shared interface with conflicting frequency found (%d != %d)"
																, freq, params.freq);
		if (wpas_p2p_handle_frequency_conflicts(wpa_s, params.freq) < 0) {
			/* Handling conflicts failed. Disable the current connect req and
			 * notify the userspace to take appropriate action */
			wpa_printf(MSG_DEBUG, "proiritize is not set. Notifying user space to handle the case");
			wpa_supplicant_disable_network(wpa_s, ssid);
			wpa_msg(wpa_s, MSG_INFO, WPA_EVENT_FREQ_CONFLICT
				" id=%d", ssid->id);
			os_memset(wpa_s->pending_bssid, 0, ETH_ALEN);
			return;
		}
	}
#endif
	ret = wpa_drv_associate(wpa_s, &params);
	if (ret < 0) {
		wpa_msg(wpa_s, MSG_INFO, "Association request to the driver "
			"failed");
		if (wpa_s->drv_flags & WPA_DRIVER_FLAGS_SANE_ERROR_CODES) {
			/*
			 * The driver is known to mean what is saying, so we
			 * can stop right here; the association will not
			 * succeed.
			 */
			wpas_connection_failed(wpa_s, wpa_s->pending_bssid);
			wpa_supplicant_set_state(wpa_s, WPA_DISCONNECTED);
			os_memset(wpa_s->pending_bssid, 0, ETH_ALEN);
			return;
		}
		/* try to continue anyway; new association will be tried again
		 * after timeout */
		assoc_failed = 1;
	}

	if (wpa_s->key_mgmt == WPA_KEY_MGMT_WPA_NONE) {
		/* Set the key after the association just in case association
		 * cleared the previously configured key. */
		wpa_supplicant_set_wpa_none_key(wpa_s, ssid);
		/* No need to timeout authentication since there is no key
		 * management. */
		wpa_supplicant_cancel_auth_timeout(wpa_s);
		wpa_supplicant_set_state(wpa_s, WPA_COMPLETED);
#ifdef CONFIG_IBSS_RSN
	} else if (ssid->mode == WPAS_MODE_IBSS &&
		   wpa_s->key_mgmt != WPA_KEY_MGMT_NONE &&
		   wpa_s->key_mgmt != WPA_KEY_MGMT_WPA_NONE) {
		/*
		 * RSN IBSS authentication is per-STA and we can disable the
		 * per-BSSID authentication.
		 */
		wpa_supplicant_cancel_auth_timeout(wpa_s);
#endif /* CONFIG_IBSS_RSN */
	} else {
		/* Timeout for IEEE 802.11 authentication and association */
		int timeout = 60;

		if (assoc_failed) {
			/* give IBSS a bit more time */
			timeout = ssid->mode == WPAS_MODE_IBSS ? 10 : 5;
		} else if (wpa_s->conf->ap_scan == 1) {
			/* give IBSS a bit more time */
			timeout = ssid->mode == WPAS_MODE_IBSS ? 20 : 10;
		}
		wpa_supplicant_req_auth_timeout(wpa_s, timeout, 0);
	}

	if (wep_keys_set && wpa_drv_get_capa(wpa_s, &capa) == 0 &&
	    capa.flags & WPA_DRIVER_FLAGS_SET_KEYS_AFTER_ASSOC) {
		/* Set static WEP keys again */
		wpa_set_wep_keys(wpa_s, ssid);
	}

	if (wpa_s->current_ssid && wpa_s->current_ssid != ssid) {
		/*
		 * Do not allow EAP session resumption between different
		 * network configurations.
		 */
		eapol_sm_invalidate_cached_session(wpa_s->eapol);
	}
	old_ssid = wpa_s->current_ssid;
	wpa_s->current_ssid = ssid;
	wpa_s->current_bss = bss;
	wpa_supplicant_rsn_supp_set_config(wpa_s, wpa_s->current_ssid);
	wpa_supplicant_initiate_eapol(wpa_s);
	if (old_ssid != wpa_s->current_ssid)
		wpas_notify_network_changed(wpa_s);
}


static void wpa_supplicant_clear_connection(struct wpa_supplicant *wpa_s,
					    const u8 *addr)
{
	struct wpa_ssid *old_ssid;

	wpa_clear_keys(wpa_s, addr);
	old_ssid = wpa_s->current_ssid;
	wpa_supplicant_mark_disassoc(wpa_s);
	wpa_sm_set_config(wpa_s->wpa, NULL);
	eapol_sm_notify_config(wpa_s->eapol, NULL, NULL);
	if (old_ssid != wpa_s->current_ssid)
		wpas_notify_network_changed(wpa_s);
	eloop_cancel_timeout(wpa_supplicant_timeout, wpa_s, NULL);
}


/**
 * wpa_supplicant_disassociate - Disassociate the current connection
 * @wpa_s: Pointer to wpa_supplicant data
 * @reason_code: IEEE 802.11 reason code for the disassociate frame
 *
 * This function is used to request %wpa_supplicant to disassociate with the
 * current AP.
 */
void wpa_supplicant_disassociate(struct wpa_supplicant *wpa_s,
				 int reason_code)
{
	u8 *addr = NULL;
	union wpa_event_data event;

	if (!is_zero_ether_addr(wpa_s->bssid)) {
		wpa_drv_disassociate(wpa_s, wpa_s->bssid, reason_code);
		addr = wpa_s->bssid;
		os_memset(&event, 0, sizeof(event));
		event.disassoc_info.reason_code = (u16) reason_code;
		event.disassoc_info.locally_generated = 1;
		wpa_supplicant_event(wpa_s, EVENT_DISASSOC, &event);
	}

	wpa_supplicant_clear_connection(wpa_s, addr);
}


/**
 * wpa_supplicant_deauthenticate - Deauthenticate the current connection
 * @wpa_s: Pointer to wpa_supplicant data
 * @reason_code: IEEE 802.11 reason code for the deauthenticate frame
 *
 * This function is used to request %wpa_supplicant to deauthenticate from the
 * current AP.
 */
void wpa_supplicant_deauthenticate(struct wpa_supplicant *wpa_s,
				   int reason_code)
{
	u8 *addr = NULL;
	union wpa_event_data event;

	if (!is_zero_ether_addr(wpa_s->bssid)) {
		wpa_drv_deauthenticate(wpa_s, wpa_s->bssid, reason_code);
		addr = wpa_s->bssid;
		os_memset(&event, 0, sizeof(event));
		event.deauth_info.reason_code = (u16) reason_code;
		event.deauth_info.locally_generated = 1;
		wpa_supplicant_event(wpa_s, EVENT_DEAUTH, &event);
	}

	wpa_supplicant_clear_connection(wpa_s, addr);
}


/**
 * wpa_supplicant_enable_network - Mark a configured network as enabled
 * @wpa_s: wpa_supplicant structure for a network interface
 * @ssid: wpa_ssid structure for a configured network or %NULL
 *
 * Enables the specified network or all networks if no network specified.
 */
void wpa_supplicant_enable_network(struct wpa_supplicant *wpa_s,
				   struct wpa_ssid *ssid)
{
	struct wpa_ssid *other_ssid;
	int was_disabled;

	if (ssid == NULL) {
		for (other_ssid = wpa_s->conf->ssid; other_ssid;
		     other_ssid = other_ssid->next) {
			if (other_ssid->disabled == 2)
				continue; /* do not change persistent P2P group
					   * data */
			if (other_ssid == wpa_s->current_ssid &&
			    other_ssid->disabled)
				wpa_s->reassociate = 1;

			was_disabled = other_ssid->disabled;

			other_ssid->disabled = 0;
			if (was_disabled)
				wpas_clear_temp_disabled(wpa_s, other_ssid, 0);

			if (was_disabled != other_ssid->disabled)
				wpas_notify_network_enabled_changed(
					wpa_s, other_ssid);
		}
		if (wpa_s->reassociate)
			wpa_supplicant_req_scan(wpa_s, 0, 0);
	} else if (ssid->disabled && ssid->disabled != 2) {
		if (wpa_s->current_ssid == NULL) {
			/*
			 * Try to reassociate since there is no current
			 * configuration and a new network was made available.
			 */
			wpa_s->reassociate = 1;
			wpa_supplicant_req_scan(wpa_s, 0, 0);
		}

		was_disabled = ssid->disabled;

		ssid->disabled = 0;
		wpas_clear_temp_disabled(wpa_s, ssid, 1);

		if (was_disabled != ssid->disabled)
			wpas_notify_network_enabled_changed(wpa_s, ssid);
	}
}


/**
 * wpa_supplicant_disable_network - Mark a configured network as disabled
 * @wpa_s: wpa_supplicant structure for a network interface
 * @ssid: wpa_ssid structure for a configured network or %NULL
 *
 * Disables the specified network or all networks if no network specified.
 */
void wpa_supplicant_disable_network(struct wpa_supplicant *wpa_s,
				    struct wpa_ssid *ssid)
{
	struct wpa_ssid *other_ssid;
	int was_disabled;

	if (ssid == NULL) {
		for (other_ssid = wpa_s->conf->ssid; other_ssid;
		     other_ssid = other_ssid->next) {
			was_disabled = other_ssid->disabled;
			if (was_disabled == 2)
				continue; /* do not change persistent P2P group
					   * data */

			other_ssid->disabled = 1;

			if (was_disabled != other_ssid->disabled)
				wpas_notify_network_enabled_changed(
					wpa_s, other_ssid);
		}
		if (wpa_s->current_ssid)
			wpa_supplicant_disassociate(
				wpa_s, WLAN_REASON_DEAUTH_LEAVING);
	} else if (ssid->disabled != 2) {
		if (ssid == wpa_s->current_ssid)
			wpa_supplicant_disassociate(
				wpa_s, WLAN_REASON_DEAUTH_LEAVING);

		was_disabled = ssid->disabled;

		ssid->disabled = 1;

		if (was_disabled != ssid->disabled)
			wpas_notify_network_enabled_changed(wpa_s, ssid);
	}
}


/**
 * wpa_supplicant_select_network - Attempt association with a network
 * @wpa_s: wpa_supplicant structure for a network interface
 * @ssid: wpa_ssid structure for a configured network or %NULL for any network
 */
void wpa_supplicant_select_network(struct wpa_supplicant *wpa_s,
				   struct wpa_ssid *ssid)
{

	struct wpa_ssid *other_ssid;
	int disconnected = 0;

	if (ssid && ssid != wpa_s->current_ssid && wpa_s->current_ssid) {
		wpa_supplicant_disassociate(
			wpa_s, WLAN_REASON_DEAUTH_LEAVING);
		disconnected = 1;
	}

	if (ssid)
		wpas_clear_temp_disabled(wpa_s, ssid, 1);

	/*
	 * Mark all other networks disabled or mark all networks enabled if no
	 * network specified.
	 */
	for (other_ssid = wpa_s->conf->ssid; other_ssid;
	     other_ssid = other_ssid->next) {
		int was_disabled = other_ssid->disabled;
		if (was_disabled == 2)
			continue; /* do not change persistent P2P group data */

		other_ssid->disabled = ssid ? (ssid->id != other_ssid->id) : 0;
		if (was_disabled && !other_ssid->disabled)
			wpas_clear_temp_disabled(wpa_s, other_ssid, 0);

		if (was_disabled != other_ssid->disabled)
			wpas_notify_network_enabled_changed(wpa_s, other_ssid);
	}

	if (ssid && ssid == wpa_s->current_ssid && wpa_s->current_ssid) {
		/* We are already associated with the selected network */
		wpa_printf(MSG_DEBUG, "Already associated with the "
			   "selected network - do nothing");
		return;
	}

	if (ssid)
		wpa_s->current_ssid = ssid;
	wpa_s->connect_without_scan = NULL;
	wpa_s->disconnected = 0;
	wpa_s->reassociate = 1;
	wpa_supplicant_req_scan(wpa_s, 0, disconnected ? 100000 : 0);

	if (ssid)
		wpas_notify_network_selected(wpa_s, ssid);
}


/**
 * wpa_supplicant_set_ap_scan - Set AP scan mode for interface
 * @wpa_s: wpa_supplicant structure for a network interface
 * @ap_scan: AP scan mode
 * Returns: 0 if succeed or -1 if ap_scan has an invalid value
 *
 */
int wpa_supplicant_set_ap_scan(struct wpa_supplicant *wpa_s, int ap_scan)
{

	int old_ap_scan;

	if (ap_scan < 0 || ap_scan > 2)
		return -1;

#ifdef ANDROID
	if (ap_scan == 2 && ap_scan != wpa_s->conf->ap_scan &&
	    wpa_s->wpa_state >= WPA_ASSOCIATING &&
	    wpa_s->wpa_state < WPA_COMPLETED) {
		wpa_printf(MSG_ERROR, "ap_scan = %d (%d) rejected while "
			   "associating", wpa_s->conf->ap_scan, ap_scan);
		return 0;
	}
#endif /* ANDROID */

	old_ap_scan = wpa_s->conf->ap_scan;
	wpa_s->conf->ap_scan = ap_scan;

	if (old_ap_scan != wpa_s->conf->ap_scan)
		wpas_notify_ap_scan_changed(wpa_s);

	return 0;
}


/**
 * wpa_supplicant_set_bss_expiration_age - Set BSS entry expiration age
 * @wpa_s: wpa_supplicant structure for a network interface
 * @expire_age: Expiration age in seconds
 * Returns: 0 if succeed or -1 if expire_age has an invalid value
 *
 */
int wpa_supplicant_set_bss_expiration_age(struct wpa_supplicant *wpa_s,
					  unsigned int bss_expire_age)
{
	if (bss_expire_age < 10) {
		wpa_msg(wpa_s, MSG_ERROR, "Invalid bss expiration age %u",
			bss_expire_age);
		return -1;
	}
	wpa_msg(wpa_s, MSG_DEBUG, "Setting bss expiration age: %d sec",
		bss_expire_age);
	wpa_s->conf->bss_expiration_age = bss_expire_age;

	return 0;
}


/**
 * wpa_supplicant_set_bss_expiration_count - Set BSS entry expiration scan count
 * @wpa_s: wpa_supplicant structure for a network interface
 * @expire_count: number of scans after which an unseen BSS is reclaimed
 * Returns: 0 if succeed or -1 if expire_count has an invalid value
 *
 */
int wpa_supplicant_set_bss_expiration_count(struct wpa_supplicant *wpa_s,
					    unsigned int bss_expire_count)
{
	if (bss_expire_count < 1) {
		wpa_msg(wpa_s, MSG_ERROR, "Invalid bss expiration count %u",
			bss_expire_count);
		return -1;
	}
	wpa_msg(wpa_s, MSG_DEBUG, "Setting bss expiration scan count: %u",
		bss_expire_count);
	wpa_s->conf->bss_expiration_scan_count = bss_expire_count;

	return 0;
}


/**
 * wpa_supplicant_set_scan_interval - Set scan interval
 * @wpa_s: wpa_supplicant structure for a network interface
 * @scan_interval: scan interval in seconds
 * Returns: 0 if succeed or -1 if scan_interval has an invalid value
 *
 */
int wpa_supplicant_set_scan_interval(struct wpa_supplicant *wpa_s,
				     int scan_interval)
{
	if (scan_interval < 0) {
		wpa_msg(wpa_s, MSG_ERROR, "Invalid scan interval %d",
			scan_interval);
		return -1;
	}
	wpa_msg(wpa_s, MSG_DEBUG, "Setting scan interval: %d sec",
		scan_interval);
	wpa_s->scan_interval = scan_interval;

	return 0;
}


/**
 * wpa_supplicant_set_debug_params - Set global debug params
 * @global: wpa_global structure
 * @debug_level: debug level
 * @debug_timestamp: determines if show timestamp in debug data
 * @debug_show_keys: determines if show keys in debug data
 * Returns: 0 if succeed or -1 if debug_level has wrong value
 */
int wpa_supplicant_set_debug_params(struct wpa_global *global, int debug_level,
				    int debug_timestamp, int debug_show_keys)
{

	int old_level, old_timestamp, old_show_keys;

	/* check for allowed debuglevels */
	if (debug_level != MSG_EXCESSIVE &&
	    debug_level != MSG_MSGDUMP &&
	    debug_level != MSG_DEBUG &&
	    debug_level != MSG_INFO &&
	    debug_level != MSG_WARNING &&
	    debug_level != MSG_ERROR)
		return -1;

	old_level = wpa_debug_level;
	old_timestamp = wpa_debug_timestamp;
	old_show_keys = wpa_debug_show_keys;

	wpa_debug_level = debug_level;
	wpa_debug_timestamp = debug_timestamp ? 1 : 0;
	wpa_debug_show_keys = debug_show_keys ? 1 : 0;

	if (wpa_debug_level != old_level)
		wpas_notify_debug_level_changed(global);
	if (wpa_debug_timestamp != old_timestamp)
		wpas_notify_debug_timestamp_changed(global);
	if (wpa_debug_show_keys != old_show_keys)
		wpas_notify_debug_show_keys_changed(global);

	return 0;
}


/**
 * wpa_supplicant_get_ssid - Get a pointer to the current network structure
 * @wpa_s: Pointer to wpa_supplicant data
 * Returns: A pointer to the current network structure or %NULL on failure
 */
struct wpa_ssid * wpa_supplicant_get_ssid(struct wpa_supplicant *wpa_s)
{
	struct wpa_ssid *entry;
	u8 ssid[MAX_SSID_LEN];
	int res;
	size_t ssid_len;
	u8 bssid[ETH_ALEN];
	int wired;

	res = wpa_drv_get_ssid(wpa_s, ssid);
	if (res < 0) {
		wpa_msg(wpa_s, MSG_WARNING, "Could not read SSID from "
			"driver");
		return NULL;
	}
	ssid_len = res;

	if (wpa_drv_get_bssid(wpa_s, bssid) < 0) {
		wpa_msg(wpa_s, MSG_WARNING, "Could not read BSSID from "
			"driver");
		return NULL;
	}

	wired = wpa_s->conf->ap_scan == 0 &&
		(wpa_s->drv_flags & WPA_DRIVER_FLAGS_WIRED);

	entry = wpa_s->conf->ssid;
	while (entry) {
		if (!wpas_network_disabled(wpa_s, entry) &&
		    ((ssid_len == entry->ssid_len &&
		      os_memcmp(ssid, entry->ssid, ssid_len) == 0) || wired) &&
		    (!entry->bssid_set ||
		     os_memcmp(bssid, entry->bssid, ETH_ALEN) == 0))
			return entry;
#ifdef CONFIG_WPS
		if (!wpas_network_disabled(wpa_s, entry) &&
		    (entry->key_mgmt & WPA_KEY_MGMT_WPS) &&
		    (entry->ssid == NULL || entry->ssid_len == 0) &&
		    (!entry->bssid_set ||
		     os_memcmp(bssid, entry->bssid, ETH_ALEN) == 0))
			return entry;
#endif /* CONFIG_WPS */

		if (!wpas_network_disabled(wpa_s, entry) && entry->bssid_set &&
		    entry->ssid_len == 0 &&
		    os_memcmp(bssid, entry->bssid, ETH_ALEN) == 0)
			return entry;

		entry = entry->next;
	}

	return NULL;
}


static int select_driver(struct wpa_supplicant *wpa_s, int i)
{
	struct wpa_global *global = wpa_s->global;

	if (wpa_drivers[i]->global_init && global->drv_priv[i] == NULL) {
		global->drv_priv[i] = wpa_drivers[i]->global_init();
		if (global->drv_priv[i] == NULL) {
			wpa_printf(MSG_ERROR, "Failed to initialize driver "
				   "'%s'", wpa_drivers[i]->name);
			return -1;
		}
	}

	wpa_s->driver = wpa_drivers[i];
	wpa_s->global_drv_priv = global->drv_priv[i];

	return 0;
}


static int wpa_supplicant_set_driver(struct wpa_supplicant *wpa_s,
				     const char *name)
{
	int i;
	size_t len;
	const char *pos, *driver = name;

	if (wpa_s == NULL)
		return -1;

	if (wpa_drivers[0] == NULL) {
		wpa_msg(wpa_s, MSG_ERROR, "No driver interfaces build into "
			"wpa_supplicant");
		return -1;
	}

	if (name == NULL) {
		/* default to first driver in the list */
		return select_driver(wpa_s, 0);
	}

	do {
		pos = os_strchr(driver, ',');
		if (pos)
			len = pos - driver;
		else
			len = os_strlen(driver);

		for (i = 0; wpa_drivers[i]; i++) {
			if (os_strlen(wpa_drivers[i]->name) == len &&
			    os_strncmp(driver, wpa_drivers[i]->name, len) ==
			    0) {
				/* First driver that succeeds wins */
				if (select_driver(wpa_s, i) == 0)
					return 0;
			}
		}

		driver = pos + 1;
	} while (pos);

	wpa_msg(wpa_s, MSG_ERROR, "Unsupported driver '%s'", name);
	return -1;
}


/**
 * wpa_supplicant_rx_eapol - Deliver a received EAPOL frame to wpa_supplicant
 * @ctx: Context pointer (wpa_s); this is the ctx variable registered
 *	with struct wpa_driver_ops::init()
 * @src_addr: Source address of the EAPOL frame
 * @buf: EAPOL data starting from the EAPOL header (i.e., no Ethernet header)
 * @len: Length of the EAPOL data
 *
 * This function is called for each received EAPOL frame. Most driver
 * interfaces rely on more generic OS mechanism for receiving frames through
 * l2_packet, but if such a mechanism is not available, the driver wrapper may
 * take care of received EAPOL frames and deliver them to the core supplicant
 * code by calling this function.
 */
void wpa_supplicant_rx_eapol(void *ctx, const u8 *src_addr,
			     const u8 *buf, size_t len)
{
	struct wpa_supplicant *wpa_s = ctx;

	wpa_dbg(wpa_s, MSG_DEBUG, "RX EAPOL from " MACSTR, MAC2STR(src_addr));
	wpa_hexdump(MSG_MSGDUMP, "RX EAPOL", buf, len);

	if (wpa_s->wpa_state < WPA_ASSOCIATED) {
		/*
		 * There is possible race condition between receiving the
		 * association event and the EAPOL frame since they are coming
		 * through different paths from the driver. In order to avoid
		 * issues in trying to process the EAPOL frame before receiving
		 * association information, lets queue it for processing until
		 * the association event is received.
		 */
		wpa_dbg(wpa_s, MSG_DEBUG, "Not associated - Delay processing "
			"of received EAPOL frame");
		wpabuf_free(wpa_s->pending_eapol_rx);
		wpa_s->pending_eapol_rx = wpabuf_alloc_copy(buf, len);
		if (wpa_s->pending_eapol_rx) {
			os_get_time(&wpa_s->pending_eapol_rx_time);
			os_memcpy(wpa_s->pending_eapol_rx_src, src_addr,
				  ETH_ALEN);
		}
		return;
	}

#ifdef CONFIG_AP
	if (wpa_s->ap_iface) {
		wpa_supplicant_ap_rx_eapol(wpa_s, src_addr, buf, len);
		return;
	}
#endif /* CONFIG_AP */

	if (wpa_s->key_mgmt == WPA_KEY_MGMT_NONE) {
		wpa_dbg(wpa_s, MSG_DEBUG, "Ignored received EAPOL frame since "
			"no key management is configured");
		return;
	}

	if (wpa_s->eapol_received == 0 &&
	    (!(wpa_s->drv_flags & WPA_DRIVER_FLAGS_4WAY_HANDSHAKE) ||
	     !wpa_key_mgmt_wpa_psk(wpa_s->key_mgmt) ||
	     wpa_s->wpa_state != WPA_COMPLETED) &&
	    (wpa_s->current_ssid == NULL ||
	     wpa_s->current_ssid->mode != IEEE80211_MODE_IBSS)) {
		/* Timeout for completing IEEE 802.1X and WPA authentication */
		wpa_supplicant_req_auth_timeout(
			wpa_s,
			(wpa_key_mgmt_wpa_ieee8021x(wpa_s->key_mgmt) ||
			 wpa_s->key_mgmt == WPA_KEY_MGMT_IEEE8021X_NO_WPA ||
			 wpa_s->key_mgmt == WPA_KEY_MGMT_WPS) ?
			70 : 10, 0);
	}
	wpa_s->eapol_received++;

	if (wpa_s->countermeasures) {
		wpa_msg(wpa_s, MSG_INFO, "WPA: Countermeasures - dropped "
			"EAPOL packet");
		return;
	}

#ifdef CONFIG_IBSS_RSN
	if (wpa_s->current_ssid &&
	    wpa_s->current_ssid->mode == WPAS_MODE_IBSS) {
		ibss_rsn_rx_eapol(wpa_s->ibss_rsn, src_addr, buf, len);
		return;
	}
#endif /* CONFIG_IBSS_RSN */

	/* Source address of the incoming EAPOL frame could be compared to the
	 * current BSSID. However, it is possible that a centralized
	 * Authenticator could be using another MAC address than the BSSID of
	 * an AP, so just allow any address to be used for now. The replies are
	 * still sent to the current BSSID (if available), though. */

	os_memcpy(wpa_s->last_eapol_src, src_addr, ETH_ALEN);
	if (!wpa_key_mgmt_wpa_psk(wpa_s->key_mgmt) &&
	    eapol_sm_rx_eapol(wpa_s->eapol, src_addr, buf, len) > 0)
		return;
	wpa_drv_poll(wpa_s);
	if (!(wpa_s->drv_flags & WPA_DRIVER_FLAGS_4WAY_HANDSHAKE))
		wpa_sm_rx_eapol(wpa_s->wpa, src_addr, buf, len);
	else if (wpa_key_mgmt_wpa_ieee8021x(wpa_s->key_mgmt)) {
		/*
		 * Set portValid = TRUE here since we are going to skip 4-way
		 * handshake processing which would normally set portValid. We
		 * need this to allow the EAPOL state machines to be completed
		 * without going through EAPOL-Key handshake.
		 */
		eapol_sm_notify_portValid(wpa_s->eapol, TRUE);
	}
}


int wpa_supplicant_update_mac_addr(struct wpa_supplicant *wpa_s)
{
	if (wpa_s->driver->send_eapol) {
		const u8 *addr = wpa_drv_get_mac_addr(wpa_s);
		if (addr)
			os_memcpy(wpa_s->own_addr, addr, ETH_ALEN);
	} else if (!(wpa_s->drv_flags &
		     WPA_DRIVER_FLAGS_P2P_DEDICATED_INTERFACE)) {
		l2_packet_deinit(wpa_s->l2);
		wpa_s->l2 = l2_packet_init(wpa_s->ifname,
					   wpa_drv_get_mac_addr(wpa_s),
					   ETH_P_EAPOL,
					   wpa_supplicant_rx_eapol, wpa_s, 0);
		if (wpa_s->l2 == NULL)
			return -1;
	} else {
		const u8 *addr = wpa_drv_get_mac_addr(wpa_s);
		if (addr)
			os_memcpy(wpa_s->own_addr, addr, ETH_ALEN);
	}

	if (wpa_s->l2 && l2_packet_get_own_addr(wpa_s->l2, wpa_s->own_addr)) {
		wpa_msg(wpa_s, MSG_ERROR, "Failed to get own L2 address");
		return -1;
	}

	wpa_dbg(wpa_s, MSG_DEBUG, "Own MAC address: " MACSTR,
		MAC2STR(wpa_s->own_addr));
	wpa_sm_set_own_addr(wpa_s->wpa, wpa_s->own_addr);

	return 0;
}


static void wpa_supplicant_rx_eapol_bridge(void *ctx, const u8 *src_addr,
					   const u8 *buf, size_t len)
{
	struct wpa_supplicant *wpa_s = ctx;
	const struct l2_ethhdr *eth;

	if (len < sizeof(*eth))
		return;
	eth = (const struct l2_ethhdr *) buf;

	if (os_memcmp(eth->h_dest, wpa_s->own_addr, ETH_ALEN) != 0 &&
	    !(eth->h_dest[0] & 0x01)) {
		wpa_dbg(wpa_s, MSG_DEBUG, "RX EAPOL from " MACSTR " to " MACSTR
			" (bridge - not for this interface - ignore)",
			MAC2STR(src_addr), MAC2STR(eth->h_dest));
		return;
	}

	wpa_dbg(wpa_s, MSG_DEBUG, "RX EAPOL from " MACSTR " to " MACSTR
		" (bridge)", MAC2STR(src_addr), MAC2STR(eth->h_dest));
	wpa_supplicant_rx_eapol(wpa_s, src_addr, buf + sizeof(*eth),
				len - sizeof(*eth));
}


/**
 * wpa_supplicant_driver_init - Initialize driver interface parameters
 * @wpa_s: Pointer to wpa_supplicant data
 * Returns: 0 on success, -1 on failure
 *
 * This function is called to initialize driver interface parameters.
 * wpa_drv_init() must have been called before this function to initialize the
 * driver interface.
 */
int wpa_supplicant_driver_init(struct wpa_supplicant *wpa_s)
{
	static int interface_count = 0;

	if (wpa_supplicant_update_mac_addr(wpa_s) < 0)
		return -1;

	if (wpa_s->bridge_ifname[0]) {
		wpa_dbg(wpa_s, MSG_DEBUG, "Receiving packets from bridge "
			"interface '%s'", wpa_s->bridge_ifname);
		wpa_s->l2_br = l2_packet_init(wpa_s->bridge_ifname,
					      wpa_s->own_addr,
					      ETH_P_EAPOL,
					      wpa_supplicant_rx_eapol_bridge,
					      wpa_s, 1);
		if (wpa_s->l2_br == NULL) {
			wpa_msg(wpa_s, MSG_ERROR, "Failed to open l2_packet "
				"connection for the bridge interface '%s'",
				wpa_s->bridge_ifname);
			return -1;
		}
	}

	wpa_clear_keys(wpa_s, NULL);

	/* Make sure that TKIP countermeasures are not left enabled (could
	 * happen if wpa_supplicant is killed during countermeasures. */
	wpa_drv_set_countermeasures(wpa_s, 0);

	wpa_dbg(wpa_s, MSG_DEBUG, "RSN: flushing PMKID list in the driver");
	wpa_drv_flush_pmkid(wpa_s);

	wpa_s->prev_scan_ssid = WILDCARD_SSID_SCAN;
	wpa_s->prev_scan_wildcard = 0;

	if (wpa_supplicant_enabled_networks(wpa_s)) {
		if (wpa_supplicant_delayed_sched_scan(wpa_s, interface_count,
						      100000))
			wpa_supplicant_req_scan(wpa_s, interface_count,
						100000);
		interface_count++;
	} else
		wpa_supplicant_set_state(wpa_s, WPA_INACTIVE);

	return 0;
}


static int wpa_supplicant_daemon(const char *pid_file)
{
	wpa_printf(MSG_DEBUG, "Daemonize..");
	return os_daemonize(pid_file);
}


static struct wpa_supplicant * wpa_supplicant_alloc(void)
{
	struct wpa_supplicant *wpa_s;

	wpa_s = os_zalloc(sizeof(*wpa_s));
	if (wpa_s == NULL)
		return NULL;
	wpa_s->scan_req = 1;
	wpa_s->scan_interval = 5;
	wpa_s->new_connection = 1;
	wpa_s->parent = wpa_s;
	wpa_s->sched_scanning = 0;

	return wpa_s;
}


20_add_indication(hs20);
		l(wpa_s->ibss_rsn, src_addr, buf, len);

	wpa_s->scan_req =	wpa_supplicant_set->scan_req =	wpa_supplicant_set->scan_req =	wpa_sud_len;
	}led;

	if (s_get_ie(fdefa_dbg(wpa_s, *k));
	pn;
	}led;

	if (s_get_ie(fdefa_dbg(wpa_s, *k));
	htcaps;

	wpa_dbg(wpanize(pdeflicif (wppe(WPA_ deflicdefaulhexg cray&&
	  
		retubg(wpanize(pt: 0;
deflicetubize(p			nt_req_scy
	 * codeflicdes nul *a ? (ssicompanyonnec&&
		((fredeflicif, MSG_ERROR,y
	 *T * @src
			  set posscan_inILDCARDklledl&&
		&htcaps;
	params.a_spol - Deflic =	wed(wputhenticatwpaMCS_MASK_addr))val);
	wpa_s->scan_interval ==	wpa_sup,odeflicd-:%s:-",odeflicr))vas.wep_key[i] = suthenticatwpaMCS_MASK_addmp(driver, errn_t len;
	lal, i- Setrt * t != &			to 6open l2_perrn_t = 0ion for the bridge interfaterval);
			a_sup int d[%i]: %lFIG_d: %p  tmine%p, NULL)i, v	}

	totmit TKIPl2_pen	/* Ttys != 		breaknabledarams.a_spol - Deflic =	w
			wpv TKIPt: 0;
en	easur cipher sui the bridge interface '%s);
			,
				wpa_(WPA_ de-licne%emcmrrorne%e\}
	}
#endeflic,Setrmrrorperrn_)t TKIP countermeasures areo
	 * n cowly s, "Ass tha_(WPA_ rentint dsr thenicompd, &p		}
	}

MCSe_net) &&
		((friion fo&htcaps;
	params.htcapa_spol - Deflic =	wed(xffs;

	wputhenticatwpaMCS_MASK_addica1gement. We
			}

3ARNIheda_suitver = params.htcapa_spol - Deflic =	w[uthenticatwpaMCS_MASK_addica1] */

	0x1fpa_s, int i)
{tf(MSG_DEBUG, "Daemoniid)
{
	smax_amsdu_t len;
	const char *pos, *driver = 

	if (s_get_ie(fdefa_dbg(wpa_s, *k));
	pn;
	= 

	if (s_get_ie(fdefa_dbg(wpa_s, *k));
	htcaps;

	(!is_z	if (ssid n fu16 msk))val);
	wpa_s->scan_interval ==	wpid)
{
	smax_amsdu:ing sz	if (ssidlayed_sc

		other_ss-1if, MSG_ERROR,y
m &parhost_to_le16(H
		*p

#if_d;

AMSDU_SIZs)
{
arams.htcapa_defa_dbg(wpa_s,&even |= msk))ed_sc

		othe)
edarams.a_defa_dbg(wpa_s,&even &= msk))etic intarams.a_defa_dbg(wpa_s,&even |= msk))	wpa_printf(MSG_DEBUG, "Daemoniz;

	mpdu_rettoe_t len;
	const char *pos, *driver =

	if (s_get_ie(fdefa_dbg(wpa_s, *k));
	pn;
	=

	if (s_get_ie(fdefa_dbg(wpa_s, *k));
	htcaps;

	("Daerettoe;
}


sta	wpa_s->scan_interval ==	wp	mpdu_rettoe:ing szrettoe;layed_screttoer_ss-1if, MSG_ERROR,y
d_screttoerscan !=rettoer> 3 -1;
	}

	wpa_dbg(wpa_s, MSG_DEBU	mpdu_rettoe:ing wpa_s->pnter._init(wMerfabe 0-3rams(s szrettoe;laIP counterEINVAIVER_FLAarams.htcapa_
	wpdu_ug_leve|	wpa3 ssid2suitve		}
rettoerr = arams.a_
	wpdu_ug_leve&= ~pa3 = arams.a_
	wpdu_ug_leve|	wrettoer&wpa3 )	wpa_printf(MSG_DEBUG, "Daemoniz;

	mpdu_density_t len;
	const char *pos, *driver = 

	if (s_get_ie(fdefa_dbg(wpa_s, *k));
	pn;
	= 

	if (s_get_ie(fdefa_dbg(wpa_s, *k));
	htcaps;

	(!is_z	ensity;
}


sta	wpa_s->scan_interval ==	wp	mpdu_	ensity:ing sz	ensity;layed_sc
ensityr_ss-1if, MSG_ERROR,y
d_sc
ensityrscan !=
ensityr> 7 -1;
	}

	wpa_dbg(wpa_s, MSG_DEnit(w	mpdu_	ensity:ing wpa_s->pnter._Merfabe 0-7rams(s.
	}
#e	ensity;laIP counterEINVAIVER_FLAarams.htcapa_
	wpdu_ug_leve|	wpa1C = arams.a_
	wpdu_ug_leve&= ~(pa1C) = arams.a_
	wpdu_ug_leve|	wc
ensityrs<				&wpa1C =	wpa_printf(MSG_DEBUG, "Daemoniz;

id)
{
	sht40_t len;
	const char *pos, *driver =

	if (s_get_ie(fdefa_dbg(wpa_s, *k));
	pn;
	=

	if (s_get_ie(fdefa_dbg(wpa_s, *k));
	htcaps;

	("Dae	if (ssid n fppen sk		 * thA_ wpa_d/
void wHT4pos =fu16 mskparhost_to_le16(H
		*p

#if_SUPPreq != paWIDTHkeys |;

	wpa_d  H
		*p

#if_SHORT_GI40MHZr))val);
	wpa_s->scan_interval ==	wpid)
{
	sht40:ing sz	if (ssidlayed_sc

		othe)
edarams.a_defa_dbg(wpa_s,&even &= ~msk))etic intarams.a_defa_dbg(wpa_s,&even |= msk))	warams.htcapa_defa_dbg(wpa_s,&even |= msk))	wpa_printf(MSG_  const u8 *buf, siz/

#ifdef ANDROID_P(wpa_s == NULL)
		return NULL;,d = 0;

	if (ssid && s,(wpa_s == NUL 0;

	iree(wpa_s_ug_leve*to the f (wpa_s ==s_get_ie(fdefa_dbg(wpa_s, *k));
	;(wpa_s ==s_get_ie(fdefa_dbg(wpa_s, *k));
	* CONFI		((freant_set_STR
		" rides(wp

	if (ssfdesabled)
			wpas_fde_eapol(wdes(wp

supplic !=wdes(wp

supplitcaps_et_STR
		" risupplicantpa_s ==s_get_ie(fdefa_dbg(wpa_s, *) des(wp

suppli
{
arams.htcapcantpa_s ==s_get_ie(fdefa_dbg(wpa_s, *) des(wp

suppli* CONFIG_HT_O	wpa_supplicaNULL;,dk));
	paarams.htcaps_led)
	deflicr))	moniid)
{
	smax_amsdu_NULL;,dk));
	paarams.htcaps;

	wpa_d led)
			wpas_fmax_amsdu)FIG_HT_O	wp	mpdu_rettoe_NULL;,dk));
	paarams.htcaps_led)
		mpdu_rettoe)FIG_HT_O	wp	mpdu_density_NULL;,dk));
	paarams.htcaps_led)
		mpdu_	ensity;laImoniz;

id)
{
	sht40_NULL;,dk));
	paarams.htcaps_led)
	id)
{
	sht40t wpa_concurrency is not supported, check for a_set &&
FD_  consfd, NULL);
	i&evenuth_alg ant *wpa_s;

	wpa_s = s_zallo  f (wbize		buf[ 256 ]))val);
tic struct wpa_supp
FD:e proL);
	int isenticSSID_SCANy
maps;
	
		 * 0x0(wp256 ;laIstic str
		 * "ng sz	l(wpa_&
		  sfd,tcol -  CAN;
	wpa_s- 0;

	icm  os_memcpp
FD-eys-TCPPORTis possi
	wpa_spos)t TKy
maps;
	
		 * 0x0(wp256 ;laIstic str
		 * "ng sz	l(wpa_&
		  sfd,max_ol, TRUpu  CAN;
	wpa_s- 0;

	icm  os_memcpp
FD-eys-d;
TPUTis possi
	wpa_spos)t Ty
maps;
	
		 * 0x0(wp256 ;laIstic str
		 * "ng sz	l(wpa_&
		  sfd,device_type CAN;
	wpa_s- 0;

	icm  os_memcpp
FD-eys-DEVTYPEis possi
	wpa_spos)t Tyframe coul/a_set &&
FD_G_DEBUG, "Daepcsc_rr eacif (wpa_supplicant_update_mac_addr(wpak for aPCSC_FUNCSturn -1;

	if a_s->eapol,pa_&
		  pcsc_rr eacif, MSG_ERROR,y
a_s;
	wpa_ant_dpa_anif (wpSled_nTRY_BO* wppol,pa_&
		  pcsc_rr eaci;a_s->eapol,pa_pa_anif, MSG_ERRg packets from b&
		  pcsc_piWPA_COMPLEpa_ani NULpiW(pol,pa_pa_anwppol,pa_&
		  pcsc_piWriver");
		pa_ania_drv_get_mac_pa_ani>own_addr,
pa_ant_dtion = 	}

	wpa_dbg(wpa_s, MSG_DEBUPC/SC PIN ;
	wpa_iaramete_flags & WPA_D(wpa_s->owd_set &	wpa_s_addr,
imsi)ica1;a_s->epa_anie_wpamsi(pol,pa_pa_anwppol,pa_amsi, &

	i");
		pa_ania_drv_get_mac_pa_ani>own_addr,
pa_ant_dtion = 	}

	wpa_dbg(wpa_s, MSG_DEBU_s->conf->ap_scIMSIlags & WPA_D(wpa_s->	pol,pa_amsi[

			wp'\0'R,y
a_s;
	wmncid_set &a_anie_wpmncid_sget_mac_pa_ani>oval);
tic struct wpa_suppSled_:cIMSI %s (MNC

	iOL fy_co,
ntication isamsi, a_s;
	wmncid_srd = 0;

	mal)
{
	ianicting to skw_bridge(voipa_ani>owrv_poll(wpess of {
	ianicting to skt u8 *addr =oipa_ani>oconcurrencPCSC_FUNCS_mgmt_pa_printf(MSG_"Daemonsif (w_exULpwpa_supplicant_update_mac_addr(wpa_bize(pv
	in[0] led(wxULpreewoania_drv_get_mac_exULpwlicant_set_exULpwt_dtion = rv_poll(wl)
{exULpwicting to skt u8 *ald
	 * has->eapol,pa_&
		  wxULpreewoanib_ifnndif, MSG_ERROR,y
d_scan drivedup(pol,pa_&
		  wxULpreewoanib_ifnndi;a_s->ed_sca_ERROR, "No driver in		len = os_strlenv
	in':'i;a_s->e= 0; wp[0] ++	wp'\0'R,y
a_s;tic struct wpa_suppEXT PW:ant data
 * b_ifnnddge_ifnave current_set_exULpwt_dwxULpreewoanidrv_gv
	inrn -1;o&htopy(bvkeys_changed(get_exULpwt_			"wpa_supplicatic struct wpa_suppEXT PW:aturn -1;
		}
	}

	wpab_ifnndlags & WPA_D(wpa_s->	rv_poll(wl)
{exULpwicting to skt u8 *aet_mac_exULpwlic	wpa_printf(MSG_DEBUG, "Daemonize..");
	ref (w_n;
	}_t len;
	const char *pos, *driver = name) == 0 &&
		ar_keys(w*n;
	}
wpa_bg(wpanize(pa_suppl= NULL) ;(wpa_s == NUL 0;

	ia_dbP keyR,y
a_s;tic struct wpa_suppnt data
 n_inILr_keys(wpa_soL);
wpa_so_s->driver wpa_driv ctrl_ILr_keys(wpa_so	wpa_clge_ifnan;
	}   wpa_suppltamp;
	}  L);
ct_dr?mp;
	}  L);
ct_dr: "N/A"uppltamp;
	}  _s->dri?mp;
	}  _s->dri: "	}

	do"uppltamp;
	}  ctrl_ILr_keys(w?mp;
	}  ctrl_ILr_keys(w: "N/A"uppltamp;
	}  Make sure thaw?mp;
	}  Make sure thaw: "N/A" * has->ep;
	}  L);
ct_da_suk for a_set &&BACKEND_FILEown_addr,
L);
ct_dr = osrel2abs_ theep;
	}  L);
ct_dapen l2_packet "L);
ct_dr "'%s'", wpa_drivers[i]->name);
			return -1;
	C adabsolutes theiver = wpa__auth_ciate = 1;
	truclge_i.
	}
#eltamp;
	}  L);
ct_dt TKIP countermeasures
a_s;tic struct wpa_suppC_ciate = 1;
	truclge_i ->wpa_s, NULLtamp;
	}  L);
ct_dwppol,pa_&
		ct_dt T#cipheency is noBACKEND_FILEe8021x(wpa_,
L);
ct_dr = osivedup(p;
	}  L);
ct_dt Tconcurrency is noBACKEND_FILEe8021x(wpa_,
L);
on(hs20L);
	i&ap_spacket "L);
ct_dapen l2_packet "L);
r "'%s'", wpa_drivers[i]->name);
			return -1;
	ap_scbg(wWPA_ ver = wpa_h_ciate = 1;
	ge_i.
	ppol,pa_&
		ct_dt TKIP countermeasure
 handshakeOANDROID ctrl_ILr_keys(w
 */
0;

	ides(we of  addt = mmf(MSG_r mainsupplicant_s->ep;
	}  Ltrl_ILr_keys(nding_eapoopy(buf, len&
		  Ltrl_ILr_keys(n;rface_couen&
		  Ltrl_ILr_keys( */

		 osivedup(p;
	}  Ltrl_ILr_keys(n;rfare
 hs->ep;
	}  
0;

	ides(wnding_eapoopy(buf, len&
		  
0;

	ides(wn;rface_couen&
		  
0;

	ides(we*/

		 osivedup(p;
	}  
0;

	ides(wn;rfa}
static int wpa_,
L);
on(hs20L);
	i&a_s->p nety(p;
	}  Ltrl_ILr_keys(
						100000p;
	}  
0;

	ides(wn;rackets from b&
		t_			"wpa_supplicatic struct );
			re\nNoth_ciate = 1;
	tound. the list */
		return selen;
	}   wpa_st_			"wpa_supplicatic struct );
			re\nILr_keys( pa_stocessqu, ET. the list */
		returwpa_drivers[i]-n;
	}   wpa_s)ntf(&	wpa_s_addr,
iwpa_s)a_supplicatic struct );
			re\nToo lal, iLr_keys( pa_stge_i.
	}
#e000p;
	}  re that TKIist */
		returwrivers[_own_addr(wa_suppl=n;
	}   wpa_su(&	wpa_s_addr,
iwpa_s)a* has->ep;
	}  Make sure that      100rivers[i]-n;
	}  Make sure that >=
abled;
	wpa_s_addr,
Make sure that, wpa_drivers[i]->name);
			re\nToo lal, 	wpa_clear_keys(wver = wpa_pa_stge_i.
	mp;
	}  Make sure that TKIP countermeasures
rivers[_own_addr(w     wpa_supplmp;
	}  Make sure tha	}
#e000
	wpa_s_addr,
Make sure that,;es areo
 autA St char *po}


M&&
	    (!- INITIALIZEe8021update_mac_addr(stru/
voidpa_supplicant *wFALSEi>owrv_poll(wc_addr(struct wpa_supplicant *wFALSEi>oy
	 * alled before this function 
 */pess of ore thislay print lhisupplic	 * nL2turn;
	}rint lhissothan thciated - Delay png cou the EAa_supplic	 * n);
	}
}


->l2_br  10boheibe= m(wpa_s, 0, p		}
	}

s_s->e
	} w()ticatoa_s"RSN: d driver p;
	}  
0;

	;
t *wL 0;

	:yed_sched_scan(wpa_s,t i;
	size_dbg(wpars[i]->DEBUG, "Receiving pac_suppli_set_driver
	wpa_s-drv_get_mawppol,pa_ae that TKwpa_s);
		if et_drive			"wpa_suppwpa_drivers[0] easu	len =_s->dri?m os_strlen(driver);

	w: tion = 	s->e= 0; wpa_drive_flush_pmkid(wpa_s);

	turn -1;
		}
	}

	wpae);
			re this function -rmat t *wm to the core s the led driver '%s'", nam		goto t *wL 0;

	easures
a_s; bridge interface '%s'",
				wpa_	}
	}

	wpa_s->driver =wpa_s->bri the list */
		returwpa_d
	wpa_s- NULpes(wget_mawppol,pa_&
		  
0;

	ides(wnnterval);
		return -1;
	}
	wpa_msg(wpDe this function eturn 0;
		(wpa_s->drides(wege_ifname,
			&
		  
0;

	ides(wn;rfaist */
		return sect_dr =
	wpa_s-e_wpaect_da_sm_rx_eapol(sect_dr&&m os_strmp(i
ct_dwppol,pa_re that !=erval);
		re_flush_pmkid(wpa_s);

	De this function etpliond_init(wpa_s->bridct_drPOL fge_ifnan; that TKIrivers[_own_addr(wa_suppl=n;pa_su(&	wpa_s_addr,
iwpa_s)a*  {
		wpa_msg(we..");
	ref (w_wR_ASSOC)>DEBUG, "Receiving pac_supp(wl)
{aect_da_sm_rskw_bridge(voire tha	}
#e00_addr,
Make sure tha MAC?0_addr,
Make sure tha :}
#e00d(wpa_s)_supp(wl)
{f_mgmrUTH, a_sm_rskw_bridge(voi&
		  f_mgmrUTH, n;rackets from b&
		  
ot11autAC_ciatPMKLife wpaol(wpa_s->ibssm- NULpes(wget_maskw_briautA_PMK_LIFETIMEs;

	wpa_d from b&
		  
ot11autAC_ciatPMKLife wpan -1;
	}

	wpa_dbg(wpa_s, MSG_DEBUa_s, MSG_s->to initiatint dp		}
		(wpa_ot11autAC_ciatPMKLife wpa the list */
		return sele from b&
		  
ot11autAC_ciatPMKRUTH, Thresholdol(wpa_s->ibssm- NULpes(wget_maskw_briautA_PMK_Rbled(wTHRESHOLDs;

	wpa_d from b&
		  
ot11autAC_ciatPMKRUTH, Thresholdn -1;
	}

	wpa_dbg(wpa_s, MSG_DEBUa_s, MSG_s->to initiatint dp		}
		(wpa_ot11autAC_ciatPMKRUTH, Threshold the list */
		return sele from b&
		  
ot11autAC_ciatSAcant_reql(wpa_s->ibssm- NULpes(wget_maskw_briautA_SA_TIMEOUTs;

	wpa_d from b&
		  
ot11autAC_ciatSAcant_ren -1;
	}

	wpa_dbg(wpa_s, MSG_DEBUa_s, MSG_s->to initiatint dp		}
		(wpa_ot11autAC_ciatSAcant_reR,
		MAC2STR(wpa_s->own_adp

sw.buf,ARNING, "Could nhw_feaructntica(, *driver =
	wpa_d &n_adp

sw.num_buf,Aiver =
	wpa_d &n_adp

sw.einitn;rackets fro"Could n key_dbg(wpa& key)t = 0ion fos);
		if et key_kndrescant_clear_ccket_deinit(=P key.einitt_clear_ccket_denc(=P key.enct_clear_cck thbemrUsp_offloadt(=P key. thbemrUsp_offloadtt_clear_cckmax__supplicat(=P key.max__supplicatt_clear_cckmax__s>ibss_rsplicat(=P key.max__s>ibss_rsplicat>own_addr,
pa>ibss_rsplpol - Del=P key.pa>ibss_rsplpol - Det_clear_cckmax_match- NUt(=P key.max_match- NUtt_clear_cckmax_remain_on_age (=P key.max_remain_on_age t_clear_cckmax__td - Dt(=P key.max__td - Dtreturwpa_d
	wpcckmax_remain_on_age (=sg(wpa_ear_cckmax_remain_on_age (=PPA_Ilayed_sched_scan(wpa_s, 0;

	if (wpSSOC)>DEBUG, "Receiving pak for a_set &&TDLSyed_sched_tdlsEAPOL,
					 
		)G, "Receiving pconcurrency is noTDLSBUG, "Ignored rec&
		  L 0;
ry MACS& red rec&
		  L 0;
ry 1]ql(wpa_s->ibshing PMKID liryget_mawppol,pa_&
		  ID liry	" (bridge - not for this interfac,
				wpa_sproL) liry the list */
		return sele frs_wRsEAPOL,
				)G, "Receiving p		wpa_msg(we..");
	ref (w_**
 * wpa_s>DEBUG, "Receiving p)_supp(wl)
{1x(wpa_s->key_mgmt_supplicant current_set_Ltrl_Ieys( *emonize..");
	reLtrl_Ieys(EAPOL,
				) TKwpa_s);
		iLtrl_Ieys( *			"wpa_supplicatic struct );
			;

	wpa",
				wpa_	}
	}

	wpasablrolnILr_keys(wpa_s.\ndif /* ANYouupplace.
 s to be monize..");
	rets queuedif /* ANDturn;
	rusn, sr	}
	}

truclwas\ndif /* ANmeasubyt has  lefn ug_levd - Deormeasures(wpa_s, dif /* ANin state case youuwiwpa_sed\ndif /* ANpa_manuo be removcant_driruclupplica of the Edif /* ANeasures(wpa_s, again.\}
	}
#ea_d from b&
		  Ltrl_ILr_keys(n;rfaAC2STR(wpa_s->own_adp

gat(=Pgat_queryEAPOL,
				) TKwpa_s);
		igat(=			"wpa_supplicatic struct );
			re,
				wpa_	}
	}

	wpaGAS query the list */
		returnk for a_set &&P2Pn sele frs_p2pEAPOL,
					 )
{

	inwpa_s>DEBUG-1;
	}

	wpa_dbg(wpa_s, MSG_DEBUG, "Own MAuppliP2P the list */
		returconcurrency is nod->icheck for a_set &&
FD_	sfd, NULL);
	i&evenuth_alg adbg(w t TconcurTKwpa_s);
	/* f (wpSSOC)>DEBUG, "Receiving pa	s->e=csc_rr eacif (wpSSOC)>DEBUG, "Receiving pa	s->ewonsif (w_exULpwpSSOC)>DEBUG, "Receiving pa	 u8 *src_addr,
					   const u8 *buf, siza_drv__n;
	}_t len;
	const char *pos, *driver =("Daec_addri]->glug_levd eaddr(wpa_s);
		if et_dri
		disconnected = 1;
	ey_mgmt_wpa_e(, *driver =
wpa_d isabled = 1;

		if (was_disabled ibshing PMKID list in the driver");
	w	e not left enabled (could
	 * s->own_adpe..");
	reLlefnup(pol,p) pak for a_set &&P2Pn sele fr5;
	wp
					 )
{

	ck 2pEAPOL_ fr5;
S& red rec)
{

	ck 2p" (bridge - not for this interfacP2P: */
voidid->irmallyremovx);
		wpa_	}

 &&
	    (!(Lr_keys(w_drbex);
removcdpabuf_alls_p2pEa_drv__)
{

	,
					 )
{

	)returconcurrency is nod->ichec(wpa_s);
		if et_dri
led ibshinga_drv_get_man;racketsc_addrpa_supplicant_geIeys(Eremovcdget_man;racketsug_levd eadcket");
		return;
	}

#ifder *pEVENT_TERMIN "ap_n;rackets from b&trl_Ieys(
		disconnected = 1;
Ltrl_Ieys(Ea_drv_get_mac_&trl_Ieys(
t_clear_cckLtrl_Ieys( *e_DRIVER_FLAkets from b&
		t!			"wpa_supplicaL);
	i&opy(buf, len&
		
t_clear_cckL);
on(_DRIVER_Feters
 * @wpa_s: Pointer tadd_Ieys( - Addns: 0w: 0 if succeed or -1 iftamp: de
 * This fuug levelngth= l2_msg(we..");
	ref (warting Ieys(:antr_keys(wh_ciate = 1;
	op - Dt initialize dPa_ssid * wpa_surr tMSG_ER_keys(wwpa_supplicant *wpa_s) wpa_drv_init() must ilablugh dd: 0w: 0 if succeed or ve		}
%msg(we..");
	r. wpa_drv_s->cl_sm wpa_supplicamsg(we..");
	rerus()lugh dd:== NULL) {
	pplicant -1 imainslay prloopl *gl*/
in of tedre re ddiceived 0w:== NULL) {
s->cl_s dd
 */
idynamico be ;
	ret%msg(we..");
	rust Dturn;
	rusn, s.a_drv_ss->cot_coun,*/
ie.g.inwhenia hotplug: 0 if suadapsid eturnse tedr_s)
{
	struct wpa	wpa_s = os_zalloc(sizeof(*wdd_Ieys( int debug_show_keys)
{

	iver =
	w) == 0 &&
		ar_keys(w*n;
	}
wpa_pa_s == NULL)
		return NULL;
		) == 0 &&
		ar_keys(w__n;
	};len;
	u8 bssid[ETH_  ((ss
nitialize ds_memcmp(bssIeys( *			"wpa, "Receivireq_scy
 fr5;
	_zalloc(sizeof(*wpa_s)interval = 5;
	wpa_s->new_connection =t wpa_supplicanver(struc =t t_Ieys( *e*n;
	};leitialize drides(wp. ANDROID_rs[i]->Dsupplicatic struct wpa_suppOANDROID  function to initia:a_s->driver =* AN(ge_i ->wpa_s)
	}
#e000p;
	}  (driver)lize drides(wp. ANDROID_rs[i]->t_clt_Ieys(.d driver lize drides(wp. ANDROID_rs[i]-returwpa_dlize drides(wp. ANDROID_Ltrl_ILr_keys(nding_licatic struct wpa_suppOANDROID  function to initia:aver =* ANLtrl_ILr_keys( (ge_i ->wpa_s)
	}
#e000p;
	}  Ltrl_ILr_keys(
				000lize drides(wp. ANDROID_Ltrl_ILr_keys(nt_clt_Ieys(.Ltrl_ILr_keys( */

	lize drides(wp. ANDROID_Ltrl_ILr_keys(returwpa_d
	wpce..");
	ref (w_n;
	}_dbg(wpa&w_n;
	})a_supplicatic struct interfac,
				wpa_ dd:== NULL)  %s
	}
#e000p;
	}  re that TKIst u8 *buf, siza_drv__n;
	}_river");");
	w	eapoopy(buf, lthe list */
_DRIVER_FLAencNant_gicant_rblrolnILr_keys(t Db_req 0w:=eys(w*/a	s->ewonsicant_geIeys(E dd
 ,
				)G		disconnected = 1;
	edrv__n;
	}_river")1");
	w	eapoopy(buf, lthe list */
_DRIVER_FLAs.wep) {
		int was_disabled = oed = oed =sabled)
	2)
		a_supplicant_geen == 0  dd
 ,
				ID from "ng = 0;

	rxter lize drin;
	};
		lize drin;
	};on(hs20);
pa_drv_flush_pmkid(wpa_s);

	Add
 :== NULL)  %s
	ppol,pa_ae that TKconnected = 1;
_daemon(const char *pDISy iNECTsabled( buf, len);

	wpa_pplicant
 * @ctx: Conteemovc_Ieys( - Removcas: 0 if succeed or -1 iftamp: de
 * This fuug levelngth= l2_msg(we..");
	ref (warting msg(w dPa_ssid * wpa_s 0 if succeed or eapol_sremovcda_supplicant_set_dcceed or ewassremovcd,s(struccceed or ewassest));und_s) wpa_drv_init() mus->cl_silablughdynamico be removca 0 if succeed or ve	 l2 wpa%msg(we..");
	r,ie.g.inwhenia hotplug: 0 if suadapsid etuturn 0;re r wpa ddiceivedtdrv_init() must ilablughremovcao b remainn_inILr_keys(snwhen wpa%msg(we..");
	r@src_g_levd edtic int interface_count =eemovc_Ieys( int debug_show_keys)
{

	iver =t len;
	const char *pos, *driver =->glug_levd eaddr(t len;
	const char *pos	if >oy
	 *Removcacceed or eAPOL framhow_keyd = WofnILr_keys(sn*/a		if er lize drin;
	};
		s->e=if er=nwpa_s>D	dislize drin;
	};on(hs20)ant *wpa_s cipher su;
	returif eS& rif 

	rxte;
}


/* != 		if er rif 

	rxt = 	s->e=if er=n_s);
		if (addr)
			o	rif 

	rxten(hs20)ant *wpa_s
pa_drv_flush_pmkid(wpa_s);

	Removx);
== NULL)  %s
	ppol,pa_ae that Trwpa_dlize drid2pEgroup_is receiver=nwpa_s>dislize drid2pEgroup_is receiverction = 1;
	wcted = 1;
	edrv__n;
	}_river")1")ug_levd ea;
eapoopy(buf, ltherent network structure
 * @wpa_s: Pointer euppluf, a_suppl_src, src_aEAP luf,ting msg(w dPa_ssid * wpa_s 0 if succeed or  initialize dPa_ssid * wpa_seup luf,r	}
	}

t lx);
	UNKNOWN"trucest));und_s)/
wpa_drivers[
 * @wpa_s: Pointer euppluf,pa_supplicant_update_mac_addr(wpa_bpa_drivers[rv_polnitho(ss
wpa_d  id = TRUE here since we are going to skip 4-way
     !wpa            g to skip 4-wayurrent_s		70 : 10, 0);
	}
	wpa_s->D	disnt netw"NO-EAP"pa_s
parv_polnitho(t_dwv_poll(we_wpmitho(_ct_da_sm_rskcant curPl2_pev_polnitho(t_wpa_s->new_connec	UNKNOWN-EAP"parent netwrv_polnitho(ss structure
 * @wpa_s: Pointer Ieys( - suppli 0w: 0 if succeed or -1 iftamp: de
 * This fuug levelngth= l2_msg(we..");
	ref (warting Iect_d:antr_keys(wn headertialize dPa_ssid * wpa_s_ER_keys(wwpa_supplrucest));und_s)/

	struct wpa	wpa_s = os_zalloc(sizeof(*ter Ieys( int debug_show_keys)
{

	iver =
	wbg(wpanize(pa_suppif (wpa_s == NULL)
		return NULL;
	wps.wep fr5;
	_lize drin;
	};
len);

  fr5;
	_zallo
	2)
		      100riversrmp(pol,pa_ae thanan; thattic int select_drNULL;
		} int i)
{
	struct w#n; or a_set &&wpa_s- {
	,
					 wpa_drivers[
 * @wpa_s: Poinmsgure tha_cbuct wpa_suif (len < sizeof(*eth))
		return;
	eth = (rval = 5;
	wpa_s->new_connection = lect_drNULL;a_ae tha;
urconcurrency is nowpa_s- {
	ichecructure
 * @wpa_s: Poinupplicant data
 * %msg(we..");
	rting des(wp dPo initiale		}
%msg(we..");
	radertialize dPa_ssid * whow_key%msg(we..");
	r@lngt,wwpa_supplicant *wpa_s) wpa_drv_init() must ilablughit data
 * %msg(we..");
	r. Afsid  interffulough
  data
 aceivedtd_srealizpa_dngthriver_ops->cl_silablugh dd:
 */pemovc
ut go if succeed or v,:
 */lay puo be,lughdeit data
 * %msg(we..");
	r._s)/

	struct wphow_keys_msg(we..");
	ref (wa
	struct wpug_leve*to the f (wpa_s ==ug_show_keys)
{

	= (rv_getr,ii pa	s->e=g_leve	wpa_s->new_connection =tk for a_set &&	wpa_s-NDIS
	    ct wp 0;

	incusif (w_ops));
	i		o	 0;

	incusif (w_ops))returconcurrency is no	wpa_s-NDISicheck f or a_set &&wpa_s- {
	,ket");
	wpess of {re tha_cbu * @wpa_s: Poinmsgure tha_cbt Tconcurrency is nowpa_s- {
	icheca_drv__ssids->bstruc(des(wp

_drv__ssidtruc_ thei;a_s->e=es(wp

_drv__ssidsyslog
led ibsh_ssids->bssyslog(i;a_s->e=es(wp

_drv__ssidtracx);>D	disnt tamp = debug_s->bslinuxdtracx); to initiant , wpa_drivers[i]->name);
			
r = wpa_,
				wpa_ inter t framloggx);"t TKIP countetion = 	}a_s, int t_dwv_wpess of {nitho(s(i;a_s->ent , wpa_rivers[i]->name);
			return -1;
	apss of oEAP litho(s"to initiant r_ss-2)pa_drivers[i]->name);
			 "Twowwpaif suEAP litho(ssilablver = wpa_	}

s_s->EAP type.v_flags & WPA_DRIVER_FLAplicanvern_req = 1;
	wpa_s-)
{

	)i;a_s->elize ds_memcmp>new_connection = dl_d = ef (wa&lize drid2pEsrv_bonjou->t_cdl_d = ef (wa&lize drid2pEsrv_upnit TKlize drides(wp.loc(void)er res(wp

	oc(void) TKlize drides(wp.wa(w_		}_(voitoer_ res(wp

wa(w_		}_(voitoe TKlize drides(wp.lbus_Ltrl_ILr_keys( * res(wp

	bus_Ltrl_ILr_keys(;a_s->e=es(wp

id_file);

	lize drides(wp.id_file)r = osivedup(=es(wp

id_file);;a_s->e=es(wp

Ltrl_ILr_keys(n

	lize drides(wp.Ltrl_ILr_keys( */

	 osivedup(=es(wp

Ltrl_ILr_keys(nt_cs->e=es(wp

 ANDROID_rs[i]->

	lize drides(wp. ANDROID_rs[i]- */

	 osivedup(=es(wp

 ANDROID_rs[i]->t_cs->e=es(wp

 ANDROID_Ltrl_ILr_keys(n

	lize drides(wp. ANDROID_Ltrl_ILr_keys( */

	 osivedup(=es(wp

 ANDROID_Ltrl_ILr_keys(nt_cp = debug__debug_slize drides(wp.w = debug__debug_	o	res(wp

_drv__ssidys = debug_show_ke		wpas_notiflize drides(wp.w = debug_		wpas_noti	o	res(wp

_drv__ssid		wpas_nodebug_show_ke;
	if (wpaiflize drides(wp.w = debug_;
	if (wpai	o	res(wp

_drv__ssid;
	if (wpR,y
a_s;tic struct wpa_suppmsg(we..");
	r@v" a_sSION_STRt Trwpa_deloopef (wara_supplicatic struct );
			re,
				wpa_	}
	}

	wpalay prloop"t TKIst u8 *buf, siza_drv_to the curags & WPA_DRIVER_FLAr
 *omef (wares(wp

BSSIopyfile);;aTKlize driLtrl_Ieys( *emonize..");
	replicantLtrl_Ieys(EAPOL,o the curapa_dlize driLtrl_Ieys( *			"wpa_supplica8 *buf, siza_drv_to the curags & WPA_DRIVER_FLAs->ewonsicant_gewe..");
	ref (w}

	wpdto the ca_supplica8 *buf, siza_drv_to the curags & WPA_DRIVER_FLA == len &&
			    os_strncmp(dri
priv[i] == NULn 0;
}


spa_dlize dri NULn 0;
t = 0ion fos);
tic struct );
			re	if (namesures. */"t TKIst u8 *buf, siza_drv_to the curags & WPA_DRIVER_Friv[i] == NULL) {vern_req = 1;lize dri NULn 0;
t*(&	wpa_sct wpa)curapa_dlize drif et_drive			"wpa_supplica8 *buf, siza_drv_to the curags & WPA_DRIVER_FLk for a_set &&
IFIpDISPLAYLAs->ewifi
id)playEAPOL,o the cDEBUG-1;
	}

	tic struct );
			re,
				wpa_	}
	}

	wpaWi-Fi */
play"t TKIst u8 *buf, siza_drv_to the curags & WPA_DRIVER_Ftry->bssid_set &&
IFIpDISPLAY_mgmt_pa_prin)
{

	= wpa_pplicant
 * @ctx: Conteuver RuLDCARD%msg(we..");
	r@mainslay prloop-1 iftamp: de
 * This fuug levelngth= l2_msg(we..");
	ref (wartingpplicant_seafsid  interffulslay prloopleuvace parameters.
 * wpa_drv_init() mu of tue it mainslay prloopl
 */_rblinuackeusn, sras lal, at initld no courentremainn_inlay pnre remframcasesedtdrv_init() must eusn, sraser maal, atDCARD%msg(we..");
	r@ts queueinpa_s->linpilatic int interface_count =eun int debug_show_keys)
{

	if (wpa_s == NULL)
		return NULL;
	wppa_dlize drides(wp.loc(void)el(wpa_s->ibsse..");
	return oslize drides(wp.id_file))G, "Receiving p		wpa_lize drides(wp.wa(w_		}_(voitoeG-1;
	s.wep fr5;
	_lize drin;
	};
len);

  fr5;
	_zallo
	2)
		/

	kets from b&trl_Ieys(
er = >ibsse..");
	reLtrl_Ieys(Ewa(w(ver =
 from b&trl_Ieys(
pa_s
parloopepess of {
ignantug_levd eu * @wpa_s: Poinug_levd er)lize di>owrloopepess of {
ignantreh_ciatu * @wpa_s: Poinreh_ciatr)lize di>oowrloopepus()herent network structure
 * @wpa_s: Poina_drv_>pendit data
 * %msg(we..");
	r-1 iftamp: de
 * This fuug levelngth= l2_msg(we..");
	ref (wartin wpa_drv_init() must have been deit data
 * %msg(we..");
	rrom tho opy(ao b wpa  = 1 tMSGresrrentnreRemainn_in 0 if succeed or vewiwpaalspol_sremovcd const u8 *buf, size_t lena_drv_tint debug_show_keys)
{

	if (w 
		reta_s->elize ds_memcmp>new_conne =tk for a_set &&
IFIpDISPLAYLAwifi
id)playEa_drv_to the curtry->bssid_set &&
IFIpDISPLAY_mgmk for a_set &&P2Pn wlls_p2pEa_drv__)
{

	,o the curtry->bssid_set &&d->ichec(;
	retulize drin;
	};)TKIst u8 *buf, sizeemovc_Ieys( )
{

	inlize drin;
	};to operapa_dlize driLtrl_Ieys()TKIst u8 *buf, sizplicantLtrl_Ieys(Ea_drv_to the  b&trl_Ieys(
pa
supplicant_ge size_t lena_drv_}

	wpdto the c;
parv__pef {unpess of {nitho(s(i;a_s, src_addr, buf,rv__Iheda {unpess of {nitho(s(i;a__dbg(wpa_s, MSG_DEBUG, " == len &&
			    os_strnceS& lize drif et_drimp(driver, s->ealize drif et_drirnc
er =_rblinua TKIst u  os_strncupplicanEa_drv_to the  bf et_drirnc
;eturwrivopy(bo the  bf et_dri)heren
 *omea_drv_ti>oowrloope	lenroy(t Trwpa_dlize drides(wp.id_file))on fo&htloc(void)tug_levd eulize drides(wp.id_file))	w	eapoopy(blize drides(wp.id_file))	w	urwrivopy(bo the  bdes(wp.Ltrl_ILr_keys(a;
eapoopy(blize drides(wp. ANDROID_rs[i]->t_capoopy(blize drides(wp. ANDROID_Ltrl_ILr_keys(a;
_capoopy(blize drid2pEais EAPOoopyqa;
_capoopy(blize dnt_cp = debug_closessyslog(i;a_p = debug_closestruc(i;a_p = debug_closeslinuxdtracx); to MSG_  const u8 *buf, siz
		wpa_h_ciatu u8 *addr = wpa_drv_get_mac_addr(wpa_ored rec&
		  Lhnterd_to initial & CFGreq !GED_COUNTRY)ol(wpa_s->ibss_rs
		  L 0;
ry MACS& red rec&
		  L 0;
ry 1]a_suppwversL 0;
ry 3]	w	eL 0;
ry MAC=->ibss_rs
		  L 0;
ry MA	w	eL 0;
ry 1AC=->ibss_rs
		  L 0;
ry 1A	w	eL 0;
ry 2		wp'\0'R,
	kets frohing PMKID liryget_mawpID liry	DEBUG-1;
		}

	tic struct );
			re,
				wpa_sproL) liryoL)d(wver = wpa_ge_ifnaID liry	 = 	}a_s, iIgnored rec&
		  Lhnterd_to initial & CFGreq !GED_EXT_PWoBACKEND	a_supplif (w_exULpwpSSOC)> =tk for a_set &&
PS
suppliwRsE
		wpa_h_ciatuSSOC)> =try->bssid_set &&
P, check for a_set &&P2Pn wlls_p2pE
		wpa_h_ciatuSSOC)> =try->bssid_set &&d->ichec(;ed rec&
		  Lhnterd_to initial =rc_addr,
					   conwdd_opyq( 
		*opyqplican *num_opyqplican opyqaf (w 
		reta_s.wep_key[i] = s*num_opyqpmp(driver, s->eopyqp
			w= opyqaf	ew_conne =R_FLA pyqp
*num_opyqp		wpopyq =R(*num_opyqp)}


MSG_DEBUG, "Dae*	C a
	/* opyqpif _ueupa_supplicant_update_mac_addr(wpa_s)supplican	/* *brfac*cbrf;a_bpa_dri	r@max opyqp(=PPA= (rv_g*opyqp= (rv_gnum_opyqprc_addr,opyqprc_n_req = 1;
	wpa_srv_)e*	(max opyqp(+o ocurapa_dopyqprcwpa_s->new_connection =t cbrfC=->ibss_rsn, src_brf;a_cdl_d = e		}_each(brfac&n_adp

brfacs)supplican	/*,yd = iver, s->ebrfC== cbrf
er =_rblinua TKIs->ebrfbled =id_set= cbrfbled =id_se&wpa_s->lest[0] & 0brfbled =, cbrfbled =, brfbled =id_s
     !wpa	pa_s->ibsblackd = eC aget_mawpbrfblb fromr "'%s'", wpa_dwdd_opyq(opyqpli&num_opyqplibrfblopyqa;


	ketsnum_opyqprc=@max opyqp != 		breakna 	}a_s, iIgnonum_opyqprc=@0)on fo&htopy(bopyqp na 	opyqprc__DRIVER_FLArconnecopyqp= MSG_  const sturn wpa_s;_mete_f_t len;
	const char *pos, *dri struct l2_eant_se (w 
		 wpa_s-= (rv_gID li= (rv_g*opyqpnt_req_scy
	 ticatRemovcaaddress ty_mgmt_wpa_ieee wpa_s-irmallycant_rburn -1;
	ete_ft) &&
		rlooper *cel	 wpa_s-> * @wpa_s: Poinuwpa_s-*addr = wld
	 * happ * an dd
	}

t
				wddr, Ein* wpa_sblackd = rom tspoingup t *wms_rs
	 * stt netlructld nollow any to be APsthan tllow aaccep thciated - Dt) &&gh. *c, src_ablackd = rn 0;
tiy->1 tMs how
 &&ye wpasowlyce.
 tri
	 * an_rburn -alid. tdrv_DEBom tmultips tytt nets mefn uan tto be APstemcpy(wpeio be est)pa_s, 0, p.we *glDturn;
	*/
intri
	,ssothan tweps->c of tpy(wpmalurns		 * th ppliculd nough   construc *pos_rsn, st) &&
		
	if (wp>ibsblackd = ewddget_mawpbrfidi;a_s->en 0;
t = 1CS& red rec&n, src_brf		 * handshake_drv_ddrewassest)ILDCARDblackd = r	pplic.n cotld noisdshakes to be ddrepa_s, 0, p		}
	}

s_s->ESS,twepshlow airyohan 
hout goxt. Oo bewise,tweppplaasowlwpairyoharv_on p.allymlic	 out 	pplica EAPO, sr	o be,yd kebe ;orse,tESS		eapol_sm_nfider_ft) licant_opyqpnt_C a
	/* opyqpif _ueupSSOC)> =, s->eopyqp; wpa_drive_flush_pmkid(wpa_s);

	A to be ddreILDCArv_ESSae);
			 *gl*/
in /
i;airyoit goxt"n;rface_coblackd = ewddget_mawpbrfidi;a_ handshhakeOnwpa_s 0*wms_rsinlopol, TRUEonlgicantkndresLhntnelsdshhakeilablILDCArv_ESSabalabl1;
rif iousms_rs	eapospoingupdshhake= mm1;
loadabal *c, srilamcase.dshhak/
g_eapoopy(buf, lent *wLs_rspopyqp na 		uf, lent *wLs_rspopyqp	wpopyqsna 	}a_s, iswitch>en 0;
; wpacase 1:}
# wpa_s-i=PPA_na 	breakna case 2:}
# wpa_s-i=P5A_na 	breakna case 3:}
# wpa_s-i=PPA__na 	breakna 	}

	do:}
# wpa_s-i=P5A_0;es areo
	 * nTODO:lrucmlicant->con paddress tDEBst Da_s, 0, pinpas->cres	doriveake= ow airyohay to be on {
	pplicassqulen, srai 0w:as->t) &&
		st u8 *buf, sizeee
		wpa_suppli wpa_s-i/PPA__	
r = PA__e*	( wpa_s-i%PPA__)) pak for a_set &&P2Pn sele fr5;	 )
{

	ck 2pEcb_on_s_rspm_notifyCS& ! fr5;	 )
{

	ck 2pE

		otherl(wpa_s->ibss_r)
{

	ck 2pt!			"wpa_supplica;	 )
{

	ck 2pEcb_on_s_rspm_notifyC len;
	s->e=2pEto be_s_rspm_notifyde fr5;	 )
{

	ck 2pmr "'1; wpa_drive_flush_pmkid(wpa_s);

	P2P: Pry->_sca->iope = 1;
	e);
			retlinuadeafsid t
				whciated - D"	 = 	}a_s,try->bssid_set &&d->icheMSG_"Daemonsi 0;

	i	/* e
	} w- Dpa_supplicant_update_mac_addr(wpa_lect_drNULL;a_&
		  v__Ice (=sg2 ||;

_s);
		if eteinit(&ar *pDwpa_s-FLAGS_ddr_SELECTION)ruct w#n; ppfinyde_set &&CTRL_IFACE)n !=
efinyde_set &&CTRL_IFACE_DBUS_NEW)nt interface_count =Ltrl_Ieys(ELtrl_rsp_int lh_t len;
	const char *pos, *driver =(  name) == 0 &&
	(ssid && s,(wr =(  namewpa_drivers[fiels,(wr =(  namewpa_drivers[int d(wpak for a, 0);
	}
	);
	}a_s)supplrv__pef {L);
	in[rv_C l&led)
	rv_R,y
a_s;tic struct wpa_suppCTRL_IFACE:cresppa_}rint lh fiels=%s
	pfielsi;a_p = hexdump_asciias_nruct wpa_suppCTRL_IFACE:cresppa_}rint d"s;

	wpa_daddr, ET l2_)rint d, rivers[i]-int d( * haswitch>eterface_count =Ltrl_eee
= l2_t lx);(fielsi; wpacase r *pCTRL_REQ	);
_IDENTITY: fo&htopy(brv_->idetlity;laIPrv_->idetlitycant l2_)r osivedup(int d(laIPrv_->idetlityid_set rivers[i]-int d(laIPrv_->pry->_s_eee
idetlitycanen;
	s->eed =sa=->ibss_rsn, src_ant_set_plica;	 urnse(wpa_sscant_clbreakna case r *pCTRL_REQ	);
_PASSWORD: fo&htopy(brv_->preewoan(laIPrv_->preewoancant l2_)r osivedup(int d(laIPrv_->preewoanid_set rivers[i]-int d(laIPrv_->pry->_s_eee
preewoancanen;
	s->eed =sa=->ibss_rsn, src_ant_set_plica;	 urnse(wpa_sscant_clbreakna case r *pCTRL_REQ	);
_NEW_PASSWORD: fo&htopy(brv_->	retpreewoan(laIPrv_->	retpreewoancant l2_)r osivedup(int d(laIPrv_->	retpreewoanid_set rivers[i]-int d(laIPrv_->pry->_s_eee
	retpreewoancanen;
	s->eed =sa=->ibss_rsn, src_ant_set_plica;	 urnse(wpa_sscant_clbreakna case r *pCTRL_REQ	);
_PIN: fo&htopy(brv_->pin(laIPrv_->piset riversdup(int d(laIPrv_->pry->_s_eee
piset en;
	s->eed =sa=->ibss_rsn, src_ant_set_plica;	 urnse(wpa_sscant_clbreakna case r *pCTRL_REQ	);
_OTP: fo&htopy(brv_->otp(laIPrv_->otpcant l2_)r osivedup(int d(laIPrv_->otpid_set rivers[i]-int d(laIP&htopy(brv_->pry->_s_eee
otp(laIPrv_->pry->_s_eee
otpt_dtion = 	rv_->pry->_s_eee
otpid_set _na 	breakna case r *pCTRL_REQ	);
_PASSPHRASE: fo&htopy(brv_->p0;
wpa_ip 4preewn(laIPrv_->p0;
wpa_ip 4preewncant l2_)r osivedup(int d(laIPrv_->pry->_s_eee
preephrase t en;
	s->eed =sa=->ibss_rsn, src_ant_set_plica;	 urnse(wpa_sscant_clbreakna 	}

	do:}
#a_s;tic struct wpa_suppCTRL_IFACE:cUnkndresfielsfge_ifnafielsi;a_aAC2STR(wpa_s->ownt network#cipheenc, 0);
	}
	);
	}&&
		st utic struct wpa_suppCTRL_IFACE:c, 0) ;
	.1Xsest)ILclud*/"t TKReceiving pconcurrenc, 0);
	}
	);
	}&&
	s,try->bssid_set &&CTRL_IFACEn !=_set &&CTRL_IFACE_DBUS_NEWichecr"Daemonsien == 0 

		othe_t len;
	const char *pos, *dri ) == 0 &&
	(ssid && saf (w 
		ret	un
ign
 :==  et_denc Trwpa_ded =sa=-a_s->new_connec1 Trwpa_ded =
	id)
{
	nif, MSG_ERRg packets fromCS& red recf et key_kndreif, et_denc(=Pred recf etenct_ctic intet_denc(=P(un
ign
 :== )ing p		s.wep_key[i] = sNUM_WEPs		7Smp(driver, rn -1;

	isabled)
	wep_ip 4
	irncm;
	s->ed_set= 0
er =_rblinua TKIs->ed_set= 5CS& (et_denc(&ar *pDwpa_s-CA *pENC_WEP4nterfac_rblinua TKIs->ed_set= 13CS& (et_denc(&ar *pDwpa_s-CA *pENC_WEP104terfac_rblinua TKIs->ed_set= 16CS& (et_denc(&ar *pDwpa_s-CA *pENC_WEP128terfac_rblinua TKIMSG_ERRg ssidi_s, MSG_EP ip &&
		s, iIgnored  here since wpskded =
	ip 4-way
 S& !ed =
	pskg PMrl(wpa_s-!ed =
	exULpps_et_STR
		 g pa	 u8 *src_addr,"Daemonsiis_p2pEticorit	wpdt u8 *addr = wpa_drv_get_mac_addr(wpa_ fr5;	 )
{

	ck_rbcEtie	t_		r *pCONC_PREF&d->_et_STR
		 g p(wpa_ fr5;	 )
{

	ck_rbcEtie	t_		r *pCONC_PREF&STAif, MSG_ERROR,KReceiving pMSG_  const sty_mg_mete_f_t len;
	const char *pos, *drif (wpa_s == NULLssid && sC=->ibss_rsn, src_  ((ss("Dae	u ;(wpa_s == os wpaondr Trwpa_ded =sa=-a_s->_supplicatic struct interfacA_mgmt_wpa_ieeemeters. breq otkndresver =* ANdr, Eblockv_flags & WP;		s, iIgnoed =
	ip 4-wayt_		r *p		70 : 10WPS_et_STR
		" riled)
		_mg_metethe }


spa_dled)
		_mg_metethe  > 50
er 	u C=-3_0;esciphepa_dled)
		_mg_metethe  > 20
er 	u C=-120;esciphepa_dled)
		_mg_metethe  > 10
er 	u C=-60;esciphepa_dled)
		_mg_metethe  > 5
er 	u C=-3_;esciphepa_dled)
		_mg_metethe  > 1
er 	u C=-20;escipher 	u C=-10;
_capoC a
 wpa(&ndri;a_s->endr.sec +e	u  <abled)
			wpas_d_ut_wl.sec_et_STR
		" riled)
			wpas_d_ut_wl.secC=-ndr.sec +e	u ))val);
	wpa_s->scan_in
#ifder *pEVENT_TEMPpDISABLED
t(wps=%dbled)=\"%s\" 	_mg_metethe =%ue	u a_iee=ng sr, red)
	inwppol,pd =itxtdled)
	ed =, led)
	ed =id_s
sr, red)
		_mg_metethe ,e	u )= MSG_  const stuleft t ne 

		othe_t len;
	const char *pos, *dri
 =(  name) == 0 &&
	(ssid && s,:==  uleft metethe addr(wpa_ed =sa=-a_s->new_conne Trwpa_ded =
	id)
{
	n_ut_wl.sec_-1;
	}

	wpa_dbg(wpa_s, 
#ifder *pEVENT_REENABLED
t((wps=%dbled)=\"%s\""s;

	red)
	inwppol,pd =itxtdled)
	ed =, led)
	ed =id_s
)	w	urwled)
			wpas_d_ut_wl.secC=-0;esled)
			