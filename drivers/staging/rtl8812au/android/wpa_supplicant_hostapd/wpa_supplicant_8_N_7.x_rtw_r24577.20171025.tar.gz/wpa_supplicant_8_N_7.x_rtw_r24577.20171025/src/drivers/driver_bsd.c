/*
 * WPA Supplicant - driver interaction with BSD net80211 layer
 * Copyright (c) 2004, Sam Leffler <sam@errno.com>
 * Copyright (c) 2004, 2Wire, Inc
 *
 * This software may be distributed under the terms of the BSD license.
 * See README for more details.
 */

#include "includes.h"
#include <sys/ioctl.h>
#include <sys/sysctl.h>

#include "common.h"
#include "driver.h"
#include "eloop.h"
#include "common/ieee802_11_defs.h"
#include "common/wpa_common.h"

#include <net/if.h>
#include <net/if_media.h>

#ifdef __NetBSD__
#include <net/if_ether.h>
#else
#include <net/ethernet.h>
#endif
#include <net/route.h>

#ifdef __DragonFly__
#include <netproto/802_11/ieee80211_ioctl.h>
#include <netproto/802_11/ieee80211_dragonfly.h>
#else /* __DragonFly__ */
#ifdef __GLIBC__
#include <netinet/ether.h>
#endif /* __GLIBC__ */
#include <net80211/ieee80211.h>
#include <net80211/ieee80211_ioctl.h>
#include <net80211/ieee80211_crypto.h>
#endif /* __DragonFly__ || __GLIBC__ */
#if defined(__FreeBSD__) || defined(__FreeBSD_kernel__)
#include <net80211/ieee80211_freebsd.h>
#endif
#if __NetBSD__
#include <net80211/ieee80211_netbsd.h>
#endif

#include "l2_packet/l2_packet.h"

struct bsd_driver_global {
	void		*ctx;
	int		sock;,sd_dEndif

#include "l2_p(uns>
#e(drv);clude <sa;#ifdif

#in;#ifink clude "l2_p
#end);cludame)inta even_addren;
	u8ew_sta.n_adr = os_cp_messal_cket>pf,
	sif

#incketSD l down",
	sstatic id_driver_global {
har ifnacp_messal_cket>cketos_cp_messr_global {
	void		*	void	os_cp_messata *hapd,
				   ;
#inee ifo the sesocketpacket_data *l2;
	char
{
	ixmit;cket socket foxmit clude "cludame)iNAMSIZ + 1];
	v+1];
#in name %s", __fuclude <s_int32_t ong) lenex,
				   ;	
#in name %s",;
		dlclude <sh>
E multd;	
#inhSSID" f name %s",beenAE multd? |= 1 ;
	iruct l2_packetr_capa *capa)
{
a)
{;
#interactia)
{bilitylclude <shs_apif

#inA	int do the		   lclude <sprev_roamink;
#in;#amink= 0)
ee PAE stls.
SD wpa_driclude <sprev_t flacy;
#int flacy= 0)
ee PAE stls.
SD wpa_driclude <sprev_w
{;
#inw
{= 0)
ee PAE stls.
SD wpa_driclude;
	m_netbsd.h>op	   lop	   ;
#in completed	   lcluic i#inGeneric 	}

]; /*"l2_pata *ha backicant roboswitcc const u8 d_driver_global {
har i*
r_gl
	.i
co->ifnav, u8 *bssid)ong) lenex,
				   ct wpa_driver_global {
	void		*	void		struct ieee8023_r_global {
har i*v = os_zl_cket_l2_.gechams->o&	void	 fla,
	s, d_driver_global {
har ,ncket(*sep < '0me, fla;
		dlp=
				   ct NULL;
		} flags 0;
#else else {}__DranPD
	struct inst u8 d_driver_global {
har i*
r_gl
	.i
co *priv)
{
	struhar *ifname)
{
	struct wpa_driver_global {
	void		*	void		struct ieee8023_r_global {
har i*v = os_zl_cket_l2_.gechams->o&	void	 fla,
	s, d_driver_global {
har ,ncket(*sep < '0y(drv-readme, ifname, sizeof()	return 0;
	}
	/* flags 0;
#else else {}_ HOSTAPD */
}


statint wpa_driv
r_glseee8021iv)
{
	struhaex,
ophaex,
len)
r *ifnv)
{
	arg)
{
	strg_truct wpa_driver_global {
har i*v =	struct ieee8023_hdr *hd11	int  (sock < 0)me, fla;
		dlp=
0ed(__e, fla
E multdn -1;

	os_memset(&mreq, 0, iizeof(mreq));
	ireq.mr_iy(ifr.ifr_nadresiv->ifname, sizeof(ifr.ifr_nadresiv->ifdrv ==dresivons(ETHt8_t =dresivvd		st (ioc =dresivhar i= iv)
{
	)strgoc =dresiveof(sttrg_truoctl(drv->fd, SIOCS	void	 fCGIFHWADDRS*hd11= 0)req.	wpa_printf(MSG_ERROR, "ioctl[SIOCSIFFLAGS]:*hd11= op=%u,t (i=%u,tgroup (SItrg_tru=%u		   st
ophalen)
trg_trutrerror(errno));
		return -1;
	}
	if (setso
}


static vt wpa_driv
r_glgeee8021iv)
{
	struhaee8023_hdr *hd11	int*iizeofex,
ophav)
{
	arg)a_drive{
	strg_truct wpa_driver_global {
har i*v =	struct iet(&mreq, 0,iizeof(mreq));
	*ireq.mr_iy(ifr.ifr_nadre siv->ifname, sizeof(ifr.ifr_nadre siv->ifdrv ==dre sivons(ETHt8_t =dre siveof(sttrg_truoc =dre sivhar i= trgoctl(drv->fd, SIOCS	void	 fCGIFHWADDRG*hd11= )req.	wpa_printf(MSG_ERROR, "ioctl[SIOCSIFFLAGS]:*hd11= op=%u,tgroup (SItrg_tru=%u		   st
ophatrg_trut(errno));
		return -1;
	}
	if (setso
}


static vt wpa_driv
geee8021var(a_driver_global {
har i*v =ofex,
ophav)
{
	arg)e{
	strg_truct wpa_drivehdr *hd11	int  (sock < 0)r_glgeee8021ims->o&iizeofophatrghatrg_trureturn -1;
	if (!(rea;
	if (=dresiveoftic vt wpa_driv
seee8021var(a_driver_global {
har i*v =ofex,
ophar *ifnv)
{
	arg)
{
	strg_truct wp;
	if (r_glseee8021iv =ofopha0hatrghatrg_trurtic vt wpa_driv
seee8021d *pria_driver_global {
har i*v =ofex,
opha{
	strgct wp;
	if (r_glseee8021iv =ofophatrgha_P_ALL0rtic vt wpa_driv
r_gl
	.i *priv, u8 *ssid)
{
	ssid)
{
	int i;

	a_driver_global {
har i*v =	struct iGLIBC__ADDRG*hd11NWI ieee8023_hdr *hd.h>
w u8
w u;ifreq ifr;
	int s;

et(&ifr, 0, sizeof(ifr));
	os_strlcpy(ifr.ifr_name, drv->ifname, sizeof(ifr.ifr_name));
	if (ioctl(de));
	har i= iv)
{
	)&
w u;if(drv->fd, SIOCS	void	 fCGIFHWADDRG*hd11NWI ,0) {
		wpa wpa_driv
w usiveof(> IEEE*hd.h>NWI _#end -1;
	if (!(rea(sap->sa_dasid)

w usiv
w u,v
w usiveofn 0;
}


st
w usiveof* __lin0;
}


stgeee8021var(v =ofIEEE*hd.h>DDR_ wirifrsid)
IEEE*hd.h>NWI _#end/* __linic vt wpa_driv
r_gls	.i *priv, u8 *ssid)*src_addr,
sid)
{
	i
sid_truct wpa_driver_global {
har i*v =	struct iGLIBC__ADDRS*hd11NWI ieee8023_hdr *hd.h>
w u8
w u;ifreq ifr;
	int s;

et(&ifr,sa_d
w usiv
w u,v
sid)

sid_truc;if
w usiveof(=

sid_tru;et(&ifr, 0, sizeof(ifr));
	os_strlcpy(ifr.ifr_name, drv->ifname, sizeof(ifr.ifr_name));
	if (ioctl(de));
	har i= iv)
{
	)&
w u;if;
	if (=>fd, SIOCS	void	 fCGIFHWADDRS*hd11NWI ,0) {
	* __lin0;
}


stseee8021var(v =ofIEEE*hd.h>DDR_ wirifrsid)

sid_truc;i __linic vt wpa_driv
r_glgs(drv

#ifdiv)
{
	struct wpa_driver_global {
har i*v =	struct ieee8023_h ifmr;
	int s;

et(&ifmr, 0, sizeof(ifmr));
	os_strlcpy(ifmr.ifm_name, ifname, Ime, sizeof(ifr.ifr_namme, ifname,))octl(drv->fd, SIOCS	void	 fCGIFHWADDRG(caddr_t)0) {
		wpa_printf(MSG_ERROR, "ioctl[SIOd toADDRG(caddr_unc__, ifname);rerror(errno));
		return -1;
	}

	if (bind(;
	if (=mme, ifncurrn = rc vt wpa_driv
r_gls	.irv

#ifdiv)
{
	stru)
{
	i
#ifdct wpa_driver_global {
har i*v =	struct ieee8023_h 	int s;

et(&ifr, 0, sizeof(ifr));
	os_strlcpy(ifr.ifr_name, drv->ifname, sizeof(ifr.ifr_name));
	if (ioctl(de));
	
#ifddres#ifdoctl(drv->fd, SIOCS	void	 fCGIFHWADDRS(caddr_t)0) 
		wpa_printf(MSG_ERROR, "ioctl[SIOd toADDRS(caddr_unc__, ifname);rerror(errno));
		return -1;
	}

	if (bind(;
	if (atic vt wpa_driv
r_gls	.is#ifddhcpv, u8 *ssid)
ookie;
	maskd)
ookie;
	modelen;
	uns
#ifddrer_glgs(drv

#ifdistrucoctl(drv
#ifddturn -1;
	if (!(rea
#ifdd 4);maskrea
#ifdd|=	mode;k < 0)r_glss(drv

#ifdistru,i
#ifdceturn -1;
	if (!(rea;
	if (atic vt wpa_driv
r_gldel_keyiv, const u8 *addr,
			    c
{
	ikey_idxct wpa_drivehdr *hd11	inldel_key wk

et(&ifr, 0, swkof(ifr));
	owkdrv == NUrams->
		wpa_printf(MSG_INFO,
			s: Failed tokey_idx=nc__, vlan & ~(key_idxc (wpak.idk_keyi
#ifkey_idx {
		wpa_printf(MSG_DEBUG, "%s: Enabled arams=
		   MAC, ifname);rerror(ac_addreaddr.sll_t(&ifr,sa_dak.idk_macr_be16);

ofIEEE*hd.h>

	if#endif pak.idk_keyi
#if(options[)fIEEE*hd.h>KEYIX_NONE;
#inXXXicludind(;
	if (seee8021var(st u8 IEEE*hd.h>DDR_DELKEYt)0wkofr));
	owkdrv c vt wpa_driv
r_gls	nd_mlmeparamsiv, const u8 *addr,
		ophar *ifntypereason8 *addr)
{
	u16 _reada_drivehdr *hd11	inlmlme mlmemset(&mreq, 0, slf(if(mreq));
	ml (ioctlml (.im_opETHt8_t ml (.im_reasonock, asonrea(sap->sa_dml (.im_macr_be16);

ofIEEE*hd.h>

	if#endif ;
	if (seee8021var(st u8 IEEE*hd.h>DDR_MLMEt)0slf(ifeq));
	ml (ioctc vt wpa_driv
r_glcr.i_la,
	iv)
{
	stru)
{
	ilmultict wpa_driver_global {
har i*v =	struct ieee8023_h 	int s;

et(&ifr, 0, sizeof(ifr));
	os_strlcpy(ifr.ifr_name, drv->ifname, sizeof(ifr.ifr_name));
	if (iocttl(drv->fd, SIOCS	void	 fCGIFHWADDRG(caddr_t)) {
		wpa_printf(MSG_ERROR, "ioctl[SIOCGIFFLAGS]: %s",
			   strerror(errno));
		close(s);;
	}
	if (setso
	os_fr.ifr_flags & 0xffffcttl(drvlmultic*sep < '0lags & 0xffff;
	 0) {
	n 0;
	}
	/*emcpylags & 0xffff;|=	 0) {
 {
		wpa_print->is_5lags & 0xffff;
	 0) {
		n 0;
	}
	/*emcpylags & 0xffff; 4); 0) {
 {
	ctl(drv->fd, SIOCS	void	 fCGIFHWADDRS(caddr_t)) {
		wpa_printf(MSG_ERROR, "ioctl[SIOCGIFFLAGS]: %s",
			   strerror(errno));
		close(s);;
	}

	if (bind(
	os_fr.ifr_flags & 0xffffct(;
	if (atic vt wpa_driv
r_gls	.ikeyir *ifname, const u8 v)
{
	stru)
e;
	mf(MSalg alg)a_driv*addr)
har *buf, size    c
{
	ikey_idx)
{
	i
	.i char *ifnddr,
eq)a_drivn;
	u8 
eq_trut(r *ifnddr,keydata_len,key_truct wpa_drivehdr *hd11	in_key wk

GLIBC__IEEE*hd.h>KEY_NOREPLAYwpa_driver_global {
har i*v =	struct iGHOSTAPD *IEEE*hd.h>KEY_NOREPLAYesockef(MSG_DEBUG, "%s: Enabled arlg=ncarams=%pokey_idx=nci
	.i c=nci"
sockopt[q_tru=%zu,key_tru=%zu__, vlan & ~(alg)6);

ofkey_idx)
socko
	.i cha
eq_trut(key_truccttl(drvalg =VER_FLALG_NONE_priDranPD
	struct i	== NUrams->
		wpaed(_is_ packet f
#else < 0)eaddr.sn 0;
	}
	/*r_gldel_keyistru)
_P_ALLkey_idxc (wplude <HOSTAPD */
}


stati 0;
	}
	/*r_gldel_keyistru)
);

ofkey_idxs_free(drv)fr, 0, swkof(ifr));
	owkdrv =tohs(hdralg_prinP_PAER_FLALG_WEP:f pak.ikvons(ETHIEEE*hd.h>CIPHER_WEP (wp
#endif P_PAER_FLALG_TKIP:f pak.ikvons(ETHIEEE*hd.h>CIPHER_TKIP (wp
#endif P_PAER_FLALG_CCMP:f pak.ikvons(ETHIEEE*hd.h>CIPHER_AES_CCM (wp
#endif 		wpa_printf(MSG_DEBUG, "Uoctl[SIOd touhertyperlg=nc__, vlan & ~(alge(s);;
	}

	if (bind(ak.ikvfr.ifr_fIEEE*hd.h>KEY_RECVv == NU
	.i c)f pak.ikvxffff;|=	 EEE*hd.h>KEY_XMITcttl(drvaams->
		wpa_printrv)fr, 0, ak.ikvmacr_be16if (ofIEEE*hd.h>

	if#endif pak.ik_keyi
#ifkey_idx {
		wpa_print(&ifr,sa_dak.ik_macr_be16);

ofIEEE*hd.h>

	if#endif p/*
soc* Deduce wh#elsedress /	void		orouh		   "key byf, ecking
soc* D" fnot a "
	yech).  Noti mosond at wesed *only	mark 	void	
soc* keys 		wpa_p; doiggerare l2_paouh		   "key y con no));.
soc*s_memcmpis_ packet f
#else < 0)eaddr.s_printfk.ikvxffff;|=	 EEE*hd.h>KEY_GRO{
 {
 pak.ik_keyi
#ifkey_idx {

			wpa_driverk.ik_keyi
#ifkey_idxlp=
0e?fIEEE*hd.h>KEYIX_NONE print	key_idx {

	wpa_driverk.ik_keyi
#!=fIEEE*hd.h>KEYIX_NONE && 
	.i c)f pak.ikvxffff;|=	 EEE*hd.h>KEY_DEFAULT;iDranPD
	struct iGLIBC__IEEE*hd.h>KEY_NOREPLAYwp/*
sc* Ignls.
replaysend:u{
		in IBSS backAHDEMO	mode.
	(drv->dhc
	os_op	   l==	 EEE*hd.h>M_IBSS wpa_driv
	os_op	   l==	 EEE*hd.h>M_AHDEMO)f pak.ikvxffff;|=	 EEE*hd.h>KEY_NOREPLAY iGHOSTAPD *IEEE*hd.h>KEY_NOREPLAYesoc<HOSTAPD */
}


stati rk.ik_keyeof(=
key_truv == NU
	q_priDraBC__WORDS_BIGENdr_Nf p/*
soc* rk.ik_keyrsc y cin ata ertypeorerms(big HOSTan), ne the 
soc* swap ite PAmas(hdnet80D" frtypeorerms_readin R_F.
soc*s_memx,
	 {

ddr,keyred Etmsg->chark.ik_keyrsc {

l2_p(is_mem i	wp
eq_trum i++sn 0;keyrsc[R_FLKEY_RSCf#en - i	- 1]rv->sq[i]* __linux__WORDS_BIGENdr_Nc*s_me(&ifr,sa_dark.ik_keyrscha
eqha
eq_tru /* __linux__WORDS_BIGENdr_Nc*s_mcpy(own_addr,rk.ik_keyhar ,nkeydakey_truccttl;
	if (seee8021var(st u8 IEEE*hd.h>DDR_R_FKEYt)0wkofr));
	owkdrv c vt wpa_driv
r_gld "
			  _w
{iv, struct wpa_driver_cabssparams)
{
	struct wDranPD
	IEEE*hd.h>DDR_APPIEwpa_t u8 pae_gr, sizecip
#ent us[1, 0		{ "WEP__,"TKIP__,"AES-OCB__,"AES-CCM__,"CKIP__,"NONE"uct emx,
vh (ntohs(hdrwn_addr)r_caress _prinP_PAER_FLCIPHER_CCMP:f pvETHIEEE*hd.h>CIPHER_AES_CCM (wp
#endif P_PAER_FLCIPHER_TKIP:f pvETHIEEE*hd.h>CIPHER_TKIP (wp
#endif P_PAER_FLCIPHER_WEP104:f pvETHIEEE*hd.h>CIPHER_WEP (wp
#endif P_PAER_FLCIPHER_WEP40:f pvETHIEEE*hd.h>CIPHER_WEP (wp
#endif P_PAER_FLCIPHER_NONE:f pvETHIEEE*hd.h>CIPHER_NONE;(wp
#endif 		wpa_printf(MSG_DEBUG, "U: FailethertypeOCDELMkey cip
#e %ustrerror(wn_addr)r_caress _(s);;
	}
	if (setsof(MSG_DEBUG, "%s: Enabled aOCDELMkey cip
#e=%"
	%  (unsi__);
	}

	i, cip
#ent us[v]8 vetsockopt(de8021d *prist u8 IEEE*hd.h>DDR_M",
	CIPHER8 ve_printf(MSG_INFO,
			   "Could not leave PAEnterOCDELMkey cip
#e PAE%u
	%s (unsignedv, cip
#ent us[v]_(s);;
	}
	if (setso> ROBl==	 EEE*hd.h>CIPHER_WEP_print/* keyint gt80y cdone*only	etectpecifu8 pip
#e);cludpvETHrwn_addr)r_caress  =VER_FLCIPHER_WEP104e?f13 : 5);_memcmpt(de8021d *prist u8 IEEE*hd.h>DDR_M",
	KEY#en8 ve_printtf(MSG_INFO,
			   "Couldd not leave PAEnterOCDELMkey nt gt80PAE%u"8 vetso);;
	}
	if (serv->fd =vs_memcpmcmpwn_addr)r_capairwiPAE&ER_FLCIPHER_CCMP)udpvE;
	i<<IEEE*hd.h>CIPHER_AES_CCM (wmcmpwn_addr)r_capairwiPAE&ER_FLCIPHER_TKIP)udpvE;
	i<<IEEE*hd.h>CIPHER_TKIP (wmcmpwn_addr)r_capairwiPAE&ER_FLCIPHER_NONE_udpvE;
	i<<IEEE*hd.h>CIPHER_NONE;(wf(MSG_DEBUG, "%s: Enabled apairwiPAEkey cip
#es=0x%x__, vlan & ~(1etsockopt(de8021d *prist u8 IEEE*hd.h>DDR_U",
	CIPHERS8 ve_printf(MSG_INFO,
			   "Could not leave PAEnterpairwiPAEkey cip
#es PAE0x%x__,ve(s);;
	}

	if (bind(a(MSG_INFO,
			s: Failed tokeyAmanageme
	stlgoret8ms=0x%x__nsi__);
	}

	i, wn_addr)r_cakey_mgmtetsockopt(de8021d *prist u8 IEEE*hd.h>DDR_KEYMGTALGSCould nwn_addr)r_cakey_mgmte_printf(MSG_INFO,
			   "Could not leave PAEnterkeyAmanageme
	stlgoret8ms PAE0x%x__rerror(wn_addr)r_cakey_mgmtetso;;
	}

	if (bind(vs_memcpmcmpwn_addr)rsnSG_eauth_udpvE;
	BIT(drv->a(MSG_INFO,
			s: Failed torsnia)
{bilities=0x%x__nsi__);
	}

	i, wn_addr)rsnSG_eauth_tsockopt(de8021d *prist u8 IEEE*hd.h>DDR_RSNCAPS8 ve_printf(MSG_INFO,
			   "Cot leave PAEnterRSNia)
{bilities PAE0x%x__rerror(ve(s);;
	}

	if (binGHOSTAPD *IEEE*hd.h>DDR_APPIEesockef(MSG_DEBUG, "%s: Enabled almulti"R_F= 0x%x__, vlan & ~(wn_addr)r_c_tsockopt(de8021d *prist u8 IEEE*hd.h>DDR_R_F~(wn_addr)r_c__printf(MSG_INFO,
			   "Cot leave PAEntericanPAE%u"8 wn_addr)r_c_tso1;
	}
	if (setso
}


static vt wpa_driv
r_glss(drdr *hd1xiv, struct wpa_driver_cabssparams)
{
	struct wef(MSG_DEBUG, "%s: Enabled almultid=nc__, vlan & ~(wn_addr)lmultidccttl(drv!wn_addr)lmultidcprint/* XXXiE stls.
 0)
eecludp;
	if (seee8021d *prist u8 IEEE*hd.h>DDR_AUTHMODE    pae_groIEEE*hd.h>
U
	}
UTO)(setso> RO!wn_addr)r_c && !wn_addr)1_defs.h"x_printf(MSG_ERROR, "ioctl[SIOd toNop(uns>X	oroicanlmultid__func__);
		while (wp;
	}
	if (setso> ROwn_addr)r_c && r_gld "
			  _w
{ist u8 
	struc		wpa_printf(MSG_ERROR, "ioctl(SIOd to set the id "
			  oican 0)
e__func__);
		while (wp;
	}
	if (setso> ROseee8021d *prist u8 IEEE*hd.h>DDR_AUTHMODE    Own_addr)r_c ?oIEEE*hd.h>
U
	}ican:oIEEE*hd.h>
U
	}*hd.X)__printf(MSG_INFO,
			octl(SIOd to set the ilmulti"R_F/(uns>X__func__);
		while (wp;
	}
	if (setso
	}
	/*r_glcr.i_la,
	ist u8 1rv c vt wpa_dv, s
r_glddr = miv, struct wp, unsigned c8fnot [IEEE*hd.h>

	if#en]ct wpa_drivehdr *hd11	in_f(Mie t8_t mx,
	e		os_memcpsg->iebuf = else {wp/*
sc* Fes(hdbackaddr )
eet frnegotia theR_F/RSNiwn_adet#es.
	(drv-fr, 0, si(if(mreq));
	i(ioctlm.ifr_hwe.f(MSmacr_be16);

ofIEEE*hd.h>

	if#endif > ROgeee8021var(st u8 IEEE*hd.h>DDR_R_FIEt)0iemreq));
	i(io	wpa_printf(MSG_INFO, "%s: Faiould not set the igterica/RSNiinetempletede		me
	urn NUgoto no_t8_t tso>ebuf = we.f(MSt8_t me		os_mwe.f(MSt8[ *ctxmcmpie		os_eturn 0iebuf = else {plude 	 me		os+= 2 {wno_t8:
t_eapol_rx(assoc pos,     c
{eof(bume		oLL0rtic vt wpa_driv
r_gll(void *priv, const u8 *addr,
			    c *data, size_t data_len, int encr
f_nametoit,
			    c *own_addr, u32 flags)
{
	struct wpa_driver_global {
har i*v =	struct ietf(MShexdumpUMP, "Got DHCP TXcket")"ata_len);

	res = send(}
	/*_data *l2;>sock, (u8 *) ixmitTH_ALEN);
	}P_ket")ata_len
 pae_grou;

	res = sc vt wpa_driv
r_glss(d 	iniv, struct wpa_driveata *hap 	inparams)
{ 	inct wpa_driver_global {
har i*v =	struct iGLIBC__ADDRS*hd11CHANNELwpa_drivehdr *hd11rom 	intc (socGHOSTAPD *ADDRS*hd11CHANNEL(drv-)
{
mode;k <ngr, snne		stfdre s, snne	cttl(drv, snne			wpa_print	   l=iGLIBC__CONFI%s:EEE*hd.hNf p	fdre sht_lmultid ?oIFMs:EEE*hd.h_.hNG :cGHOSTAPD *CONFI%s:EEE*hd.hNecludp_nametooIFMs:EEE*hd.h_.hG {
		wpa_p(drv, snne		_etpa_print	   l=oIFMs:EEE*hd.h_.hB {
		wpa_print	   l=iGLIBC__CONFI%s:EEE*hd.hNf p	fdre sht_lmultid ?oIFMs:EEE*hd.h_.hNA :cGHOSTAPD *CONFI%s:EEE*hd.hNecludp	IFMs:EEE*hd.h_.hA(setso> ROr_gls	.is#ifddhcpv =ofIFMsMMASK,	model	wpa_printf(MSG_ERROR, "ioctl[SIOd tofset the intermodulpleted	   __func__);
		while (wp;
	}
	if (setsiGLIBC__ADDRS*hd11CHANNELwprv)fr, 0, scizeof(mreq));
	creq.mr_iy(ifr.ifr_ncdresiv->ifname, sizeof(ifr.ifr_ncdresiv->if->flagdresiv, snne		st( flags;
	), snne	ctf;
	if (=>fd, SIOCS	void	 fCGIFHWADDRS*hd11CHANNELt)0creq.* __linux__ADDRS*hd11CHANNEL(drv-;
	if (seee8021d *prist u8 IEEE*hd.h>DDR_CHANNELt), snne	)ocGHOSTAPD *ADDRS*hd11CHANNEL(drvc vt wpa_driv
r_glss(ddhc_t8iv, const u8 *addr,
			iemreq))_vehd_truct wGLIBC__IEEE*hd.h>DDR_APPIEwpf(MSG_DEBUG, "%s: Enabled anterica+RSNiie4) {
		   (u, ifname);rerned long) len, strhd_truc;wp;
	if (r_glseee8021ist u8 IEEE*hd.h>DDR_APPIEofIEEE*hd.h>
PPIE_R_F~
 pae_griemrhd_truc;wGHOSTAPD *IEEE*hd.h>DDR_APPIEesoco
}


static vt wpa_deq))_v
rt_adr = iv, cct wpa;
	u8 *pos;;
	uns
ib[6]rv-{CTL__DGRAAF_ROUTEof(mrAOCK_DGRA_DG_RT_t DHCP0}etsockopt
#inc(
ib, 6)
_P_ALL&		oLL_P_ALL0r	wpa_printf(MSG_ERROR, "iWARNINnabledsend: %s"nc__, ifname);rerror(errno));
		return -1		os_m2048;udind(;
	if (eoftic vSTAPD
	struct i
 SupplAv, cod "
lictsdnet80ata *ha _Freei]; /*"bye terreeingod upti"o(__FreeBsupplCSTR,layer
 * heaerms;
	uinclude# terrrRSN_VERADDNe# terrrR_FLVERADDNe# terrrR_FLOUI_TYPEint wpa_driver_gls
	rdeauthiv, const u8 *addr,
			 u32 flags*addr,
			    const ui	len asonld del;int wpa_dpae_gr, size
#else sG_ERROR*addr)
{
	u16 _reada_wpa_dp000];
	sr.ifr_n	   MA)]cttl(drvaams-!	return NUsnG_ERRORof(buf), 0);
	if (	   MAC,ac_addreaddr.sll_lude 	 snG_ERRORof(buf), 0);
	if (	   MAC,0,0,0,0,0,0c;wp;
	if (raddrc vt wpa_driv
r_glss(dt flacyiv)
{
	stru)
{
	ilmultidct wef(MSG_DEBUG, "%s: Enabled almultid=nc__, vlan & ~(lmultidccttl;
	if (seee8021d *prist u8 IEEE*hd.h>DDR_PRIVACY~(lmultidcctc vt wpa_driv
r_gl
	.i eqnumir *ifname, const u8 v)
{
	stru)
*addr,
			    c
{
	iidx)
snametooddr,
eqct wpa_drivehdr *hd11	in_key wk

kef(MSG_DEBUG, "%s: Enabled arams=%s idx=nc__nsi__);
	}

	i, #else sG_ERRORaddr., idxs_fv-fr, 0, swkof(ifr));
	owkdrv == NUrams->
		wpa_int	r, 0, ak.ikvmacr_be16if (ofIEEE*hd.h>

	if#endif lude 	 fr,sa_dak.ik_macr_be16);

ofIEEE*hd.h>

	if#endif rk.ik_keyi
#ifidx {f > ROgeee8021var(st u8 IEEE*hd.h>DDR_R_FKEYt)0wkofr));
	owkdr	wpa_printf(MSG_INFO, "%s: Faile set the igter			    ; /urn -1;
	}

	os_memseDraBC__WORDS_BIGENdr_Nf {f p/*
soc* rk.ik_keytsc y cin ata ertypeorerms(big HOSTan), ne the 
soc* swap ite PAmas(hdnet80D" frtypeorerms_readin R_F.
soc*s_memx,
	 {

ddrtmp[R_FLKEY_RSCf#en*ctx fr,sa_dtmp,hark.ik_keytscha
));
	owk.ik_keytscurn -1l2_p(is_mem i	wpR_FLKEY_RSCf#enm i++sprintt>sq[i]s_mtmp[R_FLKEY_RSCf#en - i	- 1](serv->fd__linux__WORDS_BIGENdr_Nc*s_mp->sa_dazeofark.ik_keytscha
));
	owk.ik_keytscurn  __linux__WORDS_BIGENdr_Nc*s_m
}


static int wpa_drive
r_glflushiv)
{
	struct wpc8fnllt w[IEEE*hd.h>

	if#en]_fv-fr, 0, nllt w16if (ofIEEE*hd.h>

	if#endif ;
	if (r_gls
	rdeauthistru)
_P_ALLnllt w16IEEE*hd.h>REASON>
U
	}LEAVE)tic int wpa_driv
r_gl(drv->talobal {
har iv, struct wpa_driveata *h->talobal {
har ize_t donst *addr)
{
	u16 _reada_drivehdr *hd11	inl>talt wpsn 0)
s_fv-fr,sa_da0)
s.is_u.macr_be16);

ofIEEE*hd.h>

	if#endif > ROgeee8021var(st u8 IEEE*hd.h>DDR_ruc_rucTS) == 0 sha
));
	o= 0 s.sn etoo>pa_print/* XXX? doocket fsod und);l2_packenon-har if_ades? |= 1	har ->rx_cket fso= a0)
s.is_a0)
s.ns_rx_har ; 1	har ->rx_rtypso= a0)
s.is_a0)
s.ns_rx_rtyps; 1	har ->tx_cket fso= a0)
s.is_a0)
s.ns_tx_har ; 1	har ->tx_rtypso= a0)
s.is_a0)
s.ns_tx_rtyps; 1tso
}


static vt wpa_driv
r_gls
	rdeauthiv, const u8 *addr,
			 u32 flags*addr,
			    cui	len asonld delt wp;
	if (r_glsend_mlmeparamsist u8 IEEE*hd.h>MLME%s:
U
	,en asonld de    pae_gsap->sac vt wpa_driv
r_gls
	rdisassoc v, const u8 *addr,
			 u32 flags*addr,
			    consui	len asonld delt wp;
	if (r_glsend_mlmeparamsist u8 IEEE*hd.h>MLME%sISASSOC,en asonld de    pae_gsap->sac vt wpa_dv, s
r_glnit,	uispol_rx(receal ({
	i
GIFHW, unsigned , unsi *) ict ct wpa_driver_global {
	void		*	void		st *) ict ;ieee8023_r_global {
har i*v = oeee8023_h _snn uncr, g
	sizifa os_cp_messr.is g
	sizrtm;ieee8023_hdr *hd.h>miameelpol_rx *mia;ieee8023_hdr *hd.h>joinpol_rx *join;ieee8023_hdr *hd.h>leavepol_rx *leave;k <ngros;
	nBSD n(MSol_rx(har ihar ; 
	nock, ad(
GIFHW	void	 f_sta.n_adHW	void	 f_sta.n_ad_truc;wp> ROn	wpa_print(drvl	ret-!	rEINTR && l	ret-!	rEAGAInd -1tf(MSG_ERROR, "ioctl[SIOd k, ad()send: %s"nc__   pae_g;
	}

	i, errno));
		close(s);;
	}

;udind(;tmt sockaddr r.is g
	siz)W	void	 f_sta.n_ad;wp> RO;tm->rtm_er_bBSD !	rRTMLVERADDN_printf(MSG_INFO,
			s: FaileW-addr f;#ifink dessage er_bBSD=nc__nsiae_g;tm->rtm_er_bBSDe(s);;
	}

;udinntohs(hdr;tm->rtm_ons(_prinP_PAERTMLIEEE*hd.h:int(dant sockaddr h _snn uncr, g
	siz) rtm;ie_zallocr_gl
	.i
co->ifna	void	 sizan fla,n_	if (binp < '0me,->
		wpa_int;;
	}

;udntohs(hdrizan fla,n_what(*sep P_PAERTMLIEEE*hd.h_ASSOC:ep P_PAERTMLIEEE*hd.h_REASSOC:ep P_PAERTMLIEEE*hd.h_sISASSOC:ep P_PAERTMLIEEE*hd.h_SCANprint
#endif  P_PAERTMLIEEE*hd.h_LEAVEprintleavet sockaddr hdr *hd.h>leavepol_rx * 0) {an[ *ctx	t_eapol_rx(disassoc SIOCS	     leaver)1_v_sap->sa_ft
#endif  P_PAERTMLIEEE*hd.h_JOINprDraBC__RTMLIEEE*hd.h_REJOINep P_PAERTMLIEEE*hd.h_REJOINprD__lini_ftjoint sockaddr hdr *hd.h>joinpol_rx * 0) {an[ *ctx	tr_glddr = miv =ofSIOCS	     joinr)1_v_sap->sa_ft
#endif  P_PAERTMLIEEE*hd.h_REPLAYprint#in gnls.
cludp	
#endif  P_PAERTMLIEEE*hd.h_MICHAELprintmiat sockaddr hdr *hd.h>miameelpol_rx * 0) {an[ *ctx	tf(MSG_INFO,
			s: Fai   pa"Miameel MICsend:u{
 nit,	uisp
#end:tgroup	"keyi
=%u src_rams=
		   MAC,miar)1_v_keyi
i   paac_addremiar)1_v_srcse(s);prv)fr, 0, sa_len)(ifr));
	oif (drv =1	har .miameelpmia_end:u{
.uh		   "if def1	har .miameelpmia_end:u{
.srcdresiar)1_v_srcctx	tf(MSt_8_N_7.x_r
#end SIOCS	    
	  pae_groEVENT_MICHAEL_MIC_FAILUREt)0if (dsa_ft
#endif  innt
#endif }ac vt wpa_dv, s
cp, drv, ad(, const char *ifnddr,
rc_ramshar *ifnddr,of(buf), _	int i;

	a_driver_global {
har i*v =	stct ;ie_eapol_rx(d *pr_rx SIOCS	     
rc_ramshaof(bues = sc vt wpa_d, cons
r_glct hostapd_data *hapd,
				    pa_init_params *params)
{
	struct wpa_driver_global {
har i*v = os_zalloc(sizeof(struct wpa_driver_global {
har drv == NULL) {
		wpa_printf(MSG_INFO,
			octl[SIO allocate memory for wired drir_gata");
		return NULL;
	}

	drv->ctx = hapla;
		dlpoindex(drv->ifnafname, sizeof(rv == NULL) fla;
		dlp=
0_printf(MSG_INFO,
			s: Failed to name %s",% cdopsoate exinc__
 pae_g;
	}

	i, fname, sizeof(rv =Ugoto badv->ctx = hap	   	os_strlcpSIOCS	void	->use_pae_g	void	_ruct iey(drv->ifname, params->ifname, sizeof(drv->ifname));
	drv->usecpSIOCS *) ixmit->u_data *l2;ct home, params->i_P_ALL;
	}P_ket")a
	  pacp, drv, adofSIO (drv->pf_sock < *) ixmit->
		wpa_intgoto badv->pf_s_data *l2;
	.i u32 flak, (u8 *) ixmitTHwn_addr)) {
		os_fintgoto badv-rt PAmark 	    durink= L;
p(drv->dhcr_glcr.i_la,
	iSIO (dreturn -1goto badv-rt> ROr_gls	.is#ifddhcpv =ofIFMsOMASK,	IFMs:EEE*hd.h_structl	wpa_printf(MSG_ERROR, "ioctl[SIOd tofset the inter completed	   __func__);
		while (wpgoto badv->ctx =l_cket_		o saIOCS	void	 fla,
	s, saIOCScket(cttl;
	if (v = obad:->pf_sock < *) ixmit-!	return NU_data *l2;
ect home, p *) ixmitmr_iy(i;
		return N
#else else {}__vt wpa_dv, s
r_glid *priv)
{
	struct wpa_driver_global {
har i*v =	struct iet= NULL) fla;
		dl!eturn 0r_glcr.i_la,
	iSIO (drv->pf_sock < *) ixmit-!	return NU_data *l2;
ect home, p *) ixmitmr_iy(i;
		return c int wpa_driv
r_gl

#ipriv)
{
	struct wp
	}
	/*r_glcr.i_la,
	ist u8 1rv c vvt wpa_driv
r_gls	.i 
	rauthor->iriv, u8 *ssid)*src_addr, ETH_ALEN)metoodong) lenex,
totd	_	struid)ong) lenex,
	stru_oH_ALEN)metoodong) lenex,
	stru_p, len;
	unsauthor->irndif /*rt PAFdrinow,*only	t_8_roups	.fink Author->irn	str(drv->dhc	stru_oHE&ER_FLruc_
U
	ORIZEDn NUauthor->irndi1v->pf_s IFF_UP_p, E&ER_FLruc_
U
	ORIZEDnn NUauthor->irndi0cttl(drvauthor->irnturn -1;
	if (0cttl;
	if (r_glsend_mlmeparamsist u8 author->irn?   pae_gIEEE*hd.h>MLME%
U
	ORIZE print	e_gIEEE*hd.h>MLME%UN
U
	ORIZEha0hatap->sac __linux__/
}


statint wpa_driv
geee8021d *pria_driver_global {
har i*v =ofex,
opct wpa_drivehdr *hd11	int  (sock < 0)r_glgeee8021ims->o&iizeofopha_P_ALL0r	wpa_
-1;
	if (!(rea;
	if (=dresiv (iocc vt wpa_driv
r_capa *capr_gl
	.id *priv, u8 *bssid)
{
	/* Reporta_driver_global {
har i*v =	struct iGLIBC__ADDRG*hd11r wirieee8023_hdr *hd.h>pa_dribs

et(&irv->ifnabssiv->ifname, sizeof(ifr.ifr_nbssiv->ifdrv == NU->fd, SIOCS	void	 fCGIFHWADDRG*hd11B wirif&bsr	wpa_
-1;
	if (!(rea(bssid, pae_groupbssive_groupr.ifr_nbssiv	/* Rern N
#else 0* __lin0;
}


stgeee8021var(v =ofIEEE*hd.h>DDR_B wirin 0r_sid)
IEEE*hd.h>

	if#end	wpa ?(!( : 0* ___linic vt wpa_driv
r_capa *capr_gl
	.i *priv, u8 *ssid)
{
	ssid[0] = _driver_global {
har i*v =	struct ie;
	if (r_gl
	.i *priv =of_sid)
0rtic vt wpa_driv
r_capa *capr_gls	.if(MSt8ia_driver_global {
har i*v =of*src_addr,f(MSt8_func__f), _	if(MSt8_truct wGLIBC__IEEE*hd.h>DDR_APPIEwp;
	if (r_glseeddhc_t8iv =off(MSt8_if(MSt8_truc* __linux__IEEE*hd.h>DDR_APPIEesoco
}


stseee8021var(v =ofIEEE*hd.h>DDR_OPTIEoff(MSt8_if(MSt8_truc* __OSTAPD *IEEE*hd.h>DDR_APPIEesocc vt wpa_driv
r_capa *capr_gls	.if(MStnamenaliv)
{
	stru)
{
	iwzeof{
	it flacylen;
	uns
}
ndi0cttlf(MSG_DEBUG, "%s: waiting fopa=ncit flacy=nc__nsi;
	}

	i, wzeoft flacylcttl(drv!r_c && r_capa *capr_gls	.if(MSt8istru)
_P_ALL0r	wpa_
-1;
	ndif /*o> ROseee8021d *prist u8 IEEE*hd.h>DDR_PRIVACY~(t flacyl	wpa_
-1;
	ndif /*o> ROseee8021d *prist u8 IEEE*hd.h>DDR_R_F~(r_c_	wpa_
-1;
	ndif /*co
}


st
}
tic vt wpa_driv
r_capa *capr_gls	.if(Miv)
{
	stru)
{
	ilmultidct wef(MSG_DEBUG, "%s: Enabled almultid=nc__, vlan & ~(lmultidccttl;
	if (r_capa *capr_gls	.if(MStnamenalistru)
e;ultid ?o3 : 0~(lmultidcctc vt wpa_driv
r_capa *capr_gls	.id undermeasu{
	iv)
{
	stru)
{
	ilmultidct wef(MSG_DEBUG, "%s: Enabled almultid=nc__, vlan & ~(lmultidcct-;
	if (seee8021d *prist u8 IEEE*hd.h>DDR_COUNTERMEASURES~(lmultidcctc vvt wpa_driv
r_capa *capr_gls	.idrop_un			    iriv, u8 *ssid){
	ilmultidct wef(MSG_DEBUG, "%s: Enabled almultid=nc__, vlan & ~(lmultidcct-;
	if (seee8021d *prist u8 IEEE*hd.h>DDR_DROPUNENCRYPTED~(lmultidcctc vt wpa_driv
r_capa *capr_gldeauthen			 t8iv, const u8 *addr,
			    cui	len asonld delt wp;
	if (r_glsend_mlmeparamsist u8 IEEE*hd.h>MLME%s:
U
	,en asonld de    pae_gsap->sac vt wpa_driv
r_capa *capr_gls	.iauthSalgiv, u8 *ssid){
	iauthSalglen;
	unsauthmode;k*o> RO(authSalgE&ER_FL
U
	}
LG_OPend	flags & IauthSalgE&ER_FL
U
	}
LG_SHAREDnn NUauth	   l=oIEEE*hd.h>
U
	}
UTOif lude (drvauthSalgE&ER_FL
U
	}
LG_SHAREDn NUauth	   l=oIEEE*hd.h>
U
	}SHAREDif lude 	 auth	   l=oIEEE*hd.h>
U
	}OPencttl;
	if (seee8021d *prist u8 IEEE*hd.h>DDR_AUTHMODE sauthmode>sac vt wpa_dv, s
cp, drv, ad(, const char *ifnddr,
rc_ramshar *ifnddr,of(buf), _	int i;

	a_driver_global {
har i*v =	stct ;iie_eapol_rx(d *pr_rx SIOCSt cha
rc_ramshaof(bues = sc vt wpa_driv
r_capa *capr_glassoci t8iv, const u8 _packetr_capa *capassoci t8params)
{
	struct wpa_driver_global {
har i*v =	struct ieee8023_hdr *hd11	inlmlme mlmems-)
{
mode;k <ngrt flacy;;
	uns
}
ndi0cttlf(MSG_DEBUG, "%s: wai 	 led an_dri'%.*s'nw
{=ie  {
		urpairwiPAE	urOCDELM%urkeyAmgmtE%u" 	 _, vlan & ALEN)m,d long) lenDEB)Hwn_addr)
sid_tru,Hwn_addr)
sid 	 _, long) lenDEB)Hwn_addr)f(MSt8_tru 	 _,wn_addr)pairwiPA_suite 	 _,wn_addr)r, 0) suite 	 _,wn_addr)key_mgmt suite 	)h (ntohs(hdrwn_addr)model	rinP_PAEIEEE*hd.h>MODEs: FRA:int	   l=o0PD *ATAeso;
wp
#endif P_PAEIEEE*hd.h>MODEs:B w:int	   l=oIFMs:EEE*hd.h_:B w;
wp
#endif P_PAEIEEE*hd.h>MODEsAP:int	   l=oIFMs:EEE*hd.h_/
}


;
wp
#endif 		wpa_printf(MSG_DEBUG, "Uoctl[SIOd touhertype completed	   __);
		while (wp;
	}
	if (setso> ROr_gls	.is#ifddhcpv =ofIFMsOMASK,	model	wpa_printf(MSG_ERROR, "ioctl[SIOd tofset the inter completed	   __func__);
		while (wp;
	}

	if (bind(> ROwn_addr)	   l==	 EEE*hd.h>MODEsAP->iff_up =  *) ixmit->u_data *l2;ct home, params->i_P_ALL;
	}P_ket")a
	  paacp, drv, adofSIO (drv->>pf_sock < *) ixmit->
		wpa_int;;
	}
	if (serme, pas_ap"if def1
	}
	/*emcpired_mult_capa *capr_gls	.idrop_un			    iriSIO (wn_addr)drop_un			    irsn etoowpa_
-1;
	ndif /*o> ROr_capa *capr_gls	.iauthSalgiSIO (wn_addr)authSalglowpa_
-1;
	ndif /*o/* XXXino)); cp, dink is wronk bur)
hclear whatle alo...(drv->dhcr_capa *capr_gls	.if(MSt8iSIO (wn_addr)f(MSt8_iwn_addr)f(MSt8_trur	wpa_
-1;
	if (!(re
	t flacyndi!(wn_addr)pairwiPA_suite =VER_FLCIPHER_NONE &&n etoown_addr)r, 0) suite =VER_FLCIPHER_NONE &&n etoown_addr)key_mgmt suite =VER_FLKEY_MGMT_NONE &&n etoown_addr)f(MSt8_trulp=
0_;wpf(MSG_DEBUG, "%s: Enabled anterPRIVACYE%u"8 ;
	}

	i, f flacylcttl(drvseee8021d *priv =ofIEEE*hd.h>DDR_PRIVACY~(t flacyl	wpa_
-1;
	if (!(re
	mcmpwn_addr)r_cat8_trul&&n etooseee8021d *priv =ofIEEE*hd.h>DDR_R_F~
 pae_wn_addr)r_cat8[0] =VERLAN_EID_RSN ?o2 : 1l	wpa_
-1;
	if (!(re
	(&mreq, 0, slf(if(mreq));
	ml (ioctlml (.im_opETHIEEE*hd.h>MLME%
SSOC;
	mcmpwn_addr)n_dri!	return NU(sap->sa_dml (.im__sid)
wn_addr)n_dr,Hwn_addr)
sid_truoctlml (.im_
sid_tru->use_pae_g
sid_tru;etmcmpwn_addr)bn_dri!	return NU(sap->sa_dml (.im_macr_be16wn_addr)bn_drofIEEE*hd.h>

	if#endif > ROseee8021var(v =ofIEEE*hd.h>DDR_MLMEt)0slf(ifeq));
	ml (io	wpa_
-1;
	if (!(rea;
	if (
}
tic vt wpa_driv
r_capa *capr_glscaniv, const u8 _packetr_capa *capscanparams)
{
	struct wpa_driver_global {
har i*v =	struct iGLIBC__IEEE*hd.h>DDR_SCAN_MAX_ wirieee8023_hdr *hd.h>scanp	intsr;;
	unsi* __OSTAPD *IEEE*hd.h>DDR_SCAN_MAX_ wiresocke> ROr_gls	.is#ifddhcpv =ofIFMsOMASK,	0PD *ATAesol	wpa_printf(MSG_ERROR, "ioctl[SIOd tofset the inter completed	   __func__);
		while (wp;
	}

	if (bind(> ROseee8021d *priv =ofIEEE*hd.h>DDR_ROAMINnafunc__IEEE*hd.h_ROAMINn_MANUALl	wpa_printf(MSG_ERROR, "ioctl[SIOd tofset the intergroup (SIf(MSt_8_N_7.x_-baread;#aminks"nc__, ifname);rerror(errno));
		return -1;
	}

	if (bind(> ROr_capa *capr_gls	.if(Miv =of1l	wpa_printf(MSG_ERROR, "ioctl[SIOd tofset the interf(Ms"nc__, ifname);rerror(errno));
		return -1;
	}

	if (bind(D *NBto name %s",mua ereAmark thUPle alo a scan(drv->dhcr_glcr.i_la,
	iSIO (1l	wpa_
-1;
	if (!(re
GLIBC__IEEE*hd.h>DDR_SCAN_MAX_ wirie(&mreq, 0, seof(ifr));
	osr.sll_sr.srvfr.ifr_fIEEE*hd.h>DDR_SCAN_ACTIVELMULEEE*hd.h>DDR_SCAN_ONCELM
-1LEEE*hd.h>DDR_SCAN_NOJOINll_sr.srvdumpleted_fIEEE*hd.h>DDR_SCAN_FOREVER;etmcmpwn_addr)num_
sidso>pa_printsr.srvna_drivewn_addr)num_
sids iGLI 0
nt#inBoundaryf, eck0y cdone*bye pcom Copyrc*s_memcmpsr.srvna_dri>_IEEE*hd.h>DDR_SCAN_MAX_ wirp(1);
r.srvna_driveIEEE*hd.h>DDR_SCAN_MAX_ wir* ___lini
nt#inNBto, eck0scan(ca, e firsriclud_sr.srvfr.ifr|veIEEE*hd.h>DDR_SCAN_CHECK(setsol2_p(is_mem i	wp
r.srvna_drm i++sprint
r.srva_dr[i].tru->use_pae_g
sids[i].
sid_tru;eta(sap->sa_dar.srva_dr[i].n_dr,Hwn_addr)
sids[i].
sid_func__fr.srva_dr[i].tru) (bind(D *NBtolayer
 * delver_b a scan(complete ol_rx so no ne the  *prlesoco
}


stseee8021var(v =ofIEEE*hd.h>DDR_SCAN_REQ) ==rifr));
	osr.sll__linux__IEEE*hd.h>DDR_SCAN_MAX_ wiresoc
#inc",
	esinet a_dribefls.
 can(drv->dhcr_gls	.i *priv =ofwn_addr)
sids[0].
sid_func_wn_addr)
sids[0].
sid_trur	wpa_
-1;
	if (!(re
	D *NBtolayer
 * delver_b a scan(complete ol_rx so no ne the  *prlesoco
}


stseee8021d *priv =ofIEEE*hd.h>DDR_SCAN_REQ) 0c* __OSTAPD *IEEE*hd.h>DDR_SCAN_MAX_ wiresocc vt wpa_dv, s
r_capa *capr_glol_rx(receal ({
	i
GIFHW, unsigned , unsi *) ict ct wpa_driver_global {
	void		*	void		st *) ict ;ieee8023_r_global {
har i*v = oeee8023_h _snn uncr, g
	sizifa os_cp_messrv

 g
	sizifm;ieee8023_r.is g
	sizrtm;ie	nBSD n(MSol_rx(har iol_rx ieee8023_hdr *hd11>miameelpol_rx *mia;ieee8023_hdr *hd.h>leavepol_rx *leave;k ee8023_hdr *hd.h>joinpol_rx *join;ie<ngros;
	nock, ad(
GIFHW	void	 f_sta.n_adHW	void	 f_sta.n_ad_truc;wp> ROn	wpa_print(drvl	ret-!	rEINTR && l	ret-!	rEAGAInd -1tf(MSG_ERROR, "ioctl[SIOd k, ad()send: %s"nc__   pae_g;
	}

	i, errno));
		close(s);;
	}

;udind(;tmt sockaddr r.is g
	siz)W	void	 f_sta.n_ad;wp> RO;tm->rtm_er_bBSD !	rRTMLVERADDN_printf(MSG_INFO,
			s: FaileW-addr f;#ifink dessage er_bBSD=nc__nsiae_g;tm->rtm_er_bBSDe(s);;
	}

;udinn(&mreq, 0, _sta.of(ifr));
	o_sta.drv =tohs(hdr;tm->rtm_ons(_prinP_PAERTMLIFANNOUNCE:int(dant sockaddr h _snn uncr, g
	siz) rtm;ie_tohs(hdrizan fla,n_what(*sep P_PAEIFAN	s:PARTUREprintzallocr_gl
	.i
co->ifna	void	 sizan fla,n_	if (binp >pf_sockd -1t = hapla
E multd"if def1	_sta.. name %s"_a0)
us.iol_rx =oEVENT_INTERFACE_REMOVEDif p	
#endif  P_PAEIFAN	ARRIVALprintzallocr_gl
	.i
co *pri	void	 sizan fla,n_eof(rv =U>pf_sockdprintt = hapla;
		dlpoinan fla,n_	if (; -1t = hapla
E multd"ifemcpy innt	_sta.. name %s"_a0)
us.iol_rx =oEVENT_INTERFACE_

	EDif p	
#endif  		wpa_printtf(MSG_INFO,
			s: FaileRTMLIFANNOUNCE:ouhertyperc ; /urn -1;;
	}

;udn}intf(MSG_INFO,
			s: FaileRTMLIFANNOUNCE:oIname %s",'%s'   strerror(izan fla,n_eof(trerror(izan fla,n_whatl==	 FAN	s:PARTUREn?   pa"E multd" : "r_btd");eta(sarv->ifna_sta.. name %s"_a0)
us.iname, sizan fla,n_eof(trerror(r));
	o_sta.. name %s"_a0)
us.iname,)rv->>pf_sock_printtf(MSt_8_N_7.x_r
#end SIOCSgned EVENT_INTERFACE_rucTUS 
	  pae_gro _sta.rn -1;/*
so	ADME ,
				   he  zero afe sesendiggerae ol_rx SSID" 
so	ADMol_rx m2004,queryfrae ta");
	e ilmsu{
 a mas(h.
so	AD/ =U>pf_sizan fla,n_whatl==	 FAN	s:PARTURE)intt = hapla;
		dlpoemcpy			wpa_driver(MSt_8_N_7.x_r
#end
	void	(	void	 fgned
	  paa_groEVENT_INTERFACE_rucTUS 
	  pa	_gro _sta.rn -1innt
#endif P_PAERTMLIEEE*hd.h:int(dant sockaddr h _snn uncr, g
	siz) rtm;ie_zallocr_gl
	.i
co->ifna	void	 sizan fla,n_	if (binp < '0me,->
		wpa_int;;
	}

;udntohs(hdrizan fla,n_what(*sep P_PAERTMLIEEE*hd.h_ASSOC:ep P_PAERTMLIEEE*hd.h_REASSOC:ep t= NULL) fls_ap)intt 
#endif  tf(MSt_8_N_7.x_r
#end SIOCSgned EVENT_ASSOC,e	wpa_if p	
#endif  P_PAERTMLIEEE*hd.h_sISASSOC:ep t= NULL) fls_ap)intt 
#endif  tf(MSt_8_N_7.x_r
#end SIOCSgned EVENT_sISASSOC,e	wpa_if p	
#endif  P_PAERTMLIEEE*hd.h_SCANprint= NULL) fls_ap)intt 
#endif  tf(MSt_8_N_7.x_r
#end SIOCSgned EVENT_SCAN_RESULTS 
	  pae_gro	wpa_if p	
#endif  P_PAERTMLIEEE*hd.h_LEAVEprintleavet sockaddr hdr *hd.h>leavepol_rx * 0) {an[ *ctx	t_eapol_rx(disassoc SIOCSgned leaver)1_v_sap->sa_ft
#endif  P_PAERTMLIEEE*hd.h_JOINprDraBC__RTMLIEEE*hd.h_REJOINep P_PAERTMLIEEE*hd.h_REJOINprD__lini_ftjoint sockaddr hdr *hd.h>joinpol_rx * 0) {an[ *ctx	tr_glddr = miv =ofSIOCSgned joinr)1_v_sap->sa_ft
#endif  P_PAERTMLIEEE*hd.h_REPLAYprint#in gnls.
cludp	
#endif  P_PAERTMLIEEE*hd.h_MICHAELprintmiat sockaddr hdr *hd.h>miameelpol_rx * 0) {an[ *ctx	tf(MSG_INFO,
			s: Fai   pa"Miameel MICsend:u{
 nit,	uisp
#end:tgroup	"keyi
=%u src_rams=
		   MAC,miar)1_v_keyi
i   paac_addremiar)1_v_srcse(s
);prv)fr, 0, s_sta.of(ifr));
	o_sta.drv =t	_sta..miameelpmia_end:u{
.uh		   "i   pa!IEEE*hd.h>DS_MULTI",
	emiar)1_v_ds.rn -1;f(MSt_8_N_7.x_r
#end SIOCSgned
	  pae_groEVENT_MICHAEL_MIC_FAILUREt)0_sta.rn -1;
#endif  innt
#endif P_PAERTMLIF: Fa:int(dmt sockaddr h _, g
	siz) rtm;ie_zallocr_gl
	.i
co->ifna	void	 sizm flam_	if (binp < '0me,->
		wpa_int;;
	}

;udn> RO(izm flam_xffff;
	 0) {
	lp=
0e&&n gs & I
	os_fr.ifr
	 0) {
	l	wpa_printtf(MSG_INFO,
			s: FaileRTMLIF: Fa:oIname %s",'%s' DOWN__   pae_gme));
	drv->if  tf(MSt_8_N_7.x_r
#end SIOCSgned EVENT_INTERFACE_sISABLED 
	  pae_gro	wpa_if p		wpa_p(drv(izm flam_xffff;
	 0) {
	l!=
0e&&n gs & I
	os_fr.ifr
	 0) {
	l=wpa_printtf(MSG_INFO,
			s: FaileRTMLIF: Fa:oIname %s",'%s' UP__   pae_gme));
	drv->if  tf(MSt_8_N_7.x_r
#end SIOCSgned EVENT_INTERFACE_ENABLED 
	  pae_gro	wpa_if p	
	(
	os_fr.ifr_flam flam_xffff;
wp
#endif }ac vt wpa_dv, s
r_capa *capr_gladglscan_endry(_packetr_cascanp	isa_psizresn
 pae_groua_drivehdr *hd11	inl>canp	isa_pr,
rct wpa_driver_cascanp	isizresa_p, **tm8_t f), _	iextra_tru;etddr,pos

etextra_trus_m2 + sr flsr_
sid_tru;etextra_trus+_m2 + sr flsr_nrayps; 1extra_trus+_m3;PD *ERP IEesocoextra_trus+_msr flsr_t8_tructtl;
sa_proc(sizeof(struct wpzresa_p) + extra_truc;wp> RO;
sa_pro
		wpa_int;
	}

;ud(sap->sa_d;
sa_pr)bn_drofsr flsr_bn_drofE
	}
Lendif ;
sa_pr) 	int_msr flsr_f (soc ;
sa_pr)beacon_	itt_msr flsr_	it (ioc ;
sa_pr)capst_msr flsr_capinetoc ;
sa_pr)qud		st r flsr_rn_doc ;
sa_pr)noiPAEst r flsr_noiPA;wp/*
sc* rae rn_dkaddu.
repor thebyfrae kerne		y cin 0.5dBua_ep k, lplevehe 
sc* rae repor thenoiPAEfloor.esee_hdr *hd.h>
ode.hd dridetnd:s.
	(drv-;
sa_pr)l
#e		st r flsr_rn_d /m2 + sr flsr_noiPA;w
	pos Etmsg->cO;
sa_pr+ 1rv 
	,pos++ VERLAN_EID_ wir* 	,pos++ VEsr flsr_
sid_tru;et(sap->sa_dposofsrr+ 1,Esr flsr_
sid_trudif pos +VEsr flsr_
sid_tru;ewp/*
sc* Ded		eof rayps SSIt_8_rouead;ayp.
	(d BecauPAElayer
 * doesn't repor  ext__let a_8_rouead;ayp drinot.
	(drv-,pos++ VERLAN_EID_ UPP_RATES* 	,pos++ VEsr flsr_nrayps; 1(sap->sa_dposofsr flsr_rayps,Esr flsr_nraypsdif pos +VEsr flsr_nrayps; v-,pos++ VERLAN_EID_ERPs: Fa* 	,pos++ VE1* 	,pos++ VEsr flsr_erpre
GLI__FreeBd(__DragonFly__)ed(__FreeBd(__FreeBSD__)ed(__FreeBd(__FreeBSD_kerne	__) 1(sap->sa_dposofmsg->cOsrr+ 1) + sr flsr_
sid_tru + sr flsr_meshid_tru,
nc__fr flsr_t8_tru)* __lin0;(sap->sa_dposofmsg->cOsrr+ 1) + sr flsr_
sid_tru,_fr flsr_t8_tru)* ___lini_pos +VEsr flsr_t8_tructtl;
sa_pr)1__tru->usos -tmsg->cO;
sa_pr+ 1rv 
	tm8roc(si#enof(s_arra_d;
s->resn ;
s->;
	m+ 1,
 pae_grou ruct wpa_driver_cascanp	isizdrv == NUtm8ro
		wpa_printrv);
		rresa_p)(s);;
	}

;udinntmp[;
s->;
	++]ock, sa_poc ;
s->ress_mtmptic vt acketr_cascanp	isa_psiz
r_capa *capr_gl
	.i canp	isa_ps2iv)
{
	struct wpa_drivehdr *hd11	inl>canp	isa_pr,
r;wpa_driver_cascanp	isa_psizres;ie<ngrtru,_E st;etdiions[];
	s24*1024],r,pos

ettru->ugeee8021var(st u8 IEEE*hd.h>DDR_rCAN_RESULTS aof(bu24*1024rv == NUtru-wpa_
-1;
	if (else {wpress_m(sizeof(struct wpzres)c;wp> RO;
sro
		wpa_int;
	}

(else {wppos Et_ad;wpE st->u_ru;etwhileRO;
st >= ruct wpa_drivehdr *hd11	inl>canp	isa_p)sprint
rt sockaddr hdr *hd.h	inl>canp	isa_pr,)pos

 tf(MSpa *capr_gladglscan_endry(rps,Esr)(s);pos +VEsr flsr_tru;eta;
st -VEsr flsr_tru;etind(a(MSG_INFO,
			s: FaileReceal d %d rtypsoof scan(	isa_psi(%lu BSSes (unsi__)tru,_ long) len, str;
s->;
	)/*co
}


st
}stic vt wpa_driv(r_capa *capr_gla)
{ia_driver_global {
har i*v =ct wGLIBC__IEEE*hd.h>DDR_DEVCAPS
/* kerne		_Freei]; /*"copiirn	STR,layer
 */hdr *hd.h>var.hdude#_FreeB	 EEE*hd.h>CIPHER_WEP            0e#_FreeB	 EEE*hd.h>CIPHER_TKIP           1e#_FreeB	 EEE*hd.h>CIPHER_AES_CCM        3e#_FreeB	 EEE*hd.h>CRYPTO_WEP            (i<<IEEE*hd.h>CIPHER_WEP_e#_FreeB	 EEE*hd.h>CRYPTO_TKIP           (i<<IEEE*hd.h>CIPHER_TKIP)u#_FreeB	 EEE*hd.h>CRYPTO_AES_CCM        (i<<IEEE*hd.h>CIPHER_AES_CCM)u#_FreeB	 EEE*hd.h>C_/
}


      0x00000400      D *CAPABILITY:_/
}


 avnd:dude#_FreeB	 EEE*hd.h>C_R_F1        0x00800000      D *CAPABILITY:_R_F1 avnd:dude#_FreeB	 EEE*hd.h>C_R_F2        0x01000000      D *CAPABILITY:_R_F2 avnd:dude ee8023_hdr *hd.h>devcapsp	intdevcaps {f > ROgeee8021var(v =ofIEEE*hd.h>DDR_DEVCAPS, saevcaps,
 pav->ifnamevcapsdr	wpa_printf(MSG_INFO, "%soctl[SIOfset the iIEEE*hd.h>DDR_DEVCAPS	   strerror(errno));
		close(s);;
	}

	if (bind(f(MSG_DEBUG, "%s: Enabled aobal {caps=0x%08x,	    ocaps=0x%08x__nsi__);
	}

	i, mevcaps.dc_obal {caps, mevcaps.dc_	    ocapslcttl(drvmevcaps.dc_obal {capsr
	 EEE*hd.h>C_R_F1)
	(
	os_a)
{.key_mgmt VER_FLDRIVER_CA_FLKEY_MGMT_icanM
-1	R_FLDRIVER_CA_FLKEY_MGMT_ica_PSK;tl(drvmevcaps.dc_obal {capsr
	 EEE*hd.h>C_R_F2)
	(
	os_a)
{.key_mgmt VER_FLDRIVER_CA_FLKEY_MGMT_ica2nM
-1	R_FLDRIVER_CA_FLKEY_MGMT_ica2_PSK;ttl(drvmevcaps.dc_	    ocapsr
	 EEE*hd.h>CRYPTO_WEP)
	(
	os_a)
{.encr|veR_FLDRIVER_CA_FLENC_WEP40nM
-1	R_FLDRIVER_CA_FLENC_WEP104;tl(drvmevcaps.dc_	    ocapsr
	 EEE*hd.h>CRYPTO_TKIP)udp
	os_a)
{.encr|veR_FLDRIVER_CA_FLENC_TKIP (wmcmpmevcaps.dc_	    ocapsr
	 EEE*hd.h>CRYPTO_AES_CCM)udp
	os_a)
{.encr|veR_FLDRIVER_CA_FLENC_CCMPcttl(drvmevcaps.dc_obal {capsr
	 EEE*hd.h>C_structludp
	os_a)
{.fr.ifr|veR_FLDRIVER_s",
	_

;
# terrrIEEE*hd.h>CIPHER_WEP
# terrrIEEE*hd.h>CIPHER_TKIP
# terrrIEEE*hd.h>CIPHER_AES_CCM
# terrrIEEE*hd.h>CRYPTO_WEP
# terrrIEEE*hd.h>CRYPTO_TKIP
# terrrIEEE*hd.h>CRYPTO_AES_CCM
# terrrIEEE*hd.h>C_struct
# terrrIEEE*hd.h>C_R_F1
# terrrIEEE*hd.h>C_R_F2l__linux__IEEE*hd.h>DDR_DEVCAPSesoc
#inFdrinow,*assume TKIP, CCMP, R_F~(R_F2 as.
 _8_roueadsoc

	os_a)
{.key_mgmt VER_FLDRIVER_CA_FLKEY_MGMT_icanM
-1R_FLDRIVER_CA_FLKEY_MGMT_ica_PSKnM
-1R_FLDRIVER_CA_FLKEY_MGMT_ica2nM
-1R_FLDRIVER_CA_FLKEY_MGMT_ica2_PSK;tl
	os_a)
{.encrveR_FLDRIVER_CA_FLENC_WEP40nM
-1R_FLDRIVER_CA_FLENC_WEP104nM
-1R_FLDRIVER_CA_FLENC_TKIP M
-1R_FLDRIVER_CA_FLENC_CCMPctp
	os_a)
{.fr.ifr|veR_FLDRIVER_s",
	_

;
#_OSTAPD *IEEE*hd.h>DDR_DEVCAPSesocGLIBC__IEEE*hd.h>DDR_SCAN_MAX_ wirie
	os_a)
{.maxlscan_
sidsoveIEEE*hd.h>DDR_SCAN_MAX_ wir* __linux__IEEE*hd.h>DDR_SCAN_MAX_ wiresoc

	os_a)
{.maxlscan_
sidsove1* __OSTAPD *IEEE*hd.h>DDR_SCAN_MAX_ wiresoc

	os_a)
{.authrveR_FLDRIVER_
U
	}OPen M
-1R_FLDRIVER_
U
	}SHARED M
-1R_FLDRIVER_
U
	}LE

;
w
}


static vt wpa_de;
	mhdr *hd.h>op	   
geee8021op	   ia_driver_global {
har i*v =ct w_cp_messrvs#ifd	int fmrcttliv, cc fr, 0, sifmrif(mreq));
	ifmrse(s)iv, cc (sarv->ifnaifmr.lam_->ifname, sizeof(ifr.ifr_nifmr.lam_->if)lcttl(drv->fd, SIOCS	void	 fCGIFHWADDRGIFMEDIF~((cr_be_t)sifmr) >= a_print(drvifmr.lam_curr_rx &oIFMs:EEE*hd.h_ADHOC_printt(drvifmr.lam_curr_rx &oIFMss",
0)intt 
}


stIEEE*hd.h_M_AHDEMOv =t	_ude 	 t 
}


stIEEE*hd.h_M_:B w;
wp}int(drvifmr.lam_curr_rx &oIFMs:EEE*hd.h_structludp 
}


stIEEE*hd.h_M_/
}


;
wp(drvifmr.lam_curr_rx &oIFMs:EEE*hd.h_MONITORludp 
}


stIEEE*hd.h_M_MONITOR iGLIBC__IEEE*hd.h>M_MB w
wp(drvifmr.lam_curr_rx &oIFMs:EEE*hd.h_MB wludp 
}


stIEEE*hd.h_M_MB w;
__OSTAPD *IEEE*hd.h>M_MB wc*s_mcpy
}


stIEEE*hd.h_M_}

 sc vt wpa_d, cons
r_capa *capr_gl *priv)
{
	t char *ifname, const u8 v)
{
	struct wG_FreeB	GETPARAMiv =ofwn_ad8 ve \s)i((ve >ugeee8021d *priv =ofd *pr)	l!=
-1)
	a_driver_global {
har i*v = os_zalloc(sizeof(struct wp*v =crv == NULL) {
		wpa_int;
	}

(else {wp/*
sc* NBtoWe requis.
rae  name %s",st uereAmappeave PAEan(	if (.
	(d     Tare implies wealo ate t_8_rouphaviggef(MSt_8_N_7.x_
	(d     wait l2_pan  name %s",PAEappear.  Tare ser,  ok;nd at
	(d     doesn't be, st here; it' k, allyfrae job"o(__Fvd.
	(drv-= hapla;
		dlpoindex(drv->ifnaizeof(rv == NULL) fla;
		dlp=
0_printf(MSG_INFO,
			s: Failed to name %s",% cdopsoate exinc__
 pae_g;
	}

	i, izeof(rv =Ugoto fset;->ctx = hapt c	stct ;ie_eaCS	void	->usuct iey(drv->ifname, params->iizeof(drv->ifname));
	drv->usecp(drv!GETPARAMiv =ofIEEE*hd.h>DDR_ROAMINnaame, sprev_;#amink__printf(MSG_INFO,
			s: Failed tofset the igter;#aminkn 0)
e	   strerr;
	}

	i, errno));
		close(s);goto fset;->ctp(drv!GETPARAMiv =ofIEEE*hd.h>DDR_PRIVACY~(me, sprev_t flacyl_printf(MSG_INFO,
			s: Failed tofset the igtert flacyn 0)
e	   strerr;
	}

	i, errno));
		close(s);goto fset;->ctp(drv!GETPARAMiv =ofIEEE*hd.h>DDR_R_F~(me, sprev_r_c__printf(MSG_INFO,
			s: Failed tofset the igterw
{= 0)
e	   strerr;
	}

	i, errno));
		close(s);goto fset;->ctd(> ROr_capa *capr_gla)
{iv =crs);goto fset;-c
#inDtype name %s",durink= L;
p.(drv->dhcr_glcr.i_la,
	iSIO (dreturn -1goto fset;-c
d	os_op	   l= geee8021op	   ieturn N=l_cket_		o saIOCS	void	 fla,
	s, saIOCScket(cttl;
	if (v = ofset:_iy(i;
		return N
#else else {# terrrGETPARAMac vt wpa_dv, s
r_capa *capr_glid *priv)
{
	struct wpa_driver_global {
har i*v =	struct iet= NULL) fla;
		dl!etu && != hapla
E multd_printf(MSpa *capr_gls	.if(Miv =of0e(s
);D *NBtomark  name %s",dtypecludpr_glcr.i_la,
	iSIO (drv-intf(MSpa *capr_gls	.if(MStnamenaliv =ofSIOCSprev_r_c 
	  pa	me, sprev_t flacylv-int> ROseee8021d *priv =ofIEEE*hd.h>DDR_ROAMINnaame, sprev_;#amink_n gs & turn -1tf(MSG_INFO,
			s: Fai   pa & ed tofset the iE stls.
;#aminkn 0)
e__   pae_g;
	}

	i);->ctd(> ROock < *) ixmit-!	return NU_data *l2;
ect home, p *) ixmitmr_i=l_cket_del(saIOCScket(ctiy(i;
		return c it wpa_driv
r_capa *capr_gl
	.ia)
{iv, const u8 _packetr_capa *capa)
{
	t)
{ct wpa_driver_global {
har i*v =	struct iet(sap->sa_dt)
{, saIOCSt)
{, ruct wp*t)
{c);
w
}


static __OSTAPD */
}


statint wpa_d, cons
r_gl	void	_ *priv)
{
	t cct wpa_driver_global {
	void		*	void	 iet	void	->u(sizeof(struct wp*	void	crv == NU	void	->
		wpa_int;
	}

(else {wp	void	 fgne	stct ;ie_l_cket_ *pri&	void	 fla,
	s) {wp	void	 f *) 	st *) 0, POCK_DGRASOCK_DGRAM (drv->pf_s	void	 f *) 	wpa_printf(MSG_INFO, "%soctl[SIO *) 0,[POCK_DGRSOCK_DGRAM]	   strerror(errno));
		close(s);goto fsetf (bind(	void	 f;#ife	st *) 0, POCROUTEofSOCK_RAW (drv->pf_s	void	 f;#ife	wpa_printf(MSG_INFO, "%soctl[SIO *) 0,[POCROUTEoSOCK_RAW]	   strerror(errno));
		close(s);goto fset (bind(	void	 f_sta.n_ad_truock,t_adr = ie(s)	void	 f_sta.n_ad->u(simeof(st	void	 f_sta.n_ad_truc;wp> RO	void	 f_sta.n_ad->
		wpa_printf(MSG_INFO,
			octl[SIOd to(simeof(st)send: %__);
		while (wpgoto fset (bindSTAPD
	struct i	_uoop
E gket {
(drv->*) s	void	 f;#ife, r_glnit,	uispol_rx(receal _   pae_P_ALL	void	cre
G_linux__/
}


stati	_uoop
E gket {
(drv->*) s	void	 f;#ife, r_capa *capr_glol_rx(receal _   pae_P_ALL	void	cre__OSTAPD */
}


statin;
}


stgvoid	 iefset:_icloses	void	 f *) ) ofset1:_iy(i;
		r	void	creN
#else else {}__t wpa_dv, s
r_gl	void	_id *priv)
{
	struct wpa_driver_global {
	void		*	void		struct iet_uoop
unE gket {
(drv->*) s	void	 f;#ifee(s)iv, cc closes	void	 f;#ifee(s)iv, cc closes	void	 f *) ) oiy(i;
		r	void	crec vvr *ifn_packetr_capa *capops r_capa *capr_glopst_m wp.drv- pa= "r_gstre.desc pa= "BSDp(uns>1 t_8_roustre.	void	_ *prpa= r_gl	void	_ *prtre.	void	_id *prpa= r_gl	void	_id *pr,dSTAPD
	struct i	._str_ *prpa= r_gl *prtre._str_id *prpa= r_glid *pr,d	.ss(dt flacypa= r_glss(dt flacytre.		.i eqnumpa= r_gl		.i eqnumtre.flush	pa= r_glflushtre.(drv->taloar pa= r_gl(drv->talobal {
har ,d	.s
	rdisassocpa= r_gls
	rdisassoc,d	.s
	rdeauthpa= r_gls
	rdeauth,d	.s
	rss(d r.ifpa= r_glss(d 
	rauthor->ir,d	.

#ipr	pa= r_gl

#ipr,
G_linux__/
}


stati	. *pr2	pa= r_capa *capr_gl *prtre.de *prpaa= r_capa *capr_glid *pr,d	.
	.id *praa= r_capa *capr_gl
	.id *prtre.		.i *praa= r_capa *capr_gl
	.i *prtre.s	.id undermeasu{
	a= r_capa *capr_gls	.id undermeasu{
	tre.s7.x2	pa= r_capa *capr_gls7.xtre.		.i canp	isa_ps2a= r_capa *capr_gl
	.i canp	isa_ps2tre.deauthen			 t8aa= r_capa *capr_glidauthen			 t8tre.associ t8aa= r_capa *capr_glassoci t8tre.		.it)
{aa= r_capa *capr_gl
	.it)
{,e__OSTAPD */
}


statie.s	.if (spa= r_glss(df (stre.s	.ikeypa= r_glss(dkeytre.s	.irdr *hd1xpa= r_glss(drdr *hd1xtre._str_s	.i *praa= r_gls	.i *prtre._str_g	.i *praa= r_glg	.i *prtre._str_l(void *pra= r_gls	void *prtre.s	.igeneric_e		ma= r_gls	.idh